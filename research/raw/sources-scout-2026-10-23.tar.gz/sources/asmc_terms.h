HTTP/1.1 200 Connection Established

HTTP/2 200 
date: Fri, 23 Oct 2026 20:06:19 GMT
content-type: text/html
content-length: 45948
access-control-allow-origin: https://asmc.asean.org
last-modified: Fri, 23 Oct 2026 01:58:56 GMT
etag: "b37c-65e7852aee556"
cache-control: public, max-age=180
x-frame-options: SAMEORIGIN
strict-transport-security: max-age=31536000; includeSubDomains
x-content-type-options: nosniff
referrer-policy: no-referrer
content-security-policy: frame-src 'self' *.youtube.com *.asmc.asean.org *.google.com; 			frame-ancestors 'self' https://asmc.asean.org *.google.com; 			script-src 'self' *.google.com *.adobedtm.com *.youtube.com https://*.gstatic.com *.wogaa.sg *.google-analytics.com *.googleapis.com *.googletagmanager.com cdnjs.cloudflare.com 'unsafe-inline' 'unsafe-eval'; 			object-src https://asmc.asean.org; 			font-src 'self' 'unsafe-inline' 'unsafe-eval' data: https://assets.wogaa.sg/fonts/ https://fonts.gstatic.com https://*.googleapis.com https://maxcdn.bootstrapcdn.com; 			style-src 'self' 'unsafe-inline' 'unsafe-eval' https://*.wogaa.sg https://asmc.asean.org/ https://*.googleapis.com https://maxcdn.bootstrapcdn.com fonts.bunny.net; 			connect-src 'self' *.google.com *.adobedtm.com *.youtube.com *.wogaa.sg *.google-analytics.com *.googleapis.com *.googletagmanager.com https://asmc.asean.org; 			default-src 'self' https://*.wogaa.sg https://asmc.asean.org https://www.google-analytics.com https://www.googletagmanager.com s.w.org; 			img-src	'self' data: https://maps.gstatic.com https://*.googleapis.com https://cdn.amcharts.com https://*.googleusercontent.com https://asmc.asean.org https://www.weather.gov.sg
vary: User-Agent,Origin
x-azure-ref: 20261023T200618Z-r19f94f7f9576dh2hC1DTTdpys00000004ng00000000m44b
x-fd-int-roxy-purgeid: 0
accept-ranges: bytes

