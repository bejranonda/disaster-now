HTTP/1.1 200 Connection Established

HTTP/2 200 
date: Fri, 23 Oct 2026 19:56:57 GMT
content-type: application/json; charset=utf-8
content-encoding: br
content-language: th-TH
vary: Accept-Encoding
x-content-type-options: nosniff
server: elb

