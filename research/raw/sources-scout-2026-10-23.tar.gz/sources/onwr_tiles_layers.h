HTTP/1.1 200 Connection Established

HTTP/2 200 
content-type: application/json
access-control-allow-origin: https://disaster-now.example
access-control-allow-credentials: true
vary: Origin
x-cloud-trace-context: e29dd91c3094ed13fe054b824d5bfcd9
date: Fri, 23 Oct 2026 20:09:37 GMT
server: Google Frontend
content-length: 3448

