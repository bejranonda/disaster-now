HTTP/1.1 200 Connection Established

HTTP/1.1 400 Bad Request
Content-Length: 36
Content-Type: application/json; charset=utf-8
Access-Control-Allow-Origin: *
X-Content-Type-Options: nosniff
Content-Security-Policy: script-src 'self' 'unsafe-inline' 'unsafe-eval' https://gdacs.azurewebsites.net/ *.gdacs.org https://www.gdacs.org https://gdacs.org  https://www.gdacs.org/contentdata  https://gdacs.org/contentdata https://edo.jrc.ec.europa.eu *.jrc.ec.europa.eu *.unpkg.com https://unpkg.com *.geoserver.gfm.eodc.eu https://geoserver.gfm.eodc.eu.com https://cdn.jsdelivr.net *.cdn.jsdelivr.net *.europa.eu https://europa.eu *.ajax.googleapis.com *.ajax.aspnetcdn.com *.gstatic.com *.google.com blob:; frame-ancestors 'self' *.gdacs.org https://gdacs.org https://www.gdacs.org
X-Frame-Options: SAMEORIGIN
Referrer-Policy: strict-origin-when-cross-origin
Date: Fri, 23 Oct 2026 19:52:58 GMT
Strict-Transport-Security: max-age=31536000; includeSubDomains; preload

