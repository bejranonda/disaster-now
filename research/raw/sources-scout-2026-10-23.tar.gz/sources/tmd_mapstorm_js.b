var leafletMap;
var data;
var latlngArray = [];
$("select").removeAttr("multiple");
var cultureEN = document.getElementById("cultureEN").value;
var mapServer;
var dateTimeTH, dateTimeUTC, tracks, windNearCenter, centerPositionForecast, trackForecast, lowPressure, tropicalDepression,
tropicalStorm, typhoon, knot, speedNearCenter, directionOfMovement, severity, latitude, longitude;
var culture = $("html").attr("lang");

$(document).ready(async function () {
    dateTimeTH = $('#dateTimeTHHidden').val();
    dateTimeUTC = $('#dateTimeUTCHidden').val();
    tracks = $('#tracksHidden').val();
    windNearCenter = $('#windNearCenterHidden').val();
    centerPositionForecast = $('#centerPositionForecastHidden').val();
    trackForecast = $('#trackForecastHidden').val();
    lowPressure = $('#lowPressureHidden').val();
    tropicalDepression = $('#tropicalDepressionHidden').val();
    tropicalStorm = $('#tropicalStormHidden').val();
    typhoon = $('#typhoonHidden').val();
    knot = $('#knotHidden').val();
    speedNearCenter = $('#speedNearCenterHidden').val();
    directionOfMovement = $('#directionOfMovementHidden').val();
    severity = $('#severityHidden').val();
    latitude = $("#latitudeHidden").val();
    longitude = $("#longitudeHidden").val();

    if(cultureEN == 'en-US'){
        mapServer = 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/{z}/{y}/{x}';
    }else{
        mapServer = 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png';
    }
    createLeafletMap(null);
    var queryString = window.location.search;
    var urlParams = new URLSearchParams(queryString);
    var isWidget = urlParams.has('isWidget');
    if (isWidget) {
        await getStormData(false);
    } else {
        await getStormData();
    }
});

function createLeafletMap(bounds) {
    leafletMap = L.map('map', {
        zoomControl: false
    }).setView([defaultMapCoords[1], defaultMapCoords[0]], 5);

    L.tileLayer(mapServer , {
        attribution: '',
        maxZoom: 18,
        tileSize: 512,
        zoomOffset: -1
    }).addTo(leafletMap);

    if (bounds != null) {
        leafletMap.fitBounds(bounds);
    }
}

function emptyMap() {

    document.getElementById('mapcontainer').innerHTML = "<div id='map'></div><div id='mapcontroller'><div class='btn bg-white btn-primary-outline mb-3' onclick='enlargeMap()'><i class='fas fa-expand-arrows-alt'></i></div><div class='btn bg-white btn-primary-outline mb-3' onclick='showLagends()'><i class='fas fa-info'></i></div></div><div id='strom-legend' class='card'><div class='d-flex'><div class='me-2'><img src='/CustomTheme3/images/Storm/legends/1.png'></div><div>" + tracks + "</div></div><div class='d-flex'><div class='me-2'><img src='/CustomTheme3/images/Storm/legends/2.png'></div><div >" + windNearCenter + "</div></div><div class='d-flex'><div class='me-2'><img src='/CustomTheme3/images/Storm/legends/3.png'></div><div>" + centerPositionForecast + "</div></div><div class='d-flex'><div class='me-2'><img src='/CustomTheme3/images/Storm/legends/4.png'></div><div>" + trackForecast + "</div></div><div class='d-flex'><div class='me-2'><img src='/CustomTheme3/images/Storm/legends/5.png'></div><div>" + lowPressure + "</div></div><div class='d-flex'><div class='me-2'><img src='/CustomTheme3/images/Storm/legends/6.png'></div><div>" + tropicalDepression + "</div></div><div class='d-flex'><div class='me-2'><img src='/CustomTheme3/images/Storm/legends/7.png'></div><div>" + tropicalStorm + "</div></div><div class='d-flex'><div class='me-2'><img src='/CustomTheme3/images/Storm/legends/8.png'></div><div>" + typhoon + "</div></div></div><div id='mappositioncontroller'><div class='btn-group-vertical' role='group'><div class='btn btn-primary-outline' onclick='zoomIn()'><i class='fas fa-plus'></i></div><div class='btn btn-primary-outline' onclick='zoomOut()'><i class='fas fa-minus'></i></div></div></div>";
}

function zoomIn() {
    leafletMap ? leafletMap.setZoom(leafletMap.getZoom() + 1) : mymap.setZoom(mymap.getZoom() + 1);
}

function zoomOut() {
    leafletMap ? leafletMap.setZoom(leafletMap.getZoom() - 1) : mymap.setZoom(mymap.getZoom() - 1);
}

function enlargeMap() {
    $('#mapdisplay').toggleClass('fullscreen');
    var isScrollable = document.getElementById('mapdisplay');
    if (isScrollable.classList.contains('fullscreen')) {
        var windowHeight = $(window).height() - 74;
        $('#map').height(windowHeight + 'px');
        reRanderMap()
        $('html, body').css({
            overflow: 'hidden',
            height: '100%'
        });
    } else {
        var windowHeight = $(window).height() - (191 + 74);
        $('#map').height(windowHeight + 'px');
        reRanderMap();
        $('html, body').css({
            overflow: 'auto',
            height: 'auto'
        });
    }
}

async function getStormData(isAlert) {
    var culture = "th-TH";
    if (window.location.href.indexOf("/en/") > -1) {
        culture = "en-US"
    }
    var isAlertWidget = isAlert !== null && isAlert !== undefined ? isAlert : true;
    emptyMap();
    //createLeafletMap(leafletMap.getBounds());  load after fetch api
    latlngArray = [];
    inProgress();
    var stormId = $("#StormNameSelectList option:selected").val();
    stormId = encodeURI(stormId);

    await fetch('/api/Weather/StormTrack?stormId=' + stormId).then(async res => {
        data = await res.json();
        if (data.total > 0) {
            createLeafletMap(leafletMap.getBounds());
            displayStormMap();
            setFitBound();
            progressComplete();
        } else {
            createLeafletMap(leafletMap.getBounds());
            progressComplete();
            if (isAlertWidget) {
                //alert("ไม่มีข้อมูล");
                if (culture == "en-US") {
                    AlertStormEN();
                } else {
                    AlertStorm();
                }
            }
        }
    });
}

function setFitBound() {
    var bounds = new L.LatLngBounds(latlngArray);
    leafletMap.fitBounds(bounds);
}

function displayStormMap() {
    data.stormTrackingData.forEach(m => {

        var lineCoordsPath = [];
        var lineFutureCoordsPath = [];
        var areaPolygon = [];
        var areaRadiusPolygon = [];
        var markerPoints = [];

        var radisPolygons = [];


        m.path.forEach(n => {

            var centerCoord = [n.longitude, n.latitude];

            var radius = n.area;
            var options = {
                time: n.time,
                name: m.name,
                speed: n.windSpeed,
                predictSpeed: n.windSpeedPredict,
                type: n.type,
                isPredictData: n.isPredictData,
                iconPath: n.iconPath,
                dateTimeTH: n.dateTimeTH,
                dateTimeEN: n.dateTimeEN,
                direction: n.direction,
                lat: n.latitude,
                lon: n.longitude,
                area: n.area,
                nameEN: m.nameEN,
                typeEN: n.typeEN
            };


            var markerPoint = turf.point(centerCoord, options);
            markerPoints.push(markerPoint);

            lineCoordsPath.push({
                coordinates: centerCoord,
                options: options
            });

            var latlng = [n.latitude, n.longitude];

            if (n.isPredictData) {
                lineFutureCoordsPath.push(centerCoord);
                radisPolygons.push({
                    latlng: latlng,
                    radius: radius,
                    isFuture: options.isPredictData
                });
            }

            latlngArray.push(latlng);
        });

        if (lineCoordsPath.length > 0) {

            var pathLength = lineCoordsPath.length;
            var skip = 0;
            var min = 2;
            var coordsSetArray = [];

            for (var i = 0; i < pathLength; i++) {

                var isPredict = lineCoordsPath[i].options.isPredictData;

                if (isPredict) {
                    var coords = [lineCoordsPath[i].options.lon, lineCoordsPath[i].options.lat];
                    var areaPolygonValue = lineCoordsPath[i].options.area / 1000;
                    areaPolygon.push(coords);
                    areaRadiusPolygon.push(areaPolygonValue);

                    var lastCoordData = lineCoordsPath[i - 1];
                    if (lastCoordData) {
                        var lastCoordsIsPredict = lastCoordData.options.isPredictData;
                        if (!lastCoordsIsPredict) {
                            var lastCoordCoordinates = [lastCoordData.options.lon, lastCoordData.options.lat];
                            areaPolygon.unshift(lastCoordCoordinates);
                            areaRadiusPolygon.unshift(0);
                        }
                    }
                }
                
                var sliceArray = lineCoordsPath.slice(skip, min);
                skip += 2;
                min += 2;

                if (sliceArray.length == 2) {
                    var coordArray = [];
                    var containPredictData = false;

                    sliceArray.forEach(x => {
                        coordArray.push(x.coordinates);
                        if (x.options.isPredictData == true) {
                            containPredictData = true;
                        }
                    });

                    var stormLine = turf.lineString(coordArray, {
                        isFuture: containPredictData
                    });

                    L.geoJson(stormLine, {
                        style: styleLine,
                    }).addTo(leafletMap);

                    coordsSetArray.push(coordArray);

                    var nextTargetIndex = min - 2;

                    var lastSliceArrayItem = sliceArray[sliceArray.length - 1];
                    var nextMainArrayItem = lineCoordsPath[nextTargetIndex];

                    if (nextMainArrayItem) {
                        var nextCoordsObject = [lastSliceArrayItem, nextMainArrayItem];
                        
                        var nextCoordsArray = [];
                        var nextIsPredict = false;

                        if (nextTargetIndex == pathLength - 1) {
                            var predictDataCount = 0;
                            nextCoordsObject.forEach(x => {
                                nextCoordsArray.push(x.coordinates);
                                if (x.options.isPredictData == true) {
                                    predictDataCount += 1;
                                }
                                if (predictDataCount == 2) {
                                    nextIsPredict = true;
                                }
                            });
                        }
                        else {
                            nextCoordsObject.forEach(x => {
                                nextCoordsArray.push(x.coordinates);
                                if (x.options.isPredictData == true) {
                                    nextIsPredict = true;
                                }
                            });
                        }

                        var nextStormLine = turf.lineString(nextCoordsArray, {
                            isFuture: nextIsPredict
                        });

                        L.geoJson(nextStormLine, {
                            style: styleLine,
                        }).addTo(leafletMap);
                    }
                    
                }
                
            }
            
        }

        var hurricane = makeHurricane(areaPolygon, areaRadiusPolygon);

        L.geoJson(hurricane, {
            style: styleHurricane
        }).addTo(leafletMap);

        radisPolygons.forEach(radius => {
            if (radius.isFuture){
                L.circle(radius.latlng, {
                    radius: radius.radius,
                    color: 'red',
                    fillColor: 'red',
                    fillOpacity: 0.2,
                    weight: 0.5
                }).addTo(leafletMap);
            }
        });

        L.geoJSON(markerPoints, {
            pointToLayer: function (feature, latlng) {
                return new L.Marker(latlng, {
                    icon: L.icon({
                        iconUrl: feature.properties.iconPath,
                        iconSize: [36, 36]
                    })
                });
            },
            onEachFeature: function (feature, layer) {
                var name = feature.properties.name;
                var type = feature.properties.type;
                var latDirection = getDirection(feature.properties.lat, "N", "S");
                var lonDirection = getDirection(feature.properties.lon, "E", "W");
                var latValue = convertCoordinatetoDegreeMinuteSecond(feature.properties.lat);
                var lonValue = convertCoordinatetoDegreeMinuteSecond(feature.properties.lon);
                
                if (culture == "en-US") {
                    name = feature.properties.nameEN;
                    type = feature.properties.typeEN;
                }

                var html = `
                    <div>
                        <div class="sub-heading d-flex align-items-center text-nowarp mb-2">${name}</div>
                        <div class="row mb-2">
                            <div class="col-6">
                                <div class="d-flex align-items-center text-nowarp">${speedNearCenter}:</div>
                            </div>
                            <div class="col-6">
                                <div>${showStormWindSpeed(feature.properties.speed, feature.properties.predictSpeed, feature.properties.isPredictData)} ${knot}</div>
                            </div>
                        </div>
                        <div class="row mb-2">
                            <div class="col-6">
                                <div class="d-flex align-items-center text-nowarp">${directionOfMovement}:</div>
                            </div>
                            <div class="col-6">
                                <div>${feature.properties.direction.toUpperCase()}</div>
                            </div>
                        </div>
                        <div class="row mb-2">
                            <div class="col-6">
                                <div class="d-flex align-items-center text-nowarp">${severity}:</div>
                            </div>
                            <div class="col-6">
                                <div>${type}</div>
                            </div>
                        </div>
                        <div class="row mb-2">
                            <div class="col-6">
                                <div class="d-flex align-items-center text-nowarp">${latitude}:</div>
                            </div>
                            <div class="col-6">
                                <div>${latValue} ${latDirection}</div>
                            </div>
                        </div>
                        <div class="row mb-2">
                            <div class="col-6">
                                <div class="d-flex align-items-center text-nowarp">${longitude}:</div>
                            </div>
                            <div class="col-6">
                                <div>${lonValue} ${lonDirection}</div>
                            </div>
                        </div>
                        <div class="row mb-2">
                            <div class="col-6">
                                <div class="d-flex align-items-center text-nowarp">${dateTimeTH}:</div>
                            </div>
                            <div class="col-6">
                                <div>${feature.properties.dateTimeTH}</div>
                            </div>
                        </div>
                        <div class="row mb-2">
                            <div class="col-6">
                                <div class="d-flex align-items-center text-nowarp">${dateTimeUTC}:</div>
                            </div>
                            <div class="col-6">
                                <div>${feature.properties.dateTimeEN}</div>
                            </div>
                        </div>
                    </div>
                    `;
                layer.bindPopup(html);
            }
        }).addTo(leafletMap);
    });

    
    //Bound map on latlngArray
   // setFitBound();
    /* var bounds = new L.LatLngBounds(latlngArray);
    leafletMap.fitBounds(bounds);*/
}



function showLagends() {
    $('#strom-legend').toggle();
}

$("#displayDataBtn").click(async function () {
    getStormData();
});


function checkIsFuture(dateTime) {
    var dateTimeNowUtc = moment.utc();
    var dataDateTimeUTC = new Date(dateTime); // time is utc.
    var isFuture = false;

    if (dataDateTimeUTC.valueOf() > dateTimeNowUtc.valueOf()) {
        isFuture = true;
    }

    /*console.log("timeBE", dataDateTimeUTC.valueOf());
    console.log("timeBE as UTC format", moment(dataDateTimeUTC).format());
    console.log("dateTimeNowUtc", dateTimeNowUtc.valueOf());
    console.log("dateTimeNowUtc as UTC format", moment.utc(dateTimeNowUtc).format());
    console.log("isFuture", isFuture);*/

    return isFuture;
}

function inProgress() {
    $("html,body").css({ 'z-index': '1000', 'cursor': 'progress' });
}

function progressComplete() {
    $("html,body").css({ 'z-index': '0', 'cursor': 'default' });
}

function convertCoordinatetoDegreeMinuteSecond(coordinate) {

    var degrees = Math.floor(Math.abs(coordinate));

    var minutes = Math.floor((Math.abs(coordinate) - degrees) * 60);

    var seconds = Math.round((minutes - Math.floor(minutes)) * 60);

    return `${degrees}° ${minutes}' ${seconds}"`;

}

function getDirection(value, positiveDirection, negativeDirection) {
    return value >= 0 ? positiveDirection : negativeDirection;
}