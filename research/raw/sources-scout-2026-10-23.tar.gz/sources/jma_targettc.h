HTTP/1.1 200 Connection Established

HTTP/2 200 
content-type: application/json
content-length: 209
server: AmazonS3
last-modified: Fri, 23 Oct 2026 19:41:16 GMT
x-amz-server-side-encryption: AES256
accept-ranges: bytes
date: Fri, 23 Oct 2026 19:53:46 GMT
cache-control: max-age=60
etag: "d9cb0ff07bc31b32577cc5c54064744a"
vary: Accept-Encoding
via: 1.1 a04e8c97f1e289e082ffa9503a1e95d0.cloudfront.net (CloudFront)
age: 54
x-xss-protection: 1; mode=block
referrer-policy: strict-origin-when-cross-origin
content-security-policy: script-src 'self' 'unsafe-inline' 'unsafe-eval' www.jma.go.jp www.jma-net.go.jp js.jma.go.jp www.data.jma.go.jp ds.data.jma.go.jp www.google.com www.gstatic.com jma.genieesspv.jp pagead2.googlesyndication.com code.jquery.com ajaxzip3.github.io cdn.jsdelivr.net ajax.aspnetcdn.com code.createjs.com unpkg.com cdnjs.cloudflare.com ajax.googleapis.com platform.twitter.com github.githubassets.com maps.gsi.go.jp img.gsspat.jp; frame-ancestors 'self' www.mlit.go.jp www.data.jma.go.jp ds.data.jma.go.jp www.jma-net.go.jp www.pref.tokushima.lg.jp www.cgr.mlit.go.jp river-bosai.ktr.mlit.go.jp mie-mizubosai.go.jp sim.mie-mizubosai.go.jp mobile.mie-mizubosai.go.jp yoshino-drs.skr.mlit.go.jp view.mie-mizubosai.cbr.mlit.go.jp sim.mie-mizubosai.cbr.mlit.go.jp mobile.mie-mizubosai.cbr.mlit.go.jp
x-content-type-options: nosniff
strict-transport-security: max-age=31536000; preload
access-control-allow-origin: *
access-control-allow-headers: X-Requested-With
x-amz-cf-pop: IAD61-P6
x-amz-cf-id: ayduxfq3VmJqF1YLhGXtMh0aLyLZbZv6bq5hSSmO51zCyCiAWOUFlg==

