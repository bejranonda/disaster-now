<?xml version="1.0" encoding="utf-8"?>
<rss xmlns:content="http://purl.org/rss/1.0/modules/content/" xmlns:dc="http://purl.org/dc/elements/1.1/" version="2.0">
  <channel>
    <title>พยากรณ์อากาศประจำวัน - ภาคเหนือ</title>
    <link>http://www.tmd.go.th/api/xml/region-daily-forecast?regionid=1</link>
    <description>พยากรณ์อากาศ โดย กรมอุตุนิยมวิทยา กระทรวงดิจิทัลเพื่อเศรษฐกิจและสังคม</description>
    <language>th-TH</language>
    <copyright>Copyright 2006,Thai Meteorological Deaprtment</copyright>
    <ttl>120</ttl>
    <item>
      <title>พยากรณ์อากาศ ภาคเหนือ วันที่ 23/10/2026</title>
      <pubDate>Fri, 23 Oct 2026 21:07:00 +07:00</pubDate>
      <guid>1</guid>
      <link>http://www.tmd.go.th/api/xml/region-daily-forecast?regionid=1</link>
      <author>กรมอุตุนิยมวิทยา</author>
      <description><![CDATA[วันที่ 23/10/2026 ตั้งแต่เวลา 21:07 น. วันที่ - 21:07 น. วันพรุ่งนี้ </br><img src='http://www.tmd.go.th/CustomTheme3/icons/icon-forecast/12.svg'>Isolated thundershowers mostly in Mae Hong Son, Tak, and Phetchabun.
Minimum temperature 22–26 °C. 
Maximum temperature 34–37 °C.
Southeasterly winds 10–20 km./hr.
< br />< b > คาดหมายอุณหภูมิ(&deg; C)</ b >< br />เชียงราย&nbsp; สูงสุด 35&nbsp;&nbsp;ต่ำสุด 23<br />เชียงใหม่&nbsp; สูงสุด 36&nbsp;&nbsp;ต่ำสุด 24<br />สุโขทัย&nbsp; สูงสุด 36&nbsp;&nbsp;ต่ำสุด 25<br />ลำปาง&nbsp; สูงสุด 36&nbsp;&nbsp;ต่ำสุด 23<br />]]></description>
    </item>
  </channel>
</rss>