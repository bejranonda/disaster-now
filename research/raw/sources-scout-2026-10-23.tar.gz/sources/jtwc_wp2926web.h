HTTP/1.1 200 Connection Established

HTTP/2 200 
content-type: text/plain
content-length: 5925
server: N/A
date: Fri, 23 Oct 2026 19:55:09 GMT
access-control-allow-origin: *
access-control-allow-methods: GET, HEAD
access-control-expose-headers: ETag
access-control-max-age: 1800
last-modified: Fri, 23 Oct 2026 13:31:15 GMT
etag: "b02ef2d8cd5140c150cebb92934fc10b"
x-amz-server-side-encryption: AES256
x-amz-version-id: swreH3a5Qx3qSCBzXdfnUZRoF.hCMYaW
accept-ranges: bytes
vary: Origin
via: 1.1 5a1e060c40f67082568062fc17c09130.cloudfront.net (CloudFront)
x-amz-cf-pop: ORD51-P2
x-amz-cf-id: 14FCNr1UP_sU0mcX_PJ51JUd5XRC_WYNpi-3DdC9wCSY2RoZ7QIrXA==
x-xss-protection: 1; mode=block
x-frame-options: SAMEORIGIN
referrer-policy: same-origin
content-security-policy: frame-ancestors 'self'
x-content-type-options: nosniff
strict-transport-security: max-age=31536000; includeSubDomains; preload

