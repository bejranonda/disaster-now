HTTP/1.1 200 Connection Established

HTTP/2 404 
content-type: text/html; charset=iso-8859-1
content-length: 58
date: Fri, 23 Oct 2026 19:59:32 GMT
strict-transport-security: max-age=31536000; includeSubDomains; preload
server: ServerTokens ProductOnly
cache-control: public, max-age=3600
x-xss-protection: 1; mode=block
x-frame-options: SAMEORIGIN
x-content-type-options: nosniff
via: 1.1 9614fd760660834f20ac759cf94964b6.cloudfront.net (CloudFront)
x-amz-cf-pop: ORD56-P7
x-amz-cf-id: e8YbgaZS9yKwzR2B1TgR-EsM7_AHzq9UKeL3E7TMNl7__o_iOI2EEw==

