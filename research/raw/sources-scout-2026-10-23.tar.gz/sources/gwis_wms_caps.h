HTTP/1.1 200 Connection Established

HTTP/2 200 
date: Fri, 23 Oct 2026 20:06:30 GMT
content-type: application/vnd.ogc.wms_xml; charset=UTF-8
content-length: 197173
accept-ranges: bytes
access-control-allow-origin: *
cache-control: no-store
server: lighttpd/1.4.74

