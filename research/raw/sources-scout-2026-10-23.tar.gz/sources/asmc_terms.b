<!DOCTYPE html>
<!--[if IE 7]>
<html class="ie ie7" lang="en-US">
<![endif]-->
<!--[if IE 8]>
<html class="ie ie8" lang="en-US">
<![endif]-->
<!--[if !(IE 7) & !(IE 8)]><!-->
<html lang="en-US">
<!--<![endif]-->
<head>
<meta name='robots' content='index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1' />

	<!-- This site is optimized with the Yoast SEO plugin v23.6 - https://yoast.com/wordpress/plugins/seo/ -->
	<link rel="canonical" href="https://asmc.asean.org/terms-of-use/" />
	<meta property="og:locale" content="en_US" />
	<meta property="og:type" content="article" />
	<meta property="og:title" content="Terms of Use - ASMC" />
	<meta property="og:description" content="TERMS OF USE Thank you for visiting the official website of the ASEAN Specialised Meteorological Centre (&#8220;this Site”). By accessing and using any part of this Site, you shall be deemed to have unconditionally accepted to be legally bound by the Terms of Use. If you do not agree to any of these Terms of [&hellip;]" />
	<meta property="og:url" content="https://asmc.asean.org/terms-of-use/" />
	<meta property="og:site_name" content="ASMC" />
	<meta property="article:modified_time" content="2016-04-28T09:24:29+00:00" />
	<meta name="twitter:card" content="summary_large_image" />
	<meta name="twitter:label1" content="Est. reading time" />
	<meta name="twitter:data1" content="7 minutes" />
	<script type="application/ld+json" class="yoast-schema-graph">{"@context":"https://schema.org","@graph":[{"@type":"WebPage","@id":"https://asmc.asean.org/terms-of-use/","url":"https://asmc.asean.org/terms-of-use/","name":"Terms of Use - ASMC","isPartOf":{"@id":"https://asmc.asean.org/#website"},"datePublished":"2015-04-24T02:29:52+00:00","dateModified":"2016-04-28T09:24:29+00:00","breadcrumb":{"@id":"https://asmc.asean.org/terms-of-use/#breadcrumb"},"inLanguage":"en-US","potentialAction":[{"@type":"ReadAction","target":["https://asmc.asean.org/terms-of-use/"]}]},{"@type":"BreadcrumbList","@id":"https://asmc.asean.org/terms-of-use/#breadcrumb","itemListElement":[{"@type":"ListItem","position":1,"name":"Home","item":"https://asmc.asean.org/"},{"@type":"ListItem","position":2,"name":"Terms of Use"}]},{"@type":"WebSite","@id":"https://asmc.asean.org/#website","url":"https://asmc.asean.org/","name":"ASMC","description":"ASEAN Specialized Meteorological Centre","potentialAction":[{"@type":"SearchAction","target":{"@type":"EntryPoint","urlTemplate":"https://asmc.asean.org/?s={search_term_string}"},"query-input":{"@type":"PropertyValueSpecification","valueRequired":true,"valueName":"search_term_string"}}],"inLanguage":"en-US"}]}</script>
	<!-- / Yoast SEO plugin. -->


<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel="alternate" type="application/rss+xml" title="ASMC &raquo; Feed" href="https://asmc.asean.org/feed/" />
<link rel="alternate" type="application/rss+xml" title="ASMC &raquo; Comments Feed" href="https://asmc.asean.org/comments/feed/" />
<link rel="alternate" type="application/rss+xml" title="ASMC &raquo; Terms of Use Comments Feed" href="https://asmc.asean.org/terms-of-use/feed/" />
<script type="text/javascript">
/* <![CDATA[ */
window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/15.0.3\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/15.0.3\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/asmc.asean.org\/wp-includes\/js\/wp-emoji-release.min.js?ver=6.5.12"}};
/*! This file is auto-generated */
!function(i,n){var o,s,e;function c(e){try{var t={supportTests:e,timestamp:(new Date).valueOf()};sessionStorage.setItem(o,JSON.stringify(t))}catch(e){}}function p(e,t,n){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);var t=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data),r=(e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(n,0,0),new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data));return t.every(function(e,t){return e===r[t]})}function u(e,t,n){switch(t){case"flag":return n(e,"\ud83c\udff3\ufe0f\u200d\u26a7\ufe0f","\ud83c\udff3\ufe0f\u200b\u26a7\ufe0f")?!1:!n(e,"\ud83c\uddfa\ud83c\uddf3","\ud83c\uddfa\u200b\ud83c\uddf3")&&!n(e,"\ud83c\udff4\udb40\udc67\udb40\udc62\udb40\udc65\udb40\udc6e\udb40\udc67\udb40\udc7f","\ud83c\udff4\u200b\udb40\udc67\u200b\udb40\udc62\u200b\udb40\udc65\u200b\udb40\udc6e\u200b\udb40\udc67\u200b\udb40\udc7f");case"emoji":return!n(e,"\ud83d\udc26\u200d\u2b1b","\ud83d\udc26\u200b\u2b1b")}return!1}function f(e,t,n){var r="undefined"!=typeof WorkerGlobalScope&&self instanceof WorkerGlobalScope?new OffscreenCanvas(300,150):i.createElement("canvas"),a=r.getContext("2d",{willReadFrequently:!0}),o=(a.textBaseline="top",a.font="600 32px Arial",{});return e.forEach(function(e){o[e]=t(a,e,n)}),o}function t(e){var t=i.createElement("script");t.src=e,t.defer=!0,i.head.appendChild(t)}"undefined"!=typeof Promise&&(o="wpEmojiSettingsSupports",s=["flag","emoji"],n.supports={everything:!0,everythingExceptFlag:!0},e=new Promise(function(e){i.addEventListener("DOMContentLoaded",e,{once:!0})}),new Promise(function(t){var n=function(){try{var e=JSON.parse(sessionStorage.getItem(o));if("object"==typeof e&&"number"==typeof e.timestamp&&(new Date).valueOf()<e.timestamp+604800&&"object"==typeof e.supportTests)return e.supportTests}catch(e){}return null}();if(!n){if("undefined"!=typeof Worker&&"undefined"!=typeof OffscreenCanvas&&"undefined"!=typeof URL&&URL.createObjectURL&&"undefined"!=typeof Blob)try{var e="postMessage("+f.toString()+"("+[JSON.stringify(s),u.toString(),p.toString()].join(",")+"));",r=new Blob([e],{type:"text/javascript"}),a=new Worker(URL.createObjectURL(r),{name:"wpTestEmojiSupports"});return void(a.onmessage=function(e){c(n=e.data),a.terminate(),t(n)})}catch(e){}c(n=f(s,u,p))}t(n)}).then(function(e){for(var t in e)n.supports[t]=e[t],n.supports.everything=n.supports.everything&&n.supports[t],"flag"!==t&&(n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&n.supports[t]);n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&!n.supports.flag,n.DOMReady=!1,n.readyCallback=function(){n.DOMReady=!0}}).then(function(){return e}).then(function(){var e;n.supports.everything||(n.readyCallback(),(e=n.source||{}).concatemoji?t(e.concatemoji):e.wpemoji&&e.twemoji&&(t(e.twemoji),t(e.wpemoji)))}))}((window,document),window._wpemojiSettings);
/* ]]> */
</script>
<style id='wp-emoji-styles-inline-css' type='text/css'>

	img.wp-smiley, img.emoji {
		display: inline !important;
		border: none !important;
		box-shadow: none !important;
		height: 1em !important;
		width: 1em !important;
		margin: 0 0.07em !important;
		vertical-align: -0.1em !important;
		background: none !important;
		padding: 0 !important;
	}
</style>
<link rel='stylesheet' id='wp-block-library-css' href='https://asmc.asean.org/wp-includes/css/dist/block-library/style.min.css?ver=6.5.12' type='text/css' media='all' />
<style id='classic-theme-styles-inline-css' type='text/css'>
/*! This file is auto-generated */
.wp-block-button__link{color:#fff;background-color:#32373c;border-radius:9999px;box-shadow:none;text-decoration:none;padding:calc(.667em + 2px) calc(1.333em + 2px);font-size:1.125em}.wp-block-file__button{background:#32373c;color:#fff;text-decoration:none}
</style>
<style id='global-styles-inline-css' type='text/css'>
body{--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;--wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);--wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);--wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);--wp--preset--shadow--outlined: 6px 6px 0px -3px rgba(255, 255, 255, 1), 6px 6px rgba(0, 0, 0, 1);--wp--preset--shadow--crisp: 6px 6px 0px rgba(0, 0, 0, 1);}:where(.is-layout-flex){gap: 0.5em;}:where(.is-layout-grid){gap: 0.5em;}body .is-layout-flex{display: flex;}body .is-layout-flex{flex-wrap: wrap;align-items: center;}body .is-layout-flex > *{margin: 0;}body .is-layout-grid{display: grid;}body .is-layout-grid > *{margin: 0;}:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
.wp-block-navigation a:where(:not(.wp-element-button)){color: inherit;}
:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}
:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}
.wp-block-pullquote{font-size: 1.5em;line-height: 1.6;}
</style>
<link rel='stylesheet' id='twentytwelve-fonts-css' href='https://fonts.googleapis.com/css?family=Open+Sans:400italic,700italic,400,700&#038;subset=latin,latin-ext' type='text/css' media='all' />
<link rel='stylesheet' id='twentytwelve-style-css' href='https://asmc.asean.org/wp-content/themes/asmctheme/style.css?ver=6.5.12' type='text/css' media='all' />
<!--[if lt IE 9]>
<link rel='stylesheet' id='twentytwelve-ie-css' href='https://asmc.asean.org/wp-content/themes/asmctheme/css/ie.css?ver=20121010' type='text/css' media='all' />
<![endif]-->
<script type="text/javascript" src="https://asmc.asean.org/wp-includes/js/jquery/jquery.min.js?ver=3.7.1" id="jquery-core-js"></script>
<script type="text/javascript" src="https://asmc.asean.org/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.4.1" id="jquery-migrate-js"></script>
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://asmc.asean.org/xmlrpc.php?rsd" />
<meta name="generator" content="WordPress 6.5.12" />
<link rel='shortlink' href='https://asmc.asean.org/?p=182' />
<link rel="alternate" type="application/json+oembed" href="https://asmc.asean.org/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fasmc.asean.org%2Fterms-of-use%2F" />
<link rel="alternate" type="text/xml+oembed" href="https://asmc.asean.org/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fasmc.asean.org%2Fterms-of-use%2F&#038;format=xml" />
<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style>
<!--add for GA4 -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-H51X2LHJYX"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-H51X2LHJYX');
</script>
<!--add for GA4 end -->

<link rel="shortcut icon" type="image/x-icon" href="https://asmc.asean.org/wp-content/themes/asmctheme/assets/img/favicon.ico" />
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width" />
<!--<meta http-equiv="cache-control" content="max-age=0" />
<meta http-equiv="cache-control" content="no-cache, no-store, must-revalidate" />
<meta http-equiv="expires" content="0" />
<meta http-equiv="expires" content="Tue, 01 Jan 1980 1:00:00 GMT" />
<meta http-equiv="pragma" content="no-cache" />-->

<!--Added for cache control on 28/11/2016 -->
<!-- <meta http-equiv="cache-control" content="public, max-age=60, must-revalidate" /> -->

<title>Terms of Use - ASMC</title>
<link rel="profile" href="http://gmpg.org/xfn/11" />
<link rel="pingback" href="https://asmc.asean.org/xmlrpc.php" />
<link href="https://asmc.asean.org/wp-content/themes/asmctheme/lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="https://asmc.asean.org/wp-content/themes/asmctheme/lib/bootstrap-datepicker/datepicker3.css" rel="stylesheet">
<link href="https://asmc.asean.org/wp-content/themes/asmctheme/lib/jquery-ui/jquery-ui.css" rel="stylesheet">
<link href="https://asmc.asean.org/wp-content/themes/asmctheme/assets/css/style.css" rel="stylesheet">
<!-- Disabling responsiveness -->
<link href="https://asmc.asean.org/wp-content/themes/asmctheme/assets/css/non-responsive.css" rel="stylesheet">
<link href="https://asmc.asean.org/wp-content/themes/asmctheme/assets/css/print.css" media="print" rel="stylesheet">
<script type="text/javascript"></script>
<script src="https://assets.wogaa.sg/scripts/wogaa.js"></script>

<script src="https://asmc.asean.org/wp-content/themes/asmctheme/lib/jquery/jquery-3.7.1.min.js"></script>
<script src="https://asmc.asean.org/wp-content/themes/asmctheme/lib/jquery-ui/jquery-ui.js"></script>
<script src="https://asmc.asean.org/wp-content/themes/asmctheme/lib/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="https://asmc.asean.org/wp-content/themes/asmctheme/lib/bootstrap-datepicker/bootstrap-datepicker.js"></script>
<script src="https://asmc.asean.org/wp-content/themes/asmctheme/assets/js/global.js"></script>     
<script src="https://asmc.asean.org/wp-content/themes/asmctheme/js/utils.js"></script>    
<script src="https://asmc.asean.org/wp-content/themes/asmctheme/lib/moment.js/moment-with-locales.js"></script> </head>

<body>

<div class="pre-loader"></div>										<link href="https://asmc.asean.org/wp-content/themes/asmctheme/styles_resizer.css" rel="stylesheet"><header>            <div class="container">                <div class="row">                    <div class="col-4" style='width:312px;'>                        <a class="logo" href="https://asmc.asean.org/home/"><img src="https://asmc.asean.org/wp-content/themes/asmctheme/assets/img/logo.png" alt="ASMC" width="312" height="79"></a>                    </div>                    <div class="col-6" style='margin-top:50px;margin-left:40px;'>						<div class="row" >							<div class="col-12 text-end">								<div class="donotresize">									<ul class="list-inline">										<li class="list-inline-item">											<div id="controls">														<span id=nowTextPercent class="donotresize"></span>												<a style="border-bottom:none;" href="#" id="decrease" class="selected">A<sup>-</sup></a>  												<a style="border-bottom:none;" href="#" id="increase">A<sup>+</sup></a>											</div>										</li>										<li class="list-inline-item"><a class="donotresize" href="https://asmc.asean.org/asmc-about/">About ASMC</a></li>										<li class="list-inline-item"><a class="donotresize" href="https://asmc.asean.org/asmc-contact-us/">Contact Us</a></li>										<li class="list-inline-item"><form role="search" method="get" id="searchform" class="searchform" action="https://asmc.asean.org/" >
	<div class="search-container">
	<button type="submit" id="searchsubmit"><img alt="search" src="https://asmc.asean.org/wp-content/themes/asmctheme/assets/img/icons/icon-search.png"></button>
	<input type="text" value="" name="s" id="s" placeholder="Search" />
	</div>
	</form>										</li>									</ul>								</div>							</div>						</div>                    </div>             <div id='asean-logo' class="col-2">								<img alt='MSS' width='79' height='79' style='margin-top:30px;margin-left:40px;' src="https://asmc.asean.org/wp-content/themes/asmctheme/assets/img/asean-logo.png"/>             </div>                          <div class="col-12">						<div class="row">							<div class="col-12 text-end">								<nav  class="main-nav navbar-expand-sm" role="navigation">									<ul class="nav navbar-nav donotresize" style='padding:0px 30px;margin-right:15px;width:100%;'>									<li class='nav-item w25'>											<a  href="#" class="navhead nav-link donotresize" data-bs-toggle="dropdown">Transboundary Haze</a>												<ul class="dropdown-menu donotresize " role="menu">                            					<li><a class="donotresize dropdown-item " href="https://asmc.asean.org/asmc-alerts/">Warnings and Alerts</a></li>                            					<li id='getLatestHazeOutlook'><a id='hazeTagReviewLink' class="donotresize dropdown-item" href='#'>Haze Review</a></li>                            					<li><a class="donotresize dropdown-item" href="https://asmc.asean.org/satellite-polar/">Satellite Images</a></li>                            					<li><a class="donotresize dropdown-item" href="https://asmc.asean.org/asmc-hotspot/">Hotspot Information</a></li>                            					<li><a class="donotresize dropdown-item" href="https://asmc.asean.org/asmc-gis-portal/">Haze Information Portal</a></li>                            					<!-- <li><a class="donotresize dropdown-item" href="https://asmc.asean.org/asmc-haze-air-quality/">Air Quality Information</a></li> -->                            					<li><a class="donotresize dropdown-item" href="https://asmc.asean.org/asmc-fire/">Fire Danger Rating System</a></li>                       </ul>										</li>									<li class='nav-item w15 ml-2P'>											<a  href="#" class="navhead nav-link donotresize" data-bs-toggle="dropdown">Weather</a>											<ul class="dropdown-menu donotresize" role="menu">                            					<li><a class="donotresize dropdown-item" href="https://asmc.asean.org/asmc-regional-weather-observation/">Regional Weather</a></li>                            					<li id='getLatestWeatherOutlook'><a id='headWeatherOutlookLink' class="donotresize dropdown-item" href='#' >Subseasonal Weather Outlook and Review</a></li>                       </ul>										</li>									<li class='nav-item w15 ml-2P'>											<a  href="#" class="navhead nav-link donotresize" data-bs-toggle="dropdown">Climate</a>											<ul class="dropdown-menu donotresize " role="menu">												<li><a class="donotresize dropdown-item" href="https://asmc.asean.org/asmc-seasonal-outlook/">Seasonal Forecast (1-month and 3-month outlook)</a></li>												<li><a class="donotresize dropdown-item" href="https://asmc.asean.org/asmc-el-nino/">El Niño / La Niña</a></li>                     </ul>										</li>									<li class='nav-item w25 ml-30'>											<a  href="#" class="navhead nav-link donotresize" data-bs-toggle="dropdown">Events & Publications</a>                     <ul class="dropdown-menu donotresize" role="menu">												<li><a id='headEventsLink' class="donotresize dropdown-item" href='#' >Events</a></li>												<li><a id='headPublicLink' class="donotresize dropdown-item" href='#' >Publication</a></li>                     </ul>										</li>									<li class='nav-item w20 ml-0''>											<a class="navhead nav-link donotresize" href="https://wis2.asmc.asean.org">Data Catalog</a><!-- wis -->										</li>									</ul>								</nav>							</div></div></div>                </div>            </div>        </header>
        <div class="main">

        	<div class="container">
        		<ol class="breadcrumb">	<li class="breadcrumb-item"><a href="https://asmc.asean.org/home"><span>Home</span></a></li>	<li class="active breadcrumb-item">Terms of Use</li></ol>                                			</div>
			
						<div class="page-header">
				<div class="container">
					<h1>Terms of Use</h1>
				</div>
							</div>
						
							

				

			<div class="content-wrapper">
<div class="container">
<div class="row">
<div class="col-9">
<p> <strong>TERMS OF USE</strong></p>
<p> Thank you for visiting the official website of the ASEAN Specialised Meteorological Centre (&#8220;this Site”). By accessing and using any part of this Site, you shall be deemed to have unconditionally accepted to be legally bound by the Terms of Use. If you do not agree to any of these Terms of Use, please do not use this Site and/or the online services.</p>
<ol>
<li><strong> GENERAL</strong></li>
</ol>
<p> These Terms of Use may be changed from time to time at the absolute discretion of Meteorological Service Singapore, who is the host of this Site. All changes will be posted on this page, and your use of this Site after such changes have been posted will constitute your unconditional agreement to the modified Terms of Use and all of the changes. You should therefore read this page carefully each time you visit the Site.</p>
<ol start="2">
<li><strong> PROPRIETARY RIGHTS</strong></li>
</ol>
<p> 2.1 This Site is owned, operated and maintained by the Meteorological Service Singapore (“MSS”) of the National Environment Agency (“NEA”).</p>
<p> 2.2 The materials located on this Site including the information, trade and service marks and any software programs (&#8220;the Contents”), are protected by copyright, trademark and other forms of proprietary rights. All rights, title and interest in the Contents are owned by, licensed to or controlled by NEA.</p>
<p> 2.3 For enquiries to use any parts of the Contents of this Site, the User is requested to contact MSS by referring to Clause 4.2 below.</p>
<ol start="3">
<li><strong> PRIVACY STATEMENT</strong></li>
</ol>
<p> Please click <a href="https://asmc.asean.org/privacy-statement/">here </a>to review this Site’s Privacy Statement.</p>
<ol start="4">
<li><strong> RESTRICTIONS ON USE OF CONTENTS </strong></li>
</ol>
<p> 4.1 Except as otherwise provided, the Contents of this Site shall not be reproduced, republished, uploaded, posted, transmitted or otherwise distributed in any way, without the prior written permission of MSS.</p>
<p> 4.2 Subject to Clause 4.3, to use any parts of the Contents of this Site, the user must seek permission in writing via an email (ASMC_Enquiries@nea.gov.sg), stating the:</p>
<ul>
<li>Contents for use;</li>
<li>Intent of use;</li>
<li>Manner of use;</li>
<li>Time frame of use; and</li>
<li>Identity of the user.</li>
</ul>
<p> NEA reserves the right to refuse permission without declaring reason(s) and/or if the information submitted by the user is deemed insufficient.</p>
<p> 4.3 You may use, hyperlink, copy and distribute the Contents solely for personal, internal, non-commercial or informational purposes only. You may download one copy of any information provided in this Site onto a single computer for your own personal, non-commercial use provided that you keep intact all accompanying copyright and other proprietary notices. You may not display, distribute or otherwise use any of the Content for any commercial purpose unless you receive specific written consent from MSS.</p>
<p> 4.4 Modification of any of the Contents or use of the Contents without MSS’ written permission or for any other purpose outside the scope of MSS’ permission will be a violation of MSS’ copyright and other intellectual property rights. Graphics and images on this Site are protected by copyright and may not be reproduced or appropriated in any manner without the prior written permission of MSS and/or their respective copyright owners.</p>
<p> 4.5 The design and layout of this website is protected by intellectual property and other laws and may not be copied or imitated in whole or in part. No logo, graphic, sound, image or search engine from this website may be copied or transmitted unless expressly permitted by MSS.</p>
<ol start="5">
<li><strong> DISCLAIMER OF WARRANTIES AND LIABILITY</strong></li>
</ol>
<p> 5.1 The Contents of this Site are provided on an “as is” basis without warranties of any kind. While MSS has made every reasonable effort to ensure that the information contained in this website has been obtained from reliable sources, MSS shall not be responsible for any errors or omissions, or for the results obtained from the use of such information.</p>
<p> 5.2 To the fullest extent permitted by law, MSS does not warrant and hereby disclaims any warranty:</p>
<ul>
<li>as to the accuracy, correctness, reliability, timeliness, availability, completeness, suitability, non-infringement, title, merchantability or fitness for any particular purpose of the Contents of this Site; and</li>
<li>that the Contents available through this Site or any functions associated therewith will be uninterrupted or error-free, or that defects will be corrected or that this Site and the server is and will be free of all viruses and/or other harmful elements.</li>
</ul>
<p> 5.3 MSS shall also not be liable for any damage or loss of any kind howsoever caused as a result (direct or indirect) of the use of this Site, including but not limited to any damage or loss suffered as a result of reliance on the Contents contained in or available from this Site.</p>
<p> 5.4 This Site includes real-time data collected from automated weather observation systems. For expediency in delivery, these data would only have undergone basic quality checks. There could be instances when there are gaps in the data due to disruptions in telecommunications or equipment failure, and MSS shall not liable for any missing data.</p>
<p> 5.5 Certain products on this Site are derived from external sources such as the Japan Meteorological Agency (JMA), National Oceanic and Atmospheric Administration (NOAA) and the National Aeronautics and Space Administration (NASA) of the USA. In addition to the Terms of Use of this Site, the use of data may be subject to the terms imposed by the relevant external agencies.</p>
<p> The information provided herein is to give a better understanding of the user&#8217;s obligations and do not constitute professional or legal advice. While every effort is made to ensure that the Contents herein are consistent with existing law and practice, members of the public are advised to refer to the relevant legislation or to professional advice to be certain of their legal obligations.</p>
<ol start="6">
<li><strong> RIGHT OF ACCESS</strong></li>
</ol>
<p> 6.1 MSS reserves all rights to deny or restrict access to this Site to any particular person, or to block access from a particular Internet address to this Site, at any time, without ascribing any reasons whatsoever.</p>
<p> 6.2 You unconditionally agree that you will not:</p>
<ul>
<li>use any robot, spider, other automatic device, or manual process to monitor or copy any pages within this website or the Contents without NEA’s prior written permission;</li>
<li>use any device, software or routine to interfere or attempt to interfere with the proper working of this Site; or</li>
<li>take any action that imposes an unreasonable or disproportionately large load on MSS’ servers.</li>
</ul>
<ol start="7">
<li><strong> LINKS FROM THIS SITE TO OTHER WEBSITES</strong></li>
</ol>
<p> 7.1 This Site contains hyperlinks to websites which are not maintained by MSS nor controlled by MSS. MSS shall not be responsible for the contents of these websites and shall not be liable for any damages or loss arising from access to those websites. Use of the hyper-links and access to such websites are entirely at your own risk.</p>
<p> 7.2 All hyperlinks to other websites are provided as a convenience to you as a user of the Site. The inclusion of any hyperlink shall not imply the endorsement by MSS of the hyperlinked website. In no circumstances shall MSS be considered to be associated or affiliated in whatever manner with any trade or service marks, logos, insignia or other devices used or appearing on websites to which this Site is linked.</p>
<ol start="8">
<li><strong> LINKS TO THIS SITE FROM OTHER WEBSITES</strong></li>
</ol>
<p> 8.1 Except as set forth below, caching and links to, and the framing of this Site or any of the Contents are prohibited:</p>
<p> Linking to the Homepage: You may link to the Homepage of this Site, upon notifying NEA in writing.</p>
<p> Hyperlinking to an internal page of this Site: You must make a specific request for, and secure permission from MSS prior to hyperlinking to, or framing, this Site or any of the Contents, or engaging in similar activities.</p>
<p> 8.2 MSS reserves the right to impose conditions when permitting any hyperlinking to, or framing of this Site or any of the Contents.</p>
<p> 8.3 Your linking to, or your framing of this Site or any of the Contents will constitute acceptance of these Terms of Use. This is deemed to be the case even after the posting of any changes or modifications to these Terms of Use. If you do not accept these Terms of Use, you must discontinue linking to, or framing of this Site or any of the Contents.</p>
<p> 8.4 Under no circumstances shall MSS be considered to be associated or affiliated in whatever manner with any trade or service marks, logos, insignia or other devices used or appearing on websites that link to this Site or any of the Contents.</p>
<p> 8.5 MSS reserves all rights to disable any links to, or frames of any site containing inappropriate, profane, defamatory, infringing, obscene, indecent or unlawful topics, names, material or information, or material or information that violates any written law, any applicable intellectual property, proprietary, privacy or publicity rights.</p>
<p> 8.6 MSS reserves the right to disable any unauthorised links or frames and disclaims any responsibility for the content available on any other website reached by links to or from this Site or any of the Contents.</p>
<ol start="9">
<li><strong> GOVERNING LAW</strong></li>
</ol>
<p> 9.1 These Terms of Use shall be governed and construed in accordance with the laws of the Republic of Singapore.</p>
<p> &nbsp;
 </p></div>
</div>
</div>
</div>
						<!-- .entry-content -->
		<footer class="entry-meta">
					</footer><!-- .entry-meta -->


			
        </div>
        <!--
	</div><!-- #main .wrapper 
	<footer id="colophon" role="contentinfo">
		<div class="site-info">
						<a href="http://wordpress.org/" title="Semantic Personal Publishing Platform">Proudly powered by WordPress</a>
		</div><!-- .site-info 
	</footer><!-- #colophon 
</div><!-- #page -->

<!-- Footer -->
<footer>
  <div class="container">
    <div class="footer-top">
      <div class="row">

        <div style="width:27%;float:left;padding-left:10px;">
          <h5 class="donotresize">Transboundary Haze</h5>
          <div class="row">
            <div class="col-12">
              <ul class="list-unstyled donotresize">
                <li class="donotresize">
                  <ul class="list-unstyled">
                    <li><a class="donotresize" href="https://asmc.asean.org/asmc-alerts/">Warnings and Alerts</a></li>
                    <li><a class="donotresize" href='#' id='hazeTagReviewLink'>Haze Review</a></li>
                    <li><a class="donotresize" href="https://asmc.asean.org/satellite-polar/">Satellite Images</a></li>
                    <li><a class="donotresize" href="https://asmc.asean.org/asmc-hotspot/">Hotspot Information</a></li>
                    <li><a class="donotresize" href="https://asmc.asean.org/asmc-gis-portal/">Haze Information Portal</a></li>
                    <!-- <li><a class="donotresize" href="https://asmc.asean.org/asmc-haze-air-quality/">Air Quality Information</a></li> -->
                    <li><a class="donotresize" href="https://asmc.asean.org/asmc-fire/">Fire Danger Rating System</a></li>
                  </ul>
                </li>
              </ul>
            </div>
          </div>
        </div>

        <div style="width:15%;float:left;padding-left:10px;">
          <h5 class="donotresize">Weather</h5>
          <div class="row">
            <div class="col-12">
              <ul class="list-unstyled donotresize">
                <li class="donotresize">
                  <ul class="list-unstyled">
                    <li><a class="donotresize" href="https://asmc.asean.org/asmc-regional-weather-observation/">Regional Weather</a></li>
                    <li><a class="donotresize" href='#' id='footWeatherOutlookLink'>Subseasonal Weather Outlook and Review</a></li>
                  </ul>
                </li>
              </ul>
            </div>
          </div>
        </div>

        <div style="width:15%;float:left;padding-left:10px;">
          <h5 class="donotresize">Climate</h5>
          <div class="row">
            <div class="col-12">
              <ul class="list-unstyled donotresize">
                <li class="donotresize">
                  <ul class="list-unstyled">
                    <li><a class="donotresize" href="https://asmc.asean.org/asmc-seasonal-outlook/">Seasonal Forecast (1-month and 3-month outlook)</a></li>
                    <li><a class="donotresize" href="https://asmc.asean.org/asmc-el-nino/">El Niño / La Niña</a></li>
                  </ul>
                </li>
              </ul>
            </div>
          </div>
        </div>

        <div style="width:25%;float:left;padding-left:10px;">
          <h5 class="donotresize">Events & Publications</h5>
          <div class="row">
            <div class="col-12">
              <ul class="list-unstyled donotresize">
                <li class="donotresize">
                  <ul class="list-unstyled">
                    <li><a class="donotresize" href='#' id="footEventsLink">Events</a></li>
                    <li><a class="donotresize" href='#' id="footPublicationsLink">Publication</a></li>
                  </ul>
                </li>
              </ul>
            </div>
          </div>
        </div>

        <div style="width:18%;float:left;padding-left:10px;">
          <ul class="list-unstyled title-list donotresize">
            <li><a class="donotresize" href="https://wis2.asmc.asean.org">Data Catalog</a></li>
            <li><a class="donotresize" href="https://asmc.asean.org/asmc-about/">About</a></li>
            <!-- <li><a href="https://asmc.asean.org/asmc-faq/">FAQs</a></li> -->
            <li><a class="donotresize" href="https://asmc.asean.org/asmc-contact-us/">Contact Us</a></li>
            <li>Follow us on <a class="donotresize" href="https://asmc.asean.org/feed/"><img width="22" height="21" alt="RSS" src="https://asmc.asean.org/wp-content/themes/asmctheme/assets/img/icon-rss.png"></a></li>
          </ul>
        </div>
      </div>
    </div>
    <!-- / .footer-top -->

    <div class="footer-bottom">
      <div class="row">
        <div class="col-6">
          <ul class="list-inline donotresize" style="width: max-content">
            <li class="list-inline-item"><a class="donotresize" href="https://asmc.asean.org/terms-of-use/">Terms &amp; Conditions</a></li>
            <li class="list-inline-item"><span>|</span></li>
            <li class="list-inline-item"><a class="donotresize" href="https://asmc.asean.org/privacy-statement/">Privacy Policy</a></li>
            <li class="list-inline-item"><span>|</span></li>
            <li class="list-inline-item"><a class="donotresize" href="https://asmc.asean.org/asmc-supported-browsers/">Supported Browsers</a></li>
            <li class="list-inline-item"><span>|</span></li>
            <li class="list-inline-item"><a class="donotresize" href="https://www.tech.gov.sg/report_vulnerability">Report Vulnerability</a></li>
          </ul>
        </div>
        <div class="col-6">
          <p class="text-end copyright donotresize">&copy;2026 ASEAN Specialised Meteorological Centre</p>
        </div>
      </div>
    </div>
    <!-- / .footer-bottom -->
  </div>
</footer>
<script type="text/javascript" src="https://asmc.asean.org/wp-includes/js/comment-reply.min.js?ver=6.5.12" id="comment-reply-js" async="async" data-wp-strategy="async"></script>
<script type="text/javascript" src="https://asmc.asean.org/wp-content/themes/asmctheme/js/navigation.js?ver=20140711" id="twentytwelve-navigation-js"></script>
<script src="https://asmc.asean.org/wp-content/themes/asmctheme/js/function_resizer.js" id="resizeFunction" type="text/javascript"></script>
<script type="text/javascript">
  $('#headEventsLink').click(function(){
    deleteCookieCategoryName();
    window.location.href = 'https://asmc.asean.org/events-twenty-sixth-session-of-the-asean-climate-outlook-forum-aseancof-26/';
  });
  $('#headPublicLink').click(function(){
    deleteCookieCategoryName();
    window.location.href = 'https://asmc.asean.org/asmc-annual-report-2025-2026/';
  });
  $('#headWeatherOutlookLink').click(function(){
    deleteCookieCategoryName();
    window.location.href = 'https://asmc.asean.org/subseasonal-weather-outlook-12-25-october-2026/';
  });
  $('#headHazeOutlookLink').click(function(){
    deleteCookieCategoryName();
    window.location.href = 'https://asmc.asean.org/haze-outlook-for-land-fires-and-smoke-haze-situation-16-31-january-2020/';
  });
  $('#weatherTagOutlookLink').click(function(){
    deleteCookieCategoryName();
    window.location.href = 'https://asmc.asean.org/subseasonal-weather-outlook-12-25-october-2026/';
  });
  $('#weatherTagReviewLink').click(function(){
    deleteCookieCategoryName();
    window.location.href = 'https://asmc.asean.org/subseasonal-weather-review-of-regional-weather-for-september-2026/';
  });
  $('#hazeTagOutlookLink').click(function(){
    deleteCookieCategoryName();
    window.location.href = 'https://asmc.asean.org/haze-outlook-for-land-fires-and-smoke-haze-situation-16-31-january-2020/';
  });
  $('#hazeTagReviewLink').click(function(){
    deleteCookieCategoryName();
    window.location.href = 'https://asmc.asean.org/review-of-regional-haze-situation-for-august-2026/';
  });
  $('.breadcrumb').find('*').click(function(){
    deleteCookieCategoryName();
  });

  $('#footEventsLink').click(function(){
    deleteCookieCategoryName();
    window.location.href = 'https://asmc.asean.org/events-twenty-sixth-session-of-the-asean-climate-outlook-forum-aseancof-26/';
  });
  $('#footPublicationsLink').click(function(){
    deleteCookieCategoryName();
    window.location.href = 'https://asmc.asean.org/asmc-annual-report-2025-2026/';
  });
  $('#footWeatherOutlookLink').click(function(){
    deleteCookieCategoryName();
    document.cookie="weatherOutlook=active;path=/";
    document.cookie="weatherReview=inactive;path=/";
    window.location.href = 'https://asmc.asean.org/subseasonal-weather-outlook-12-25-october-2026/';
  });
  $('#footHazeOutlookLink').click(function(){
    deleteCookieCategoryName();
    document.cookie="hazeOutlook=active;path=/";
    document.cookie="hazeReview=inactive;path=/";
    window.location.href = 'https://asmc.asean.org/haze-outlook-for-land-fires-and-smoke-haze-situation-16-31-january-2020/';
  });

</script>

</body>
</html>
<!-- Dynamic page generated in 0.226 seconds. -->
<!-- Cached page generated by WP-Super-Cache on 2026-10-23 09:58:56 -->

<!-- super cache -->