HTTP/1.1 200 Connection Established

HTTP/2 200 
server: nginx
date: Fri, 23 Oct 2026 19:57:51 GMT
content-type: text/html; charset=utf-8
vary: RSC, Next-Router-State-Tree, Next-Router-Prefetch, Next-Router-Segment-Prefetch, Accept-Encoding
x-nextjs-cache: HIT
x-nextjs-prerender: 1
x-nextjs-stale-time: 4294967294
x-powered-by: Next.js
cache-control: s-maxage=31536000
etag: "14d6f3bxqwg9a"
content-encoding: gzip
x-kong-upstream-latency: 3
x-kong-proxy-latency: 1
via: kong/3.7.1
x-kong-request-id: 085bcf19db52694e6553750ca47d4b36

