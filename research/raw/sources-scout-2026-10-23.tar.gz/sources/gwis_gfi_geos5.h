HTTP/1.1 200 Connection Established

HTTP/2 200 
date: Fri, 23 Oct 2026 20:06:42 GMT
content-type: text/plain; charset=UTF-8
content-length: 383
accept-ranges: bytes
access-control-allow-origin: *
cache-control: public, max-age=3600
expires: Fri, 23 Oct 2026 21:06:42 GMT
server: lighttpd/1.4.74

