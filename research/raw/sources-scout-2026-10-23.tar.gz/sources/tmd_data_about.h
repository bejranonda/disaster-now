HTTP/1.1 302 Found
date: Fri, 23 Oct 2026 20:07:26 GMT
content-type: text/html; charset=UTF-8
location: https://data.tmd.go.th/api/about.php
server: cloudflare
x-powered-by: ASP.NET
access-control-allow-origin: https://wxmap.tmd.go.th
access-control-allow-methods: GET, OPTIONS
access-control-allow-headers: Content-Type
access-control-allow-private-network: true
cf-cache-status: DYNAMIC
transfer-encoding: chunked

HTTP/1.1 200 Connection Established

HTTP/2 200 
date: Fri, 23 Oct 2026 20:07:28 GMT
content-type: text/html
vary: Accept-Encoding
server: cloudflare
x-powered-by: PHP/5.3.28
x-powered-by: ASP.NET
access-control-allow-origin: https://wxmap.tmd.go.th
access-control-allow-methods: GET, OPTIONS
access-control-allow-headers: Content-Type
access-control-allow-private-network: true
cf-cache-status: DYNAMIC
content-encoding: gzip

