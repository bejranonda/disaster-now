HTTP/1.1 200 Connection Established

HTTP/2 200 
date: Fri, 23 Oct 2026 20:06:17 GMT
content-type: application/vnd.google-earth.kml+xml
content-length: 248105
access-control-allow-origin: https://asmc.asean.org
last-modified: Fri, 23 Oct 2026 08:50:15 GMT
etag: "3c929-65e7e11a34ae0"
cache-control: public, max-age=180
x-frame-options: SAMEORIGIN
strict-transport-security: max-age=31536000; includeSubDomains
x-content-type-options: nosniff
referrer-policy: no-referrer
content-security-policy: frame-src 'self' *.youtube.com *.asmc.asean.org *.google.com; 			frame-ancestors 'self' https://asmc.asean.org *.google.com; 			script-src 'self' *.google.com *.adobedtm.com *.youtube.com https://*.gstatic.com *.wogaa.sg *.google-analytics.com *.googleapis.com *.googletagmanager.com cdnjs.cloudflare.com 'unsafe-inline' 'unsafe-eval'; 			object-src https://asmc.asean.org; 			font-src 'self' 'unsafe-inline' 'unsafe-eval' data: https://assets.wogaa.sg/fonts/ https://fonts.gstatic.com https://*.googleapis.com https://maxcdn.bootstrapcdn.com; 			style-src 'self' 'unsafe-inline' 'unsafe-eval' https://*.wogaa.sg https://asmc.asean.org/ https://*.googleapis.com https://maxcdn.bootstrapcdn.com fonts.bunny.net; 			connect-src 'self' *.google.com *.adobedtm.com *.youtube.com *.wogaa.sg *.google-analytics.com *.googleapis.com *.googletagmanager.com https://asmc.asean.org; 			default-src 'self' https://*.wogaa.sg https://asmc.asean.org https://www.google-analytics.com https://www.googletagmanager.com s.w.org; 			img-src	'self' data: https://maps.gstatic.com https://*.googleapis.com https://cdn.amcharts.com https://*.googleusercontent.com https://asmc.asean.org https://www.weather.gov.sg
vary: User-Agent,Origin
x-azure-ref: 20261023T200617Z-r19f94f7f95k9c75hC1DTTttms00000004tg000000007c2x
x-fd-int-roxy-purgeid: 0
x-cache-info: L2_T2
accept-ranges: bytes

