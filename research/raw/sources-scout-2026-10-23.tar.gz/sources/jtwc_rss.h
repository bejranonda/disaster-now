HTTP/1.1 200 Connection Established

HTTP/2 200 
content-type: application/rss+xml
content-length: 6768
server: N/A
date: Fri, 23 Oct 2026 19:54:41 GMT
access-control-allow-origin: *
access-control-allow-methods: GET, HEAD
access-control-expose-headers: ETag
access-control-max-age: 1800
last-modified: Fri, 23 Oct 2026 19:54:20 GMT
etag: "22b1c48468dcf36f8ef89bab1f320086"
x-amz-server-side-encryption: AES256
x-amz-version-id: L8DYG8conlUqaicEI36m5ze4GhgS1dvH
accept-ranges: bytes
vary: Origin
via: 1.1 1ac532da7db85d551ad10ca7bd9957b8.cloudfront.net (CloudFront)
x-amz-cf-pop: IAD61-P1
x-amz-cf-id: ouaLGaYZq8DiBuUQj05-eJ4dqyqzZ-ocZp1bjIyxKJtFKZs-WBj6_Q==
x-xss-protection: 1; mode=block
x-frame-options: SAMEORIGIN
referrer-policy: same-origin
content-security-policy: frame-ancestors 'self'
x-content-type-options: nosniff
strict-transport-security: max-age=31536000; includeSubDomains; preload

