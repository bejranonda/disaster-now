<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
  
    
  
    <link rel="alternate" type="application/rss+xml" href="/rss.xml" />
    
    <link rel="shortcut icon" type="image/ico" href="https://a0.awsstatic.com/libra-css/images/site/fav/favicon.ico"/>
    <link rel="apple-touch-icon" sizes="57x57" href="https://a0.awsstatic.com/libra-css/images/site/touch-icon-iphone-114-smile.png"/>
    <link rel="apple-touch-icon" sizes="72x72" href="https://a0.awsstatic.com/libra-css/images/site/touch-icon-ipad-144-smile.png"/>
    <link rel="apple-touch-icon" sizes="114x114" href="https://a0.awsstatic.com/libra-css/images/site/touch-icon-iphone-114-smile.png"/>
    <link rel="apple-touch-icon" sizes="144x144" href="https://a0.awsstatic.com/libra-css/images/site/touch-icon-ipad-144-smile.png"/>  
  
    <title>NASA Landslide Project Project - Registry of Open Data on AWS</title>
  
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://assets.opendata.aws/css/bootstrap/3.4.1/bootstrap.min.css">
  
    <!-- Our local CSS -->
    <link rel="stylesheet" href="/css/main.css">
  
    <script type="application/ld+json">
    {
      "@context" : "http://schema.org",
      "@type" : "Dataset",
      "name" : "NASA Landslide Project Project",
      "description" : "The Landslide Hazard Assessment for Situational Awareness (LHASA) model identifies locations with high potential for landslide occurrence at a daily temporal resolution. LHASA combines satellite‐based precipitation estimates with a landslide susceptibility map derived from information on slope, geology, road networks, fault zones, and forest loss. When rainfall is considered to be extreme and susceptibility values are moderate to very high, a “nowcast” is issued to indicate the times and places where landslides are more probable. Although the model could be run every half hour, this archive contains a daily record derived from a retrospective model run and spatial coverage is from 60°N to 60°S .\n\u003cbr\u003e\u003ch4 id=\"global_landslide_nowcast\"\u003eGlobal_Landslide_Nowcast\u003c/h4\u003e\nThe Global Landslide Nowcast addresses the need for real-time situational awareness of landslide hazard. The Landslide Hazard Assessment for Situational Awareness model (LHASA) combines satellite rainfall estimates from the Global Precipitation Measurement mission (GPM) with soil moisture estimates from the Soil Moisture Active Passive (SMAP) satellite and other factors to produce a map of locations where rainfall-triggered landslide activity is probable. Due to the latency of the rainfall data, the nowcast is a near-real time product with a minimum latency of 5 hours. Although the model could be run every half hour, this archive contains a daily record derived from a retrospective model run. The Global Landslide Nowcast version 2.0.0 retains replaces the heuristic decision tree from version 1.0 with a machine learning model. Instead of merging all factors other than precipitation into a susceptibility map, LHASA 2.0 takes in each variable as a separate input layer. The most important change is the replacement of the categorical nowcast with a probabilistic output. This will enable users to adjust the threshold to suit their specific application and geographic location.\n\u003cbr\u003e\u003ch4 id=\"data-discovery\"\u003eData Discovery\u003c/h4\u003e\nExplore this data using NASA\u0026#39;s \u003ca href=\"https://search.earthdata.nasa.gov/\"\u003eEarthdata Search\u003c/a\u003e, a comprehensive tool for discovering and visualizing Earth science datasets.\n\u003cbr\u003e\u003ch4 id=\"data-access\"\u003eData Access\u003c/h4\u003e\nAccess requires an \u003ca href=\"https://urs.earthdata.nasa.gov/\"\u003eEarthdata Login\u003c/a\u003e account. \u003ca href=\"https://data.gesdisc.earthdata.nasa.gov/s3credentialsREADME\"\u003eRead our guide on obtaining AWS credentials\u003c/a\u003e to retrieve this data from AWS.\n\u003cbr\u003e\u003cbr\u003e",
      "license" : "\u003ca href=\"https://creativecommons.org/licenses/by/4.0/\"\u003eCreative Commons BY 4.0\u003c/a\u003e",
      "sourceOrganization" : "NASA"
    }
    </script>
  
  </head>
  <body>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://assets.opendata.aws/js/jquery/3.5.1/jquery.min.js"></script>
    <!-- Latest compiled and minified JavaScript -->
    <script src="https://assets.opendata.aws/js/bootstrap/3.4.1/bootstrap.min.js"></script>
    <nav class="navbar navbar-default navbar-fixed-top">
      <div class="container">
        <div class="roda-header">
          <h2><a href="/" alt="Home">Registry of Open Data on AWS</a></h2>
          <a href="http://aws.amazon.com/what-is-cloud-computing">
            <img src="https://assets.opendata.aws/img/AWS-Logo_White-Color_300x180.png" alt="Powered by AWS Cloud Computing" id="aws_header_logo">
          </a>
        </div>
      </div>
    </nav>
    <div class="container" >

    <h1>NASA Landslide Project Project</h1>
    <p>
      

      <span class="label label-info tag link-tag">precipitation</span>

      <span class="label label-info tag link-tag">satellite imagery</span>

      <span class="label label-info tag link-tag">soil moisture</span>
    </p>
    <div class="row">
      <div class="col-md-6">
      <h3>Description</h3>
      <p>The Landslide Hazard Assessment for Situational Awareness (LHASA) model identifies locations with high potential for landslide occurrence at a daily temporal resolution. LHASA combines satellite‐based precipitation estimates with a landslide susceptibility map derived from information on slope, geology, road networks, fault zones, and forest loss. When rainfall is considered to be extreme and susceptibility values are moderate to very high, a “nowcast” is issued to indicate the times and places where landslides are more probable. Although the model could be run every half hour, this archive contains a daily record derived from a retrospective model run and spatial coverage is from 60°N to 60°S .
<br><h4 id="global_landslide_nowcast">Global_Landslide_Nowcast</h4>
The Global Landslide Nowcast addresses the need for real-time situational awareness of landslide hazard. The Landslide Hazard Assessment for Situational Awareness model (LHASA) combines satellite rainfall estimates from the Global Precipitation Measurement mission (GPM) with soil moisture estimates from the Soil Moisture Active Passive (SMAP) satellite and other factors to produce a map of locations where rainfall-triggered landslide activity is probable. Due to the latency of the rainfall data, the nowcast is a near-real time product with a minimum latency of 5 hours. Although the model could be run every half hour, this archive contains a daily record derived from a retrospective model run. The Global Landslide Nowcast version 2.0.0 retains replaces the heuristic decision tree from version 1.0 with a machine learning model. Instead of merging all factors other than precipitation into a susceptibility map, LHASA 2.0 takes in each variable as a separate input layer. The most important change is the replacement of the categorical nowcast with a probabilistic output. This will enable users to adjust the threshold to suit their specific application and geographic location.
<br><h4 id="data-discovery">Data Discovery</h4>
Explore this data using NASA&#39;s <a href="https://search.earthdata.nasa.gov/">Earthdata Search</a>, a comprehensive tool for discovering and visualizing Earth science datasets.
<br><h4 id="data-access">Data Access</h4>
Access requires an <a href="https://urs.earthdata.nasa.gov/">Earthdata Login</a> account. <a href="https://data.gesdisc.earthdata.nasa.gov/s3credentialsREADME">Read our guide on obtaining AWS credentials</a> to retrieve this data from AWS.
<br><br></p>

      <h4>Update Frequency</h4>
      <p>Varies by dataset</p>

      <h4>License</h4>
      <p><a href="https://creativecommons.org/licenses/by/4.0/">Creative Commons BY 4.0</a></p>

      <h4>Documentation</h4>
      <p><a href="https://landslides.nasa.gov/">https://landslides.nasa.gov/</a></p>

      <h4>Managed By</h4>
      <p><a href=""><img src="/img/logos/nasa-logo.png" class="managed-by-logo" alt=""></a></p>
      <p>See all datasets managed by <a href="https://registry.opendata.aws/collab/nasa">NASA</a>.</p>

      <h4>Contact</h4>
      <p><a href="https://earthdata.nasa.gov/contact">https://earthdata.nasa.gov/contact</a></p>

      <h4>How to Cite</h4>
      <p>NASA Landslide Project Project was accessed on <code>DATE</code> from https://registry.opendata.aws/nasa-landslide-project. </p>


    </div>
    <div class="col-md-5 col-md-offset-1">
      <h3>Resources on AWS</h3>
      <ul class="resource-list">
        <li>
          <dl class="resource-list">
            <dt class="resource-description">Description</dt>
            <dd class="resource-description">Global_Landslide_Nowcast v1.1 - The Landslide Hazard Assessment for Situational Awareness (LHASA) model identifies locations with high potential for landslide occurrence at a daily temporal resolution. LHASA combines satellite‐based precipitation estimates with a landslide susceptibility map derived from information on slope, geology, road networks, fault zones, and forest loss.</dd>
            <dt class="resource-type">Resource type</dt>
            <dd class="resource-type s3-bucket">S3 Bucket <a href="https://data.gesdisc.earthdata.nasa.gov/s3credentials"><span class="label label-info tag link-tag">Controlled Access</span></a></dd>
            <dt class="resource-arn">Amazon Resource Name (ARN)</dt>
            <dd><code>arn:aws:s3:::gesdisc-cumulus-prod-protected/Landslide/Global_Landslide_Nowcast.1.1</code></dd>
            <dt class="resource-region">AWS Region</dt>
            <dd><code>us-west-2</code></dd>
          </dl>
        </li>
        <li>
          <dl class="resource-list">
            <dt class="resource-description">Description</dt>
            <dd class="resource-description">Global_Landslide_Nowcast v2.0.0 - The Global Landslide Nowcast addresses the need for real-time situational awareness of landslide hazard. The Landslide Hazard Assessment for Situational Awareness model (LHASA) combines satellite rainfall estimates from the Global Precipitation Measurement mission (GPM) with soil moisture estimates from the Soil Moisture Active Passive (SMAP) satellite and other factors to produce a map of locations where rainfall-triggered landslide activity is probable.</dd>
            <dt class="resource-type">Resource type</dt>
            <dd class="resource-type s3-bucket">S3 Bucket <a href="https://data.gesdisc.earthdata.nasa.gov/s3credentials"><span class="label label-info tag link-tag">Controlled Access</span></a></dd>
            <dt class="resource-arn">Amazon Resource Name (ARN)</dt>
            <dd><code>arn:aws:s3:::gesdisc-cumulus-prod-protected/Landslide/Global_Landslide_Nowcast.2.0.0</code></dd>
            <dt class="resource-region">AWS Region</dt>
            <dd><code>us-west-2</code></dd>
          </dl>
        </li>
      </ul>
    </div>
  </div>

    <hr/>
    <p><a href="https://github.com/awslabs/open-data-registry/blob/main/datasets/nasa-landslide-project.yaml">Edit this dataset entry on GitHub</a></p>
    <p><a href="mailto:opendata@amazon.com">Tell us about your project</a></p>
    <p><a href="/"><b>Home</b></a></p>
  </div>
  <script src="/js/tags.js"></script>
