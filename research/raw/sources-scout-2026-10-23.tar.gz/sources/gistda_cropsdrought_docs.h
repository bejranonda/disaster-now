HTTP/1.1 200 Connection Established

HTTP/2 200 
server: nginx
date: Fri, 23 Oct 2026 19:58:21 GMT
content-type: text/html; charset=utf-8
x-content-type-options: nosniff
x-frame-options: DENY
x-xss-protection: 1; mode=block
vary: rsc, next-router-state-tree, next-router-prefetch, next-router-segment-prefetch, Accept-Encoding
x-nextjs-cache: HIT
x-nextjs-prerender: 1
x-nextjs-prerender: 1
x-nextjs-stale-time: 300
cache-control: s-maxage=31536000
content-encoding: gzip
strict-transport-security: max-age=31536000; includeSubDomains; preload
x-cdn: Imperva
x-iinfo: 37-33378301-33255199 pNNN RT(1792785501657 99) q(0 0 0 15) r(4 4) U12

