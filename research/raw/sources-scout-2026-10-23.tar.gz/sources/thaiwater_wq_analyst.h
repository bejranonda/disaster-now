HTTP/1.1 200 Connection Established

HTTP/2 200 
access-control-allow-credentials: true
access-control-allow-headers: Accept, Content-Type, Content-Length, Accept-Encoding, X-CSRF-Token, Authentication, X-Debug, Accept-Language, X-Language
access-control-allow-methods: POST, GET, OPTIONS, PUT, DELETE, PATCH
access-control-allow-origin: https://disaster-now.example
access-control-expose-headers: Link
access-control-max-age: 600
content-encoding: gzip
content-type: application/json; charset=utf-8
date: Fri, 23 Oct 2026 20:04:22 GMT
strict-transport-security: max-age=63072000
x-frame-options: SAMEORIGIN
x-content-type-options: nosniff

