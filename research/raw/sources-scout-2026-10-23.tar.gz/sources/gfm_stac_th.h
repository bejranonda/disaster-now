HTTP/1.1 200 Connection Established

HTTP/2 200 
access-control-allow-credentials: true
access-control-allow-origin: https://disaster-now.example
access-control-expose-headers: Location,Www-Authenticate,ETag,Expires,Last-Modified,Cache-Control,Content-Type
content-encoding: br
content-type: application/geo+json
date: Fri, 23 Oct 2026 19:59:31 GMT
server: uvicorn
vary: Accept-Encoding,Origin
content-length: 11660

