HTTP/1.1 200 Connection Established

HTTP/2 200 
cache-control: private, must-revalidate, max-age=0
content-type: application/json;charset=UTF-8
content-encoding: gzip
etag: 1d85729e
vary: Origin
server: Microsoft-IIS/10.0
x-content-type-options: nosniff
x-xss-protection: 1; mode=block
access-control-allow-origin: https://disaster-now.example
access-control-allow-credentials: true
server: 
x-aspnet-version: 4.0.30319
x-powered-by: ASP.NET
date: Fri, 23 Oct 2026 20:02:42 GMT
content-length: 423

