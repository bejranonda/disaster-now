HTTP/1.1 200 Connection Established

HTTP/2 200 
date: Fri, 23 Oct 2026 19:55:46 GMT
content-type: text/xml
cache-control: public,max-age=60
content-encoding: br
content-language: th-TH
vary: Accept-Encoding
x-content-type-options: nosniff
server: elb

