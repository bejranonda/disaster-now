HTTP/1.1 200 Connection Established

HTTP/2 200 
content-type: application/json
cache-control: public, max-age=30
access-control-allow-origin: https://disaster-now.example
access-control-allow-credentials: true
vary: Origin
x-cloud-trace-context: 046be98670adb7608b9983b229430410;o=1
date: Fri, 23 Oct 2026 20:11:34 GMT
server: Google Frontend
content-length: 340

