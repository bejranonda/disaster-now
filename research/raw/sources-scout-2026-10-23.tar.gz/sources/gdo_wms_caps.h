HTTP/1.1 200 Connection Established

HTTP/2 200 
date: Fri, 23 Oct 2026 20:01:02 GMT
content-type: text/xml; charset=utf-8
access-control-allow-origin: *
access-control-allow-headers: Authorization
access-control-allow-methods: GET
access-control-expose-headers: Content-Security-Policy, Location
access-control-max-age: 600
cache-control: no-cache, private
x-ratelimit-limit: 60
x-ratelimit-remaining: 59
vary: Accept-Encoding
content-encoding: gzip
x-azure-ref: 20261023T200102Z-r19dbdbfcd5xr7d6hC1DTT0f8800000005kg000000004th6
x-fd-int-roxy-purgeid: 66551398

