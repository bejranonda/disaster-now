GetFeatureInfo results:

Layer 'nasa_geos5.query'
  Feature 0: 
    x = '99.0625'
    y = '18.75'
    value_0 = '0.00010104713'
    value_1 = '20.978769'
    value_2 = '2.2988012'
    value_3 = '73.571014'
    value_4 = '0.00025113276'
    value_5 = '4.264482'
    value_list = '0.00010104713,20.978769,2.2988012,73.571014,0.00025113276,4.264482'
    red = '0'
    green = '20'
    blue = '2'
