<?xml version="1.0" encoding="UTF-8"?>
<ColorMaps xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
           xsi:noNamespaceSchemaLocation="http://gibs.earthdata.nasa.gov/schemas/ColorMap_v1.3.xsd">
  <ColorMap title="Water Product">
    <Entries>
      <ColorMapEntry rgb="0,0,0" transparent="true" nodata="true" ref="0"/>
      <ColorMapEntry rgb="0,0,1" transparent="true" sourceValue="0" ref="1"/>
      <ColorMapEntry rgb="50,210,245" transparent="false" sourceValue="1" ref="2"/>
      <ColorMapEntry rgb="255,255,0" transparent="false" sourceValue="2" ref="3"/>
      <ColorMapEntry rgb="250,30,36" transparent="false" sourceValue="3" ref="4"/>
      <ColorMapEntry rgb="175,175,175" transparent="false" sourceValue="255" ref="5"/>
    </Entries>
    <Legend type="classification">
      <LegendEntry rgb="0,0,1" tooltip="No Water" id="1"/>
      <LegendEntry rgb="50,210,245" tooltip="Surface Water" id="2"/>
      <LegendEntry rgb="255,255,0" tooltip="Recurring Flood" id="3"/>
      <LegendEntry rgb="250,30,36" tooltip="Flood" id="4"/>
      <LegendEntry rgb="175,175,175" tooltip="Insufficient Data" id="5"/>
    </Legend>
  </ColorMap>
</ColorMaps>
