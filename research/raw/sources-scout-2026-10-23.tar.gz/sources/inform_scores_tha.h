HTTP/1.1 200 Connection Established

HTTP/1.1 200 OK
Cache-Control: no-cache
Pragma: no-cache
Content-Type: application/json; charset=utf-8
Expires: -1
Access-Control-Allow-Origin: *
Access-Control-Allow-Headers: Content-Type
X-Content-Security-Policy: default-src 'self'
X-Content-Type-Options: nosniff
X-XSS-Protection: 1; mode=block
Content-Security-Policy: upgrade-insecure-requests; worker-src data: blob: https: 'unsafe-inline' 'unsafe-eval'; default-src https: wss: data: 'unsafe-inline' 'unsafe-eval'
X-Frame-Options: SAMEORIGIN
Referrer-Policy: strict-origin-when-cross-origin
Permissions-Policy: camera=(), microphone=(), geolocation=(), payment=(), usb=(), interest-cohort=()
Date: Fri, 23 Oct 2026 20:07:47 GMT
Content-Length: 1177
Strict-Transport-Security: max-age=31536000; includeSubDomains; preload

