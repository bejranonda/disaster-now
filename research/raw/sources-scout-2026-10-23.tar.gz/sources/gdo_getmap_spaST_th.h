HTTP/1.1 200 Connection Established

HTTP/2 400 
date: Fri, 23 Oct 2026 20:01:25 GMT
content-type: text/html; charset=utf-8
access-control-allow-origin: *
access-control-allow-headers: Authorization
access-control-allow-methods: GET
access-control-expose-headers: Content-Security-Policy, Location
access-control-max-age: 600
cache-control: no-cache, private
x-ratelimit-limit: 60
x-ratelimit-remaining: 59
x-azure-ref: 20261023T200125Z-16c667b4cf96trf7hC1IADukag00000003yg000000002b8z
x-fd-int-roxy-purgeid: 66551398

