HTTP/1.1 200 Connection Established

HTTP/2 407 
server: nginx
date: Fri, 23 Oct 2026 19:58:05 GMT
content-type: application/json
content-length: 50
access-control-allow-origin: *
access-control-expose-headers: Content-Range,X-Request-Id
vary: Origin
x-kong-upstream-latency: 1
x-kong-proxy-latency: 0
via: kong/3.7.1
x-kong-request-id: c3973c3a11bd93517d90863f76ab9b40

