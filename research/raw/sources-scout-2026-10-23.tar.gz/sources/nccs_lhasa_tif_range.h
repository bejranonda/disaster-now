HTTP/1.1 200 Connection Established

HTTP/1.1 206 Partial Content
Date: Fri, 23 Oct 2026 20:02:30 GMT
Server: nginx/1.14.1
Strict-Transport-Security: max-age=31536000
Content-Type: image/tiff
Content-Length: 65536
Last-Modified: Fri, 23 Oct 2026 15:14:55 GMT
ETag: "6adb79ef-88fa055"
Content-Range: bytes 0-65535/143630421
Strict-Transport-Security: max-age=63072000; includeSubDomains;

