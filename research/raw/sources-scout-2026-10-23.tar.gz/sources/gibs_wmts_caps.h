HTTP/1.1 200 Connection Established

HTTP/2 200 
content-type: text/xml; charset=UTF-8
date: Fri, 23 Oct 2026 19:59:51 GMT
x-xss-protection: 1; mode=block
strict-transport-security: max-age=31536000; includeSubDomains; preload
server: ServerTokens ProductOnly
cache-control: public, max-age=1800
vary: Accept-Encoding
content-encoding: gzip
access-control-allow-origin: *
x-cache-detail: "cache miss: attempting entity save" from 172.17.0.3
x-content-type-options: nosniff
x-frame-options: SAMEORIGIN
via: 1.1 81d2bbed6d967470f490f7ed09936a1c.cloudfront.net (CloudFront)
x-amz-cf-pop: IAD61-P5
x-amz-cf-id: QhwjkZoI_Sf61xsfy33EfcNzGlA4vBH9uFR2M4njw2Nr2A0tdKj9nQ==

