HTTP/1.1 200 Connection Established

HTTP/2 200 
date: Fri, 23 Oct 2026 19:56:35 GMT
content-type: application/javascript
cache-control: public, max-age=2592000, s-maxage=31557600
content-encoding: br
content-language: th-TH
last-modified: Sun, 02 Aug 2026 17:15:58 GMT
accept-ranges: bytes
etag: "1dd22a2958bf56f"
vary: Accept-Encoding
x-content-type-options: nosniff
server: elb

