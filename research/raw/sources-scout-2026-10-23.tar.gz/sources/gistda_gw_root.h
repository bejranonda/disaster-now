HTTP/1.1 200 Connection Established

HTTP/2 301 
server: nginx
date: Fri, 23 Oct 2026 19:57:17 GMT
content-type: text/html
content-length: 79
x-kong-response-latency: 0
x-kong-request-id: db594b5eaa5e1a6427dd781624d81839

