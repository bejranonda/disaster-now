<!doctype html>
<html data-n-head-ssr lang="en" data-n-head="%7B%22lang%22:%7B%22ssr%22:%22en%22%7D%7D">
  <head >
    <title>landslide</title><meta data-n-head="ssr" charset="utf-8"><meta data-n-head="ssr" name="viewport" content="width=device-width, initial-scale=1"><meta data-n-head="ssr" data-hid="description" name="description" content="Landslide Hazard Assessment for Situational Awareness"><meta data-n-head="ssr" name="keywords" content="Landslide, Hazard Assessment, Landslide Assessment, Landslide Monitoring"><meta data-n-head="ssr" name="author" content="SERVIR MEKONG"><meta data-n-head="ssr" name="format-detection" content="telephone=no"><link data-n-head="ssr" rel="icon" type="image/x-icon" href="/favicon.ico"><link data-n-head="ssr" rel="stylesheet" href="https://unpkg.com/@material-tailwind/html@latest/styles/material-tailwind.css"><link data-n-head="ssr" rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.2/leaflet.min.css"><script data-n-head="ssr" src="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.2/leaflet.js"></script><script data-n-head="ssr" src="/js/script.js"></script><link rel="preload" href="/_nuxt/e40774e.js" as="script"><link rel="preload" href="/_nuxt/1d6c15e.js" as="script"><link rel="preload" href="/_nuxt/cd47793.js" as="script"><link rel="preload" href="/_nuxt/948513d.js" as="script"><link rel="preload" href="/_nuxt/8ed6756.js" as="script"><link rel="preload" href="/_nuxt/1e44861.js" as="script"><style data-vue-ssr-id="65b97e00:0 583f3138:0 02dc7f4f:0 855bc060:0">/*! tailwindcss v2.2.19 | MIT License | https://tailwindcss.com*/

/*! modern-normalize v1.1.0 | MIT License | https://github.com/sindresorhus/modern-normalize */

/*
Document
========
*/

/**
Use a better box model (opinionated).
*/

*,
::before,
::after {
  box-sizing: border-box;
}

/**
Use a more readable tab size (opinionated).
*/

html {
  -moz-tab-size: 4;
  -o-tab-size: 4;
     tab-size: 4;
}

/**
1. Correct the line height in all browsers.
2. Prevent adjustments of font size after orientation changes in iOS.
*/

html {
  line-height: 1.15; /* 1 */
  -webkit-text-size-adjust: 100%; /* 2 */
}

/*
Sections
========
*/

/**
Remove the margin in all browsers.
*/

body {
  margin: 0;
}

/**
Improve consistency of default fonts in all browsers. (https://github.com/sindresorhus/modern-normalize/issues/3)
*/

body {
  font-family:
		system-ui,
		-apple-system, /* Firefox supports this but not yet `system-ui` */
		'Segoe UI',
		Roboto,
		Helvetica,
		Arial,
		sans-serif,
		'Apple Color Emoji',
		'Segoe UI Emoji';
}

/*
Grouping content
================
*/

/**
1. Add the correct height in Firefox.
2. Correct the inheritance of border color in Firefox. (https://bugzilla.mozilla.org/show_bug.cgi?id=190655)
*/

hr {
  height: 0; /* 1 */
  color: inherit; /* 2 */
}

/*
Text-level semantics
====================
*/

/**
Add the correct text decoration in Chrome, Edge, and Safari.
*/

abbr[title] {
  -webkit-text-decoration: underline dotted;
          text-decoration: underline dotted;
}

/**
Add the correct font weight in Edge and Safari.
*/

b,
strong {
  font-weight: bolder;
}

/**
1. Improve consistency of default fonts in all browsers. (https://github.com/sindresorhus/modern-normalize/issues/3)
2. Correct the odd 'em' font sizing in all browsers.
*/

code,
kbd,
samp,
pre {
  font-family:
		ui-monospace,
		SFMono-Regular,
		Consolas,
		'Liberation Mono',
		Menlo,
		monospace; /* 1 */
  font-size: 1em; /* 2 */
}

/**
Add the correct font size in all browsers.
*/

small {
  font-size: 80%;
}

/**
Prevent 'sub' and 'sup' elements from affecting the line height in all browsers.
*/

sub,
sup {
  font-size: 75%;
  line-height: 0;
  position: relative;
  vertical-align: baseline;
}

sub {
  bottom: -0.25em;
}

sup {
  top: -0.5em;
}

/*
Tabular data
============
*/

/**
1. Remove text indentation from table contents in Chrome and Safari. (https://bugs.chromium.org/p/chromium/issues/detail?id=999088, https://bugs.webkit.org/show_bug.cgi?id=201297)
2. Correct table border color inheritance in all Chrome and Safari. (https://bugs.chromium.org/p/chromium/issues/detail?id=935729, https://bugs.webkit.org/show_bug.cgi?id=195016)
*/

table {
  text-indent: 0; /* 1 */
  border-color: inherit; /* 2 */
}

/*
Forms
=====
*/

/**
1. Change the font styles in all browsers.
2. Remove the margin in Firefox and Safari.
*/

button,
input,
optgroup,
select,
textarea {
  font-family: inherit; /* 1 */
  font-size: 100%; /* 1 */
  line-height: 1.15; /* 1 */
  margin: 0; /* 2 */
}

/**
Remove the inheritance of text transform in Edge and Firefox.
1. Remove the inheritance of text transform in Firefox.
*/

button,
select { /* 1 */
  text-transform: none;
}

/**
Correct the inability to style clickable types in iOS and Safari.
*/

button,
[type='button'] {
  -webkit-appearance: button;
}

/**
Remove the inner border and padding in Firefox.
*/

::-moz-focus-inner {
  border-style: none;
  padding: 0;
}

/**
Restore the focus styles unset by the previous rule.
*/

/**
Remove the additional ':invalid' styles in Firefox.
See: https://github.com/mozilla/gecko-dev/blob/2f9eacd9d3d995c937b4251a5557d95d494c9be1/layout/style/res/forms.css#L728-L737
*/

/**
Remove the padding so developers are not caught out when they zero out 'fieldset' elements in all browsers.
*/

legend {
  padding: 0;
}

/**
Add the correct vertical alignment in Chrome and Firefox.
*/

progress {
  vertical-align: baseline;
}

/**
Correct the cursor style of increment and decrement buttons in Safari.
*/

::-webkit-inner-spin-button,
::-webkit-outer-spin-button {
  height: auto;
}

/**
1. Correct the odd appearance in Chrome and Safari.
2. Correct the outline style in Safari.
*/

/**
Remove the inner padding in Chrome and Safari on macOS.
*/

::-webkit-search-decoration {
  -webkit-appearance: none;
}

/**
1. Correct the inability to style clickable types in iOS and Safari.
2. Change font properties to 'inherit' in Safari.
*/

::-webkit-file-upload-button {
  -webkit-appearance: button; /* 1 */
  font: inherit; /* 2 */
}

/*
Interactive
===========
*/

/*
Add the correct display in Chrome and Safari.
*/

summary {
  display: list-item;
}

/**
 * Manually forked from SUIT CSS Base: https://github.com/suitcss/base
 * A thin layer on top of normalize.css that provides a starting point more
 * suitable for web applications.
 */

/**
 * Removes the default spacing and border for appropriate elements.
 */

blockquote,
dl,
dd,
h1,
h2,
h3,
h4,
h5,
h6,
hr,
figure,
p,
pre {
  margin: 0;
}

button {
  background-color: transparent;
  background-image: none;
}

fieldset {
  margin: 0;
  padding: 0;
}

ol,
ul {
  list-style: none;
  margin: 0;
  padding: 0;
}

/**
 * Tailwind custom reset styles
 */

/**
 * 1. Use the user's configured `sans` font-family (with Tailwind's default
 *    sans-serif font stack as a fallback) as a sane default.
 * 2. Use Tailwind's default "normal" line-height so the user isn't forced
 *    to override it to ensure consistency even when using the default theme.
 */

html {
  font-family: ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, "Noto Sans", sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji"; /* 1 */
  line-height: 1.5; /* 2 */
}

/**
 * Inherit font-family and line-height from `html` so users can set them as
 * a class directly on the `html` element.
 */

body {
  font-family: inherit;
  line-height: inherit;
}

/**
 * 1. Prevent padding and border from affecting element width.
 *
 *    We used to set this in the html element and inherit from
 *    the parent element for everything else. This caused issues
 *    in shadow-dom-enhanced elements like <details> where the content
 *    is wrapped by a div with box-sizing set to `content-box`.
 *
 *    https://github.com/mozdevs/cssremedy/issues/4
 *
 *
 * 2. Allow adding a border to an element by just adding a border-width.
 *
 *    By default, the way the browser specifies that an element should have no
 *    border is by setting it's border-style to `none` in the user-agent
 *    stylesheet.
 *
 *    In order to easily add borders to elements by just setting the `border-width`
 *    property, we change the default border-style for all elements to `solid`, and
 *    use border-width to hide them instead. This way our `border` utilities only
 *    need to set the `border-width` property instead of the entire `border`
 *    shorthand, making our border utilities much more straightforward to compose.
 *
 *    https://github.com/tailwindcss/tailwindcss/pull/116
 */

*,
::before,
::after {
  box-sizing: border-box; /* 1 */
  border-width: 0; /* 2 */
  border-style: solid; /* 2 */
  border-color: currentColor; /* 2 */
}

/*
 * Ensure horizontal rules are visible by default
 */

hr {
  border-top-width: 1px;
}

/**
 * Undo the `border-style: none` reset that Normalize applies to images so that
 * our `border-{width}` utilities have the expected effect.
 *
 * The Normalize reset is unnecessary for us since we default the border-width
 * to 0 on all elements.
 *
 * https://github.com/tailwindcss/tailwindcss/issues/362
 */

img {
  border-style: solid;
}

textarea {
  resize: vertical;
}

input::-moz-placeholder, textarea::-moz-placeholder {
  opacity: 1;
  color: #9ca3af;
}

input::placeholder,
textarea::placeholder {
  opacity: 1;
  color: #9ca3af;
}

button {
  cursor: pointer;
}

/**
 * Override legacy focus reset from Normalize with modern Firefox focus styles.
 *
 * This is actually an improvement over the new defaults in Firefox in our testing,
 * as it triggers the better focus styles even for links, which still use a dotted
 * outline in Firefox by default.
 */

table {
  border-collapse: collapse;
}

h1,
h2,
h3,
h4,
h5,
h6 {
  font-size: inherit;
  font-weight: inherit;
}

/**
 * Reset links to optimize for opt-in styling instead of
 * opt-out.
 */

a {
  color: inherit;
  text-decoration: inherit;
}

/**
 * Reset form element properties that are easy to forget to
 * style explicitly so you don't inadvertently introduce
 * styles that deviate from your design system. These styles
 * supplement a partial reset that is already applied by
 * normalize.css.
 */

button,
input,
optgroup,
select,
textarea {
  padding: 0;
  line-height: inherit;
  color: inherit;
}

/**
 * Use the configured 'mono' font family for elements that
 * are expected to be rendered with a monospace font, falling
 * back to the system monospace stack if there is no configured
 * 'mono' font family.
 */

pre,
code,
kbd,
samp {
  font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
}

/**
 * 1. Make replaced elements `display: block` by default as that's
 *    the behavior you want almost all of the time. Inspired by
 *    CSS Remedy, with `svg` added as well.
 *
 *    https://github.com/mozdevs/cssremedy/issues/14
 * 
 * 2. Add `vertical-align: middle` to align replaced elements more
 *    sensibly by default when overriding `display` by adding a
 *    utility like `inline`.
 *
 *    This can trigger a poorly considered linting error in some
 *    tools but is included by design.
 * 
 *    https://github.com/jensimmons/cssremedy/issues/14#issuecomment-634934210
 */

img,
svg,
video,
canvas,
audio,
iframe,
embed,
object {
  display: block; /* 1 */
  vertical-align: middle; /* 2 */
}

/**
 * Constrain images and videos to the parent width and preserve
 * their intrinsic aspect ratio.
 *
 * https://github.com/mozdevs/cssremedy/issues/14
 */

img,
video {
  max-width: 100%;
  height: auto;
}

/**
 * Ensure the default browser behavior of the `hidden` attribute.
 */

[hidden] {
  display: none;
}

*, ::before, ::after{
  --tw-border-opacity:1;
  border-color:rgba(229, 231, 235, var(--tw-border-opacity));
}

.container{
  width:100%;
}

@media (min-width: 640px){
  .container{
    max-width:640px;
  }
}

@media (min-width: 768px){
  .container{
    max-width:768px;
  }
}

@media (min-width: 1024px){
  .container{
    max-width:1024px;
  }
}

@media (min-width: 1280px){
  .container{
    max-width:1280px;
  }
}

@media (min-width: 1536px){
  .container{
    max-width:1536px;
  }
}

.pointer-events-none{
  pointer-events:none;
}

.pointer-events-auto{
  pointer-events:auto;
}

.visible{
  visibility:visible;
}

.fixed{
  position:fixed;
}

.absolute{
  position:absolute;
}

.relative{
  position:relative;
}

.top-0{
  top:0px;
}

.top-3{
  top:0.75rem;
}

.top-8{
  top:2rem;
}

.top-12{
  top:3rem;
}

.right-0{
  right:0px;
}

.right-3{
  right:0.75rem;
}

.bottom-0{
  bottom:0px;
}

.bottom-28{
  bottom:7rem;
}

.left-0{
  left:0px;
}

.left-3{
  left:0.75rem;
}

.z-10{
  z-index:10;
}

.z-50{
  z-index:50;
}

.float-left{
  float:left;
}

.m-4{
  margin:1rem;
}

.mx-auto{
  margin-left:auto;
  margin-right:auto;
}

.my-4{
  margin-top:1rem;
  margin-bottom:1rem;
}

.mt-1{
  margin-top:0.25rem;
}

.mt-2{
  margin-top:0.5rem;
}

.mt-3{
  margin-top:0.75rem;
}

.mt-4{
  margin-top:1rem;
}

.mt-6{
  margin-top:1.5rem;
}

.mt-12{
  margin-top:3rem;
}

.mr-0{
  margin-right:0px;
}

.mr-1{
  margin-right:0.25rem;
}

.mr-2{
  margin-right:0.5rem;
}

.mr-4{
  margin-right:1rem;
}

.mr-auto{
  margin-right:auto;
}

.mb-0{
  margin-bottom:0px;
}

.mb-1{
  margin-bottom:0.25rem;
}

.ml-0{
  margin-left:0px;
}

.ml-2{
  margin-left:0.5rem;
}

.ml-auto{
  margin-left:auto;
}

.block{
  display:block;
}

.inline-block{
  display:inline-block;
}

.flex{
  display:flex;
}

.inline-flex{
  display:inline-flex;
}

.table{
  display:table;
}

.grid{
  display:grid;
}

.hidden{
  display:none;
}

.h-4{
  height:1rem;
}

.h-5{
  height:1.25rem;
}

.h-6{
  height:1.5rem;
}

.h-10{
  height:2.5rem;
}

.h-12{
  height:3rem;
}

.h-14{
  height:3.5rem;
}

.h-16{
  height:4rem;
}

.h-40{
  height:10rem;
}

.h-60{
  height:15rem;
}

.h-64{
  height:16rem;
}

.h-full{
  height:100%;
}

.h-screen{
  height:100vh;
}

.w-4{
  width:1rem;
}

.w-5{
  width:1.25rem;
}

.w-6{
  width:1.5rem;
}

.w-8{
  width:2rem;
}

.w-40{
  width:10rem;
}

.w-64{
  width:16rem;
}

.w-auto{
  width:auto;
}

.w-1\/2{
  width:50%;
}

.w-full{
  width:100%;
}

.border-collapse{
  border-collapse:collapse;
}

.transform-gpu{
  --tw-translate-x:0;
  --tw-translate-y:0;
  --tw-rotate:0;
  --tw-skew-x:0;
  --tw-skew-y:0;
  --tw-scale-x:1;
  --tw-scale-y:1;
  transform:translate3d(var(--tw-translate-x), var(--tw-translate-y), 0) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

.translate-y-0{
  --tw-translate-y:0px;
}

.rotate-45{
  --tw-rotate:45deg;
}

.rotate-90{
  --tw-rotate:90deg;
}

.-rotate-45{
  --tw-rotate:-45deg;
}

@-webkit-keyframes spin{
  to{
    transform:rotate(360deg);
  }
}

@keyframes spin{
  to{
    transform:rotate(360deg);
  }
}

@-webkit-keyframes ping{
  75%, 100%{
    transform:scale(2);
    opacity:0;
  }
}

@keyframes ping{
  75%, 100%{
    transform:scale(2);
    opacity:0;
  }
}

@-webkit-keyframes pulse{
  50%{
    opacity:.5;
  }
}

@keyframes pulse{
  50%{
    opacity:.5;
  }
}

@-webkit-keyframes bounce{
  0%, 100%{
    transform:translateY(-25%);
    -webkit-animation-timing-function:cubic-bezier(0.8,0,1,1);
            animation-timing-function:cubic-bezier(0.8,0,1,1);
  }

  50%{
    transform:none;
    -webkit-animation-timing-function:cubic-bezier(0,0,0.2,1);
            animation-timing-function:cubic-bezier(0,0,0.2,1);
  }
}

@keyframes bounce{
  0%, 100%{
    transform:translateY(-25%);
    -webkit-animation-timing-function:cubic-bezier(0.8,0,1,1);
            animation-timing-function:cubic-bezier(0.8,0,1,1);
  }

  50%{
    transform:none;
    -webkit-animation-timing-function:cubic-bezier(0,0,0.2,1);
            animation-timing-function:cubic-bezier(0,0,0.2,1);
  }
}

.cursor-pointer{
  cursor:pointer;
}

.appearance-none{
  -webkit-appearance:none;
     -moz-appearance:none;
          appearance:none;
}

.grid-cols-2{
  grid-template-columns:repeat(2, minmax(0, 1fr));
}

.grid-cols-3{
  grid-template-columns:repeat(3, minmax(0, 1fr));
}

.flex-col{
  flex-direction:column;
}

.flex-col-reverse{
  flex-direction:column-reverse;
}

.content-center{
  align-content:center;
}

.content-start{
  align-content:flex-start;
}

.content-end{
  align-content:flex-end;
}

.items-start{
  align-items:flex-start;
}

.items-end{
  align-items:flex-end;
}

.items-center{
  align-items:center;
}

.justify-end{
  justify-content:flex-end;
}

.justify-center{
  justify-content:center;
}

.justify-between{
  justify-content:space-between;
}

.gap-1{
  gap:0.25rem;
}

.gap-5{
  gap:1.25rem;
}

.space-x-3 > :not([hidden]) ~ :not([hidden]){
  --tw-space-x-reverse:0;
  margin-right:calc(0.75rem * var(--tw-space-x-reverse));
  margin-left:calc(0.75rem * calc(1 - var(--tw-space-x-reverse)));
}

.space-x-6 > :not([hidden]) ~ :not([hidden]){
  --tw-space-x-reverse:0;
  margin-right:calc(1.5rem * var(--tw-space-x-reverse));
  margin-left:calc(1.5rem * calc(1 - var(--tw-space-x-reverse)));
}

.space-y-0 > :not([hidden]) ~ :not([hidden]){
  --tw-space-y-reverse:0;
  margin-top:calc(0px * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom:calc(0px * var(--tw-space-y-reverse));
}

.space-y-0\.5 > :not([hidden]) ~ :not([hidden]){
  --tw-space-y-reverse:0;
  margin-top:calc(0.125rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom:calc(0.125rem * var(--tw-space-y-reverse));
}

.divide-y > :not([hidden]) ~ :not([hidden]){
  --tw-divide-y-reverse:0;
  border-top-width:calc(1px * calc(1 - var(--tw-divide-y-reverse)));
  border-bottom-width:calc(1px * var(--tw-divide-y-reverse));
}

.divide-gray-100 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(243, 244, 246, var(--tw-divide-opacity));
}

.overflow-hidden{
  overflow:hidden;
}

.overflow-y-auto{
  overflow-y:auto;
}

.rounded-sm{
  border-radius:0.125rem;
}

.rounded{
  border-radius:0.25rem;
}

.rounded-full{
  border-radius:9999px;
}

.border{
  border-width:1px;
}

.border-t{
  border-top-width:1px;
}

.border-b-2{
  border-bottom-width:2px;
}

.border-b{
  border-bottom-width:1px;
}

.border-solid{
  border-style:solid;
}

.border-gray-50{
  --tw-border-opacity:1;
  border-color:rgba(249, 250, 251, var(--tw-border-opacity));
}

.border-gray-200{
  --tw-border-opacity:1;
  border-color:rgba(229, 231, 235, var(--tw-border-opacity));
}

.border-gray-300{
  --tw-border-opacity:1;
  border-color:rgba(209, 213, 219, var(--tw-border-opacity));
}

.border-gray-400{
  --tw-border-opacity:1;
  border-color:rgba(156, 163, 175, var(--tw-border-opacity));
}

.border-gray-900{
  --tw-border-opacity:1;
  border-color:rgba(17, 24, 39, var(--tw-border-opacity));
}

.border-red-600{
  --tw-border-opacity:1;
  border-color:rgba(220, 38, 38, var(--tw-border-opacity));
}

.border-red-900{
  --tw-border-opacity:1;
  border-color:rgba(127, 29, 29, var(--tw-border-opacity));
}

.hover\:border-red-600:hover{
  --tw-border-opacity:1;
  border-color:rgba(220, 38, 38, var(--tw-border-opacity));
}

.border-opacity-30{
  --tw-border-opacity:0.3;
}

.border-opacity-75{
  --tw-border-opacity:0.75;
}

.bg-black{
  --tw-bg-opacity:1;
  background-color:rgba(0, 0, 0, var(--tw-bg-opacity));
}

.bg-white{
  --tw-bg-opacity:1;
  background-color:rgba(255, 255, 255, var(--tw-bg-opacity));
}

.bg-red-700{
  --tw-bg-opacity:1;
  background-color:rgba(185, 28, 28, var(--tw-bg-opacity));
}

.bg-blue-200{
  --tw-bg-opacity:1;
  background-color:rgba(191, 219, 254, var(--tw-bg-opacity));
}

.hover\:bg-white:hover{
  --tw-bg-opacity:1;
  background-color:rgba(255, 255, 255, var(--tw-bg-opacity));
}

.hover\:bg-gray-100:hover{
  --tw-bg-opacity:1;
  background-color:rgba(243, 244, 246, var(--tw-bg-opacity));
}

.hover\:bg-gray-200:hover{
  --tw-bg-opacity:1;
  background-color:rgba(229, 231, 235, var(--tw-bg-opacity));
}

.bg-opacity-0{
  --tw-bg-opacity:0;
}

.bg-opacity-20{
  --tw-bg-opacity:0.2;
}

.bg-opacity-50{
  --tw-bg-opacity:0.5;
}

.bg-opacity-60{
  --tw-bg-opacity:0.6;
}

.bg-opacity-70{
  --tw-bg-opacity:0.7;
}

.hover\:bg-opacity-30:hover{
  --tw-bg-opacity:0.3;
}

.hover\:bg-opacity-50:hover{
  --tw-bg-opacity:0.5;
}

.bg-gradient-to-b{
  background-image:linear-gradient(to bottom, var(--tw-gradient-stops));
}

.from-white{
  --tw-gradient-from:#fff;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(255, 255, 255, 0));
}

.from-gray-400{
  --tw-gradient-from:#9ca3af;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(156, 163, 175, 0));
}

.to-gray-100{
  --tw-gradient-to:#f3f4f6;
}

.to-gray-500{
  --tw-gradient-to:#6b7280;
}

.bg-cover{
  background-size:cover;
}

.bg-contain{
  background-size:contain;
}

.bg-fixed{
  background-attachment:fixed;
}

.bg-center{
  background-position:center;
}

.bg-no-repeat{
  background-repeat:no-repeat;
}

.p-1{
  padding:0.25rem;
}

.p-2{
  padding:0.5rem;
}

.p-3{
  padding:0.75rem;
}

.p-4{
  padding:1rem;
}

.px-0{
  padding-left:0px;
  padding-right:0px;
}

.px-1{
  padding-left:0.25rem;
  padding-right:0.25rem;
}

.px-4{
  padding-left:1rem;
  padding-right:1rem;
}

.px-6{
  padding-left:1.5rem;
  padding-right:1.5rem;
}

.py-1{
  padding-top:0.25rem;
  padding-bottom:0.25rem;
}

.py-2{
  padding-top:0.5rem;
  padding-bottom:0.5rem;
}

.py-3{
  padding-top:0.75rem;
  padding-bottom:0.75rem;
}

.py-6{
  padding-top:1.5rem;
  padding-bottom:1.5rem;
}

.py-8{
  padding-top:2rem;
  padding-bottom:2rem;
}

.py-12{
  padding-top:3rem;
  padding-bottom:3rem;
}

.text-left{
  text-align:left;
}

.text-center{
  text-align:center;
}

.text-right{
  text-align:right;
}

.align-top{
  vertical-align:top;
}

.align-middle{
  vertical-align:middle;
}

.font-sans{
  font-family:ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, "Noto Sans", sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji";
}

.text-xs{
  font-size:0.75rem;
  line-height:1rem;
}

.text-sm{
  font-size:0.875rem;
  line-height:1.25rem;
}

.text-lg{
  font-size:1.125rem;
  line-height:1.75rem;
}

.text-xl{
  font-size:1.25rem;
  line-height:1.75rem;
}

.text-2xl{
  font-size:1.5rem;
  line-height:2rem;
}

.text-6xl{
  font-size:3.75rem;
  line-height:1;
}

.font-normal{
  font-weight:400;
}

.font-semibold{
  font-weight:600;
}

.font-bold{
  font-weight:700;
}

.leading-4{
  line-height:1rem;
}

.leading-5{
  line-height:1.25rem;
}

.text-black{
  --tw-text-opacity:1;
  color:rgba(0, 0, 0, var(--tw-text-opacity));
}

.text-white{
  --tw-text-opacity:1;
  color:rgba(255, 255, 255, var(--tw-text-opacity));
}

.text-gray-300{
  --tw-text-opacity:1;
  color:rgba(209, 213, 219, var(--tw-text-opacity));
}

.text-gray-700{
  --tw-text-opacity:1;
  color:rgba(55, 65, 81, var(--tw-text-opacity));
}

.text-opacity-30{
  --tw-text-opacity:0.3;
}

.text-opacity-70{
  --tw-text-opacity:0.7;
}

.hover\:text-opacity-80:hover{
  --tw-text-opacity:0.8;
}

.underline{
  text-decoration:underline;
}

*, ::before, ::after{
  --tw-shadow:0 0 #0000;
}

.shadow{
  --tw-shadow:0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.06);
  box-shadow:var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}

.shadow-xl{
  --tw-shadow:0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
  box-shadow:var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}

*, ::before, ::after{
  --tw-ring-inset:var(--tw-empty,/*!*/ /*!*/);
  --tw-ring-offset-width:0px;
  --tw-ring-offset-color:#fff;
  --tw-ring-color:rgba(59, 130, 246, 0.5);
  --tw-ring-offset-shadow:0 0 #0000;
  --tw-ring-shadow:0 0 #0000;
}

.filter{
  --tw-blur:var(--tw-empty,/*!*/ /*!*/);
  --tw-brightness:var(--tw-empty,/*!*/ /*!*/);
  --tw-contrast:var(--tw-empty,/*!*/ /*!*/);
  --tw-grayscale:var(--tw-empty,/*!*/ /*!*/);
  --tw-hue-rotate:var(--tw-empty,/*!*/ /*!*/);
  --tw-invert:var(--tw-empty,/*!*/ /*!*/);
  --tw-saturate:var(--tw-empty,/*!*/ /*!*/);
  --tw-sepia:var(--tw-empty,/*!*/ /*!*/);
  --tw-drop-shadow:var(--tw-empty,/*!*/ /*!*/);
  filter:var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow);
}

.transition-all{
  transition-property:all;
  transition-timing-function:cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration:150ms;
}

.duration-75{
  transition-duration:75ms;
}

.duration-200{
  transition-duration:200ms;
}

.ease-in-out{
  transition-timing-function:cubic-bezier(0.4, 0, 0.2, 1);
}

@media (min-width: 640px){
}

@media (min-width: 768px){
  .md\:top-0{
    top:0px;
  }

  .md\:m-auto{
    margin:auto;
  }

  .md\:block{
    display:block;
  }

  .md\:flex{
    display:flex;
  }

  .md\:h-10{
    height:2.5rem;
  }

  .md\:w-72{
    width:18rem;
  }

  .md\:w-96{
    width:24rem;
  }

  .md\:w-1\/2{
    width:50%;
  }

  .md\:w-1\/4{
    width:25%;
  }

  .md\:w-2\/4{
    width:50%;
  }

  .md\:w-3\/4{
    width:75%;
  }

  .md\:grid-cols-1{
    grid-template-columns:repeat(1, minmax(0, 1fr));
  }

  .md\:flex-row{
    flex-direction:row;
  }

  .md\:justify-start{
    justify-content:flex-start;
  }

  .md\:p-0{
    padding:0px;
  }

  .md\:p-4{
    padding:1rem;
  }

  .md\:px-0{
    padding-left:0px;
    padding-right:0px;
  }

  .md\:py-2{
    padding-top:0.5rem;
    padding-bottom:0.5rem;
  }

  .md\:pb-1{
    padding-bottom:0.25rem;
  }

  .md\:text-right{
    text-align:right;
  }
}

@media (min-width: 1024px){
  .lg\:hidden{
    display:none;
  }
}

@media (min-width: 1280px){
  .xl\:hidden{
    display:none;
  }
}

@media (min-width: 1536px){
}
/*purgecss start ignore*/
.nuxt-progress{
  position:fixed;
  top:0;
  left:0;
  right:0;
  height:2px;
  width:0;
  opacity:1;
  transition:width .1s,opacity .4s;
  background-color:#000;
  z-index:999999
}
.nuxt-progress.nuxt-progress-notransition{
  transition:none
}
.nuxt-progress-failed{
  background-color:red
}

/*purgecss end ignore*/
/*purgecss start ignore*/
.navbar{
  border-radius:0
}
.bg-hero{
  background:url(/images/in-landslide_14.jpg);
  background-size:cover;
  background-repeat:no-repeat
}

/*purgecss end ignore*/
/*purgecss start ignore*/
.cesium-svgPath-svg{
  position:absolute;
  top:0;
  left:0;
  width:100%;
  height:100%;
  overflow:hidden
}
.cesium-button{
  display:inline-block;
  position:relative;
  background:#303336;
  border:1px solid #444;
  color:#edffff;
  fill:#edffff;
  border-radius:4px;
  padding:5px 12px;
  margin:2px 3px;
  cursor:pointer;
  overflow:hidden;
  -moz-user-select:none;
  -webkit-user-select:none;
  user-select:none
}
.cesium-button:focus{
  color:#fff;
  fill:#fff;
  border-color:#ea4;
  outline:none
}
.cesium-button:hover{
  color:#fff;
  fill:#fff;
  background:#48b;
  border-color:#aef;
  box-shadow:0 0 8px #fff
}
.cesium-button:active{
  color:#000;
  fill:#000;
  background:#adf;
  border-color:#fff;
  box-shadow:0 0 8px #fff
}
.cesium-button-disabled,.cesium-button-disabled:active,.cesium-button-disabled:focus,.cesium-button-disabled:hover,.cesium-button:disabled{
  background:#303336;
  border-color:#444;
  color:#646464;
  fill:#646464;
  box-shadow:none;
  cursor:default
}
.cesium-button option{
  background-color:#000;
  color:#eee
}
.cesium-button option:disabled{
  color:#777
}
.cesium-button input,.cesium-button label{
  cursor:pointer
}
.cesium-button input{
  vertical-align:sub
}
.cesium-toolbar-button{
  box-sizing:border-box;
  width:32px;
  height:32px;
  border-radius:14%;
  padding:0;
  vertical-align:middle;
  z-index:0
}
.cesium-performanceDisplay-defaultContainer{
  position:absolute;
  top:50px;
  right:10px;
  text-align:right
}
.cesium-performanceDisplay{
  background-color:rgba(40,40,40,.7019607843137254);
  padding:7px;
  border-radius:5px;
  border:1px solid #444;
  font:700 12px sans-serif
}
.cesium-performanceDisplay-fps{
  color:#e52
}
.cesium-performanceDisplay-throttled{
  color:#a42
}
.cesium-performanceDisplay-ms{
  color:#de3
}
.cesium-animation-theme{
  visibility:hidden;
  display:block;
  position:absolute;
  z-index:-100
}
.cesium-animation-themeNormal{
  color:#222
}
.cesium-animation-themeHover{
  color:#4488b0
}
.cesium-animation-themeSelect{
  color:#242
}
.cesium-animation-themeDisabled{
  color:#333
}
.cesium-animation-themeKnob{
  color:#222
}
.cesium-animation-themePointer{
  color:#2e2
}
.cesium-animation-themeSwoosh{
  color:#8ac
}
.cesium-animation-themeSwooshHover{
  color:#aef
}
.cesium-animation-svgText{
  fill:#edffff;
  font-family:Sans-Serif;
  font-size:15px;
  text-anchor:middle
}
.cesium-animation-blank{
  fill:#000;
  fill-opacity:.01;
  stroke:none
}
.cesium-animation-rectButton{
  cursor:pointer;
  -moz-user-select:none;
  -webkit-user-select:none;
  user-select:none
}
.cesium-animation-rectButton .cesium-animation-buttonGlow{
  fill:#fff;
  stroke:none;
  display:none
}
.cesium-animation-rectButton:hover .cesium-animation-buttonGlow{
  display:block
}
.cesium-animation-rectButton .cesium-animation-buttonPath{
  fill:#edffff
}
.cesium-animation-rectButton .cesium-animation-buttonMain{
  stroke:#444;
  stroke-width:1.2
}
.cesium-animation-rectButton:hover .cesium-animation-buttonMain{
  stroke:#aef
}
.cesium-animation-rectButton:active .cesium-animation-buttonMain{
  fill:#abd6ff
}
.cesium-animation-buttonDisabled{
  -moz-user-select:none;
  -webkit-user-select:none;
  user-select:none
}
.cesium-animation-buttonDisabled .cesium-animation-buttonMain{
  stroke:#555
}
.cesium-animation-buttonDisabled .cesium-animation-buttonPath{
  fill:#818181
}
.cesium-animation-buttonDisabled .cesium-animation-buttonGlow{
  display:none
}
.cesium-animation-buttonToggled .cesium-animation-buttonGlow{
  display:block;
  fill:#2e2
}
.cesium-animation-buttonToggled .cesium-animation-buttonMain{
  stroke:#2e2
}
.cesium-animation-buttonToggled:hover .cesium-animation-buttonGlow{
  fill:#fff
}
.cesium-animation-buttonToggled:hover .cesium-animation-buttonMain{
  stroke:#2e2
}
.cesium-animation-shuttleRingG,.cesium-animation-shuttleRingPausePointer,.cesium-animation-shuttleRingPointer{
  cursor:pointer
}
.cesium-animation-shuttleRingBack{
  fill:#181818;
  fill-opacity:.8;
  stroke:#333;
  stroke-width:1.2
}
.cesium-animation-shuttleRingSwoosh line{
  stroke:#8ac;
  stroke-width:3;
  stroke-opacity:.2;
  stroke-linecap:round
}
.cesium-animation-knobOuter{
  cursor:pointer;
  stroke:#444;
  stroke-width:1.2
}
.cesium-animation-knobInner{
  cursor:pointer
}
.cesium-baseLayerPicker-selected{
  position:absolute;
  top:0;
  left:0;
  width:100%;
  height:100%;
  border:none
}
.cesium-baseLayerPicker-dropDown{
  display:block;
  position:absolute;
  box-sizing:content-box;
  top:auto;
  right:0;
  width:320px;
  max-height:500px;
  margin-top:5px;
  background-color:rgba(38,38,38,.7490196078431373);
  border:1px solid #444;
  padding:6px;
  overflow:auto;
  border-radius:10px;
  -moz-user-select:none;
  -webkit-user-select:none;
  user-select:none;
  transform:translateY(-20%);
  visibility:hidden;
  opacity:0;
  transition:visibility 0s .2s,opacity .2s ease-in,transform .2s ease-in
}
.cesium-baseLayerPicker-dropDown-visible{
  transform:translate(0);
  visibility:visible;
  opacity:1;
  transition:opacity .2s ease-out,transform .2s ease-out
}
.cesium-baseLayerPicker-sectionTitle{
  display:block;
  font-family:sans-serif;
  font-size:16pt;
  text-align:left;
  color:#edffff;
  margin-bottom:4px
}
.cesium-baseLayerPicker-choices{
  margin-bottom:5px
}
.cesium-baseLayerPicker-categoryTitle{
  color:#edffff;
  font-size:11pt
}
.cesium-baseLayerPicker-choices{
  display:block;
  border:1px solid #888;
  border-radius:5px;
  padding:5px 0
}
.cesium-baseLayerPicker-item{
  display:inline-block;
  vertical-align:top;
  margin:2px 5px;
  width:64px;
  text-align:center;
  cursor:pointer
}
.cesium-baseLayerPicker-itemLabel{
  display:block;
  font-family:sans-serif;
  font-size:8pt;
  text-align:center;
  vertical-align:middle;
  color:#edffff;
  cursor:pointer;
  word-wrap:break-word
}
.cesium-baseLayerPicker-item:focus .cesium-baseLayerPicker-itemLabel,.cesium-baseLayerPicker-item:hover .cesium-baseLayerPicker-itemLabel{
  text-decoration:underline
}
.cesium-baseLayerPicker-itemIcon{
  display:inline-block;
  position:relative;
  width:inherit;
  height:auto;
  background-size:100% 100%;
  border:1px solid #444;
  border-radius:9px;
  color:#edffff;
  margin:0;
  padding:0;
  cursor:pointer;
  box-sizing:border-box
}
.cesium-baseLayerPicker-item:hover .cesium-baseLayerPicker-itemIcon{
  border-color:#fff;
  box-shadow:0 0 8px #fff,0 0 8px #fff
}
.cesium-baseLayerPicker-selectedItem .cesium-baseLayerPicker-itemLabel{
  color:#bdecf8
}
.cesium-baseLayerPicker-selectedItem .cesium-baseLayerPicker-itemIcon{
  border:4px double #bdecf8
}
.cesium-widget{
  position:relative
}
.cesium-widget,.cesium-widget canvas{
  width:100%;
  height:100%;
  touch-action:none
}
.cesium-widget-credits{
  display:block;
  position:absolute;
  bottom:0;
  left:0;
  color:#fff;
  font-size:10px;
  text-shadow:0 0 2px #000;
  padding-right:5px
}
.cesium-widget-credits a,.cesium-widget-credits a:visited{
  color:#fff
}
.cesium-widget-errorPanel{
  position:absolute;
  inset:0;
  text-align:center;
  background:rgba(0,0,0,.7);
  z-index:99999
}
.cesium-widget-errorPanel:before{
  display:inline-block;
  vertical-align:middle;
  height:100%;
  content:""
}
.cesium-widget-errorPanel-content{
  width:75%;
  max-width:500px;
  display:inline-block;
  text-align:left;
  vertical-align:middle;
  border:1px solid #510c00;
  border-radius:7px;
  background-color:#f0d9d5;
  font-size:14px;
  color:#510c00
}
.cesium-widget-errorPanel-content.expanded{
  max-width:75%
}
.cesium-widget-errorPanel-header{
  font-size:18px;
  font-family:Open Sans,Verdana,Geneva,sans-serif;
  background:#d69d93;
  border-bottom:2px solid #510c00;
  border-radius:3px 3px 0 0;
  padding:15px
}
.cesium-widget-errorPanel-scroll{
  overflow:auto;
  font-family:Open Sans,Verdana,Geneva,sans-serif;
  white-space:pre-wrap;
  padding:0 15px;
  margin:10px 0 20px
}
.cesium-widget-errorPanel-buttonPanel{
  padding:0 15px;
  margin:10px 0 20px;
  text-align:right
}
.cesium-widget-errorPanel-buttonPanel button{
  border-color:#510c00;
  background:#d69d93;
  color:#202020;
  margin:0
}
.cesium-widget-errorPanel-buttonPanel button:focus,.cesium-widget-errorPanel-buttonPanel button:hover{
  border-color:#510c00;
  background:#f0d9d5;
  color:#510c00
}
.cesium-widget-errorPanel-buttonPanel button:active{
  border-color:#510c00;
  background:#b17b72;
  color:#510c00
}
.cesium-widget-errorPanel-more-details{
  text-decoration:underline;
  cursor:pointer
}
.cesium-widget-errorPanel-more-details:hover{
  color:#2b0700
}
.cesium-cesiumInspector{
  border-radius:5px;
  transition:width .25s ease-in-out;
  background:rgba(48,51,54,.8);
  border:1px solid #444;
  color:#edffff;
  display:inline-block;
  position:relative;
  padding:4px 12px;
  -moz-user-select:none;
  -webkit-user-select:none;
  user-select:none;
  overflow:hidden
}
.cesium-cesiumInspector-button{
  text-align:center;
  font-size:11pt
}
.cesium-cesiumInspector-visible .cesium-cesiumInspector-button{
  border-bottom:1px solid #aaa;
  padding-bottom:3px
}
.cesium-cesiumInspector-button,.cesium-cesiumInspector input:enabled{
  cursor:pointer
}
.cesium-cesiumInspector-visible{
  width:185px;
  height:auto
}
.cesium-cesiumInspector-hidden{
  width:122px;
  height:17px
}
.cesium-cesiumInspector-sectionContent{
  max-height:600px
}
.cesium-cesiumInspector-section-collapsed .cesium-cesiumInspector-sectionContent{
  max-height:0;
  padding:0!important;
  overflow:hidden
}
.cesium-cesiumInspector-dropDown{
  margin:5px 0;
  font-family:sans-serif;
  font-size:10pt;
  width:185px
}
.cesium-cesiumInspector-frustumStatistics{
  padding:5px;
  background-color:rgba(80,80,80,.7490196078431373)
}
.cesium-cesiumInspector-pickButton{
  background-color:rgba(0,0,0,.30196078431372547);
  border:1px solid #444;
  color:#edffff;
  border-radius:5px;
  padding:3px 7px;
  cursor:pointer;
  -moz-user-select:none;
  -webkit-user-select:none;
  user-select:none;
  margin:0 auto
}
.cesium-cesiumInspector-pickButton:focus{
  outline:none
}
.cesium-cesiumInspector-pickButton:active,.cesium-cesiumInspector-pickButtonHighlight{
  color:#000;
  background:#adf;
  border-color:#fff;
  box-shadow:0 0 8px #fff
}
.cesium-cesiumInspector-center{
  text-align:center
}
.cesium-cesiumInspector-sectionHeader{
  font-weight:700;
  font-size:10pt;
  margin:0;
  cursor:pointer
}
.cesium-cesiumInspector-pickSection{
  border:1px solid #aaa;
  border-radius:5px;
  padding:3px;
  margin-bottom:5px
}
.cesium-cesiumInspector-sectionContent{
  margin-bottom:10px;
  transition:max-height .25s
}
.cesium-cesiumInspector-tileText{
  padding-bottom:10px;
  border-bottom:1px solid #aaa
}
.cesium-cesiumInspector-relativeText{
  padding-top:10px
}
.cesium-cesiumInspector-sectionHeader:before{
  margin-right:5px;
  content:"-";
  width:1ch;
  display:inline-block
}
.cesium-cesiumInspector-section-collapsed .cesium-cesiumInspector-sectionHeader:before{
  content:"+"
}
ul.cesium-cesiumInspector-statistics{
  margin:0;
  padding-top:3px;
  padding-bottom:3px
}
ul.cesium-cesiumInspector-statistics+ul.cesium-cesiumInspector-statistics{
  border-top:1px solid #aaa
}
.cesium-cesiumInspector-slider{
  margin-top:5px
}
.cesium-cesiumInspector-slider input[type=number]{
  text-align:left;
  background-color:#222;
  outline:none;
  border:1px solid #444;
  color:#edffff;
  width:100px;
  border-radius:3px;
  padding:1px;
  margin-left:10px;
  cursor:auto
}
.cesium-cesiumInspector-slider input[type=number]::-webkit-inner-spin-button,.cesium-cesiumInspector-slider input[type=number]::-webkit-outer-spin-button{
  -webkit-appearance:none;
  margin:0
}
.cesium-cesiumInspector-slider input[type=range]{
  margin-left:5px;
  vertical-align:middle
}
.cesium-cesiumInspector-hide .cesium-cesiumInspector-styleEditor{
  display:none
}
.cesium-cesiumInspector-styleEditor{
  padding:10px;
  border-radius:5px;
  background:rgba(48,51,54,.8);
  border:1px solid #444
}
.cesium-cesiumInspector-styleEditor textarea{
  width:100%;
  height:300px;
  background:transparent;
  color:#edffff;
  border:none;
  padding:0;
  white-space:pre;
  overflow-wrap:normal;
  overflow-x:auto
}
.cesium-3DTilesInspector{
  width:300px;
  pointer-events:all
}
.cesium-3DTilesInspector-statistics{
  font-size:11px
}
.cesium-3DTilesInspector div,.cesium-3DTilesInspector input[type=range]{
  width:100%;
  box-sizing:border-box
}
.cesium-cesiumInspector-error{
  color:#ff9e9e;
  overflow:auto
}
.cesium-3DTilesInspector .cesium-cesiumInspector-section{
  margin-top:3px
}
.cesium-3DTilesInspector .cesium-cesiumInspector-sectionHeader+.cesium-cesiumInspector-show{
  border-top:1px solid #fff
}
input.cesium-cesiumInspector-url{
  overflow:hidden;
  white-space:nowrap;
  overflow-x:scroll;
  background-color:transparent;
  color:#fff;
  outline:none;
  border:none;
  height:1em;
  width:100%
}
.cesium-cesiumInspector .field-group{
  display:table
}
.cesium-cesiumInspector .field-group>label{
  display:table-cell;
  font-weight:700
}
.cesium-cesiumInspector .field-group>.field{
  display:table-cell;
  width:100%
}
.cesium-button.cesium-fullscreenButton,.cesium-button.cesium-vrButton{
  display:block;
  width:100%;
  height:100%;
  margin:0;
  border-radius:0
}
.cesium-viewer-geocoderContainer .cesium-geocoder-input{
  border:1px solid #444;
  background-color:rgba(40,40,40,.7019607843137254);
  color:#fff;
  display:inline-block;
  vertical-align:middle;
  width:0;
  height:32px;
  margin:0;
  padding:0 32px 0 0;
  border-radius:0;
  box-sizing:border-box;
  transition:width .25s ease-in-out,background-color .2s ease-in-out;
  -webkit-appearance:none
}
.cesium-viewer-geocoderContainer:hover .cesium-geocoder-input{
  border-color:#aef;
  box-shadow:0 0 8px #fff
}
.cesium-viewer-geocoderContainer .cesium-geocoder-input:focus{
  border-color:#ea4;
  background-color:rgba(15,15,15,.9019607843137255);
  box-shadow:none;
  outline:none
}
.cesium-viewer-geocoderContainer .cesium-geocoder-input-wide,.cesium-viewer-geocoderContainer .cesium-geocoder-input:focus,.cesium-viewer-geocoderContainer:hover .cesium-geocoder-input{
  padding-left:4px;
  width:250px
}
.cesium-viewer-geocoderContainer .search-results{
  position:absolute;
  background-color:#000;
  color:#eee;
  overflow-y:auto;
  opacity:.8;
  width:100%
}
.cesium-viewer-geocoderContainer .search-results ul{
  list-style-type:none;
  margin:0;
  padding:0
}
.cesium-viewer-geocoderContainer .search-results ul li{
  font-size:14px;
  padding:3px 10px
}
.cesium-viewer-geocoderContainer .search-results ul li:hover{
  cursor:pointer
}
.cesium-viewer-geocoderContainer .search-results ul li.active{
  background:#48b
}
.cesium-geocoder-searchButton{
  background-color:#303336;
  display:inline-block;
  position:absolute;
  cursor:pointer;
  width:32px;
  top:1px;
  right:1px;
  height:30px;
  vertical-align:middle;
  fill:#edffff
}
.cesium-geocoder-searchButton:hover{
  background-color:#48b
}
.cesium-infoBox{
  display:block;
  position:absolute;
  top:50px;
  right:0;
  width:40%;
  max-width:480px;
  background:rgba(38,38,38,.95);
  color:#edffff;
  border:1px solid #444;
  border-right:none;
  border-top-left-radius:7px;
  border-bottom-left-radius:7px;
  box-shadow:0 0 10px 1px #000;
  transform:translate(100%);
  visibility:hidden;
  opacity:0;
  transition:visibility 0s .2s,opacity .2s ease-in,transform .2s ease-in
}
.cesium-infoBox-visible{
  transform:translate(0);
  visibility:visible;
  opacity:1;
  transition:opacity .2s ease-out,transform .2s ease-out
}
.cesium-infoBox-title{
  display:block;
  height:20px;
  padding:5px 30px 5px 25px;
  background:#545454;
  border-top-left-radius:7px;
  text-align:center;
  text-overflow:ellipsis;
  white-space:nowrap;
  overflow:hidden;
  box-sizing:content-box
}
.cesium-infoBox-bodyless .cesium-infoBox-title{
  border-bottom-left-radius:7px
}
button.cesium-infoBox-camera{
  top:4px;
  left:4px;
  width:22px;
  height:22px;
  border-color:transparent;
  border-radius:3px
}
button.cesium-infoBox-camera,button.cesium-infoBox-close{
  display:block;
  position:absolute;
  background:transparent;
  padding:0 5px;
  margin:0
}
button.cesium-infoBox-close{
  top:5px;
  right:5px;
  height:20px;
  border:none;
  border-radius:2px;
  font-weight:700;
  font-size:16px;
  color:#edffff
}
button.cesium-infoBox-close:focus{
  background:rgba(238,136,0,.44);
  outline:none
}
button.cesium-infoBox-close:hover{
  background:#888;
  color:#000
}
button.cesium-infoBox-close:active{
  background:#a00;
  color:#000
}
.cesium-infoBox-bodyless .cesium-infoBox-iframe{
  display:none
}
.cesium-infoBox-iframe{
  border:none;
  width:100%;
  width:calc(100% - 2px)
}
span.cesium-sceneModePicker-wrapper{
  display:inline-block;
  position:relative;
  margin:0 3px
}
.cesium-sceneModePicker-visible{
  visibility:visible;
  opacity:1;
  transition:opacity .25s linear
}
.cesium-sceneModePicker-hidden{
  visibility:hidden;
  opacity:0;
  transition:visibility 0s .25s,opacity .25s linear
}
.cesium-sceneModePicker-wrapper .cesium-sceneModePicker-none{
  display:none
}
.cesium-sceneModePicker-slide-svg{
  transition:left 2s;
  top:0;
  left:0
}
.cesium-sceneModePicker-wrapper .cesium-sceneModePicker-dropDown-icon{
  box-sizing:border-box;
  padding:0;
  margin:3px 0
}
.cesium-sceneModePicker-wrapper .cesium-sceneModePicker-button2D,.cesium-sceneModePicker-wrapper .cesium-sceneModePicker-button3D,.cesium-sceneModePicker-wrapper .cesium-sceneModePicker-buttonColumbusView{
  margin:0 0 3px
}
.cesium-sceneModePicker-wrapper .cesium-sceneModePicker-button3D .cesium-sceneModePicker-icon2D{
  left:100%
}
.cesium-sceneModePicker-wrapper .cesium-sceneModePicker-button3D .cesium-sceneModePicker-iconColumbusView{
  left:200%
}
.cesium-sceneModePicker-wrapper .cesium-sceneModePicker-buttonColumbusView .cesium-sceneModePicker-icon3D{
  left:-200%
}
.cesium-sceneModePicker-wrapper .cesium-sceneModePicker-button2D .cesium-sceneModePicker-icon3D,.cesium-sceneModePicker-wrapper .cesium-sceneModePicker-buttonColumbusView .cesium-sceneModePicker-icon2D{
  left:-100%
}
.cesium-sceneModePicker-wrapper .cesium-sceneModePicker-button2D .cesium-sceneModePicker-iconColumbusView{
  left:100%
}
.cesium-sceneModePicker-wrapper .cesium-sceneModePicker-selected{
  border-color:#2e2;
  box-shadow:0 0 8px #fff,0 0 8px #fff
}
span.cesium-projectionPicker-wrapper{
  display:inline-block;
  position:relative;
  margin:0 3px
}
.cesium-projectionPicker-visible{
  visibility:visible;
  opacity:1;
  transition:opacity .25s linear
}
.cesium-projectionPicker-hidden{
  visibility:hidden;
  opacity:0;
  transition:visibility 0s .25s,opacity .25s linear
}
.cesium-projectionPicker-wrapper .cesium-projectionPicker-none{
  display:none
}
.cesium-projectionPicker-wrapper .cesium-projectionPicker-dropDown-icon{
  box-sizing:border-box;
  padding:0;
  margin:3px 0
}
.cesium-projectionPicker-wrapper .cesium-projectionPicker-buttonOrthographic,.cesium-projectionPicker-wrapper .cesium-projectionPicker-buttonPerspective{
  margin:0 0 3px
}
.cesium-projectionPicker-wrapper .cesium-projectionPicker-buttonPerspective .cesium-projectionPicker-iconOrthographic{
  left:100%
}
.cesium-projectionPicker-wrapper .cesium-projectionPicker-buttonOrthographic .cesium-projectionPicker-iconPerspective{
  left:-100%
}
.cesium-projectionPicker-wrapper .cesium-projectionPicker-selected{
  border-color:#2e2;
  box-shadow:0 0 8px #fff,0 0 8px #fff
}
.cesium-performance-watchdog-message-area{
  position:relative;
  background-color:#ff0;
  color:#000;
  padding:10px
}
.cesium-performance-watchdog-message{
  margin-right:30px
}
.cesium-performance-watchdog-message-dismiss{
  position:absolute;
  right:0;
  margin:0 10px 0 0
}
.cesium-navigationHelpButton-wrapper{
  position:relative;
  display:inline-block
}
.cesium-navigation-help{
  visibility:hidden;
  position:absolute;
  top:38px;
  right:2px;
  width:250px;
  border-radius:10px;
  transform:scale(.01);
  transform-origin:234px -10px;
  transition:visibility 0s .25s,transform .25s ease-in
}
.cesium-navigation-help-visible{
  visibility:visible;
  transform:scale(1);
  transition:transform .25s ease-out
}
.cesium-navigation-help-instructions{
  border:1px solid #444;
  background-color:rgba(38,38,38,.7490196078431373);
  padding-bottom:5px;
  border-radius:0 0 10px 10px
}
.cesium-click-navigation-help{
  display:none
}
.cesium-touch-navigation-help{
  display:none;
  padding-top:5px
}
.cesium-click-navigation-help-visible,.cesium-touch-navigation-help-visible{
  display:block
}
.cesium-navigation-help-pan{
  color:#6cf;
  font-weight:700
}
.cesium-navigation-help-zoom{
  color:#65fd00;
  font-weight:700
}
.cesium-navigation-help-rotate{
  color:#ffd800;
  font-weight:700
}
.cesium-navigation-help-tilt{
  color:#d800d8;
  font-weight:700
}
.cesium-navigation-help-details{
  color:#fff
}
.cesium-navigation-button{
  color:#fff;
  background-color:transparent;
  border-bottom:none;
  border-top:1px solid #444;
  border-right:1px solid #444;
  margin:0;
  width:50%;
  cursor:pointer
}
.cesium-navigation-button-icon{
  vertical-align:middle;
  padding:5px 1px
}
.cesium-navigation-button:focus{
  outline:none
}
.cesium-navigation-button-left{
  border-radius:10px 0 0;
  border-left:1px solid #444
}
.cesium-navigation-button-right{
  border-radius:0 10px 0 0;
  border-left:none
}
.cesium-navigation-button-selected{
  background-color:rgba(38,38,38,.7490196078431373)
}
.cesium-navigation-button-unselected{
  background-color:rgba(0,0,0,.7490196078431373)
}
.cesium-navigation-button-unselected:hover{
  background-color:rgba(76,76,76,.7490196078431373)
}
.cesium-selection-wrapper{
  position:absolute;
  width:160px;
  height:160px;
  pointer-events:none;
  visibility:hidden;
  opacity:0;
  transition:visibility 0s .2s,opacity .2s ease-in
}
.cesium-selection-wrapper-visible{
  visibility:visible;
  opacity:1;
  transition:opacity .2s ease-out
}
.cesium-selection-wrapper svg{
  fill:#2e2;
  stroke:#000;
  stroke-width:1.1px
}
.cesium-timeline-main{
  position:relative;
  left:0;
  bottom:0;
  overflow:hidden;
  border:1px solid #888;
  -moz-user-select:none;
  -webkit-user-select:none;
  user-select:none
}
.cesium-timeline-trackContainer{
  width:100%;
  overflow:auto;
  border-top:1px solid #888;
  position:relative;
  top:0;
  left:0
}
.cesium-timeline-tracks{
  position:absolute;
  top:0;
  left:0;
  width:100%
}
.cesium-timeline-needle{
  position:absolute;
  left:0;
  top:1.7em;
  bottom:0;
  width:1px;
  background:red
}
.cesium-timeline-bar{
  position:relative;
  left:0;
  top:0;
  overflow:hidden;
  cursor:pointer;
  width:100%;
  height:1.7em;
  background:linear-gradient(180deg,rgba(116,117,119,.8) 0,rgba(58,68,82,.8) 11%,rgba(46,50,56,.8) 46%,rgba(53,53,53,.8) 81%,rgba(53,53,53,.8))
}
.cesium-timeline-ruler{
  visibility:hidden;
  white-space:nowrap;
  font-size:80%;
  z-index:-200
}
.cesium-timeline-highlight{
  position:absolute;
  bottom:0;
  left:0;
  background:#08f
}
.cesium-timeline-ticLabel{
  position:absolute;
  top:0;
  left:0;
  white-space:nowrap;
  font-size:80%;
  color:#eee
}
.cesium-timeline-ticMain{
  position:absolute;
  bottom:0;
  left:0;
  width:1px;
  height:50%;
  background:#eee
}
.cesium-timeline-ticSub{
  position:absolute;
  bottom:0;
  left:0;
  width:1px;
  height:33%;
  background:#aaa
}
.cesium-timeline-ticTiny{
  position:absolute;
  bottom:0;
  left:0;
  width:1px;
  height:25%;
  background:#888
}
.cesium-timeline-icon16{
  display:block;
  position:absolute;
  width:16px;
  height:16px;
  background-image:url(data:text/plain;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAQCAYAAAB3AH1ZAAAAAXNSR0IArs4c6QAAAAZiS0dEAP8A/wD/oL2nkwAAAAlwSFlzAAALEwAACxMBAJqcGAAAAAd0SU1FB9sIDBITKIVzLEMAAAKNSURBVEjHxdXNSxRhHAfw7zzrqhuoWJnSkrippUVSEKsHI9BTUYdAJA/RoYMREV26rAdn6tAfUARi16hQqkOBQRgUEYFWEC3OwczMjdZd92VmdWfmeelgTjO7q7gb0VzmmZnn85vvPPPMM8B/3qTcE2PPpuTZKB1eWuUQACgXYACYwVFbCTTVeZXB/i55o4LFelcAZfStYD4vpAoPGAGo4GBcQEgSOAUMQyAezwK6iQfDPXnhS/FkHZ+/8VLMWxxqWkfH3gbMRNOYi2roavbja0zHQmoFPYf8ED4Ko4aivm9MOG/u9I8mwrafeK7a/tVrNc/bARYN5noadeq7q0342vXw9CIMU6BmW8rVP9cPBPe52uu+v3O/y9sB4gkTWs6Qsk0mj5ExXMelejvA8WafYmkmGPHanTijdtvif8rx5RiCjdWKs2Cp3jWRDl96KhrbqlBeJqBOLyLQXg0IgbkZDS0dO8EZxZfPSTA9jvDDK3mT0OmP1FXh3XwEEAKdTX5MRWLgjCK4pwH3xt/YnjgLHAv4lHTCAKMMu/wV+KZGob6PoKyMQ0+sgBpZVJZn0NterxQaVqef/DRn+/EXYds/mZx2eVeAW9d65dhCEsaKCb7K8HH0gqTevyh9GDkn0VULRiaLzJKGBu9swfdaiie5RVo9ESURN8E8BE0n7ggACJy8KzghSCzp6DmwWxkaCm24EBXr8wI8Hrkq06QBiRC0t24HALS11IBTCyJl4vb1AXmzpbVYTwoVOXN0h7L8Mwtm8bXPybIQ/5FCX3dA2cr6XowvGCA02CvztAnz9+JiZk1AMxG6fEreSoBiPNmoyNnuWiWVzAIAtISO08E6pZi/3N96AIDn4E3h3P8L/wshP+txtEs4JAAAAABJRU5ErkJggg==);
  background-repeat:no-repeat
}
.cesium-viewer{
  font-family:sans-serif;
  font-size:16px;
  overflow:hidden;
  display:block;
  position:relative;
  top:0;
  left:0
}
.cesium-viewer,.cesium-viewer-cesiumWidgetContainer{
  width:100%;
  height:100%
}
.cesium-viewer-bottom{
  display:block;
  position:absolute;
  bottom:0;
  left:0;
  padding-right:5px
}
.cesium-viewer .cesium-widget-credits{
  display:inline;
  position:static;
  bottom:auto;
  left:auto;
  padding-right:0;
  color:#fff;
  font-size:10px;
  text-shadow:0 0 2px #000
}
.cesium-viewer-timelineContainer{
  position:absolute;
  bottom:0;
  left:169px;
  right:29px;
  height:27px;
  padding:0;
  margin:0;
  overflow:hidden;
  font-size:14px
}
.cesium-viewer-animationContainer{
  position:absolute;
  bottom:0;
  left:0;
  padding:0;
  width:169px;
  height:112px
}
.cesium-viewer-fullscreenContainer,.cesium-viewer-vrContainer{
  position:absolute;
  bottom:0;
  right:0;
  padding:0;
  width:29px;
  height:29px;
  overflow:hidden
}
.cesium-viewer-toolbar{
  display:block;
  position:absolute;
  top:5px;
  right:5px
}
.cesium-viewer-cesiumInspectorContainer{
  display:block;
  position:absolute;
  top:50px;
  right:10px
}
.cesium-viewer-geocoderContainer{
  position:relative;
  display:inline-block;
  margin:0 3px
}
.cesium-viewer-cesium3DTilesInspectorContainer{
  display:block;
  position:absolute;
  top:50px;
  right:10px;
  max-height:calc(100% - 120px);
  box-sizing:border-box;
  overflow-y:auto;
  overflow-x:hidden
}
.cesium-credit-textContainer,.cesium-widget-credits,.dxrs-slidersContainer>.slide:nth-child(2),.dxrs-slidersContainer>path{
  display:none!important
}

/*purgecss end ignore*/</style>
  </head>
  <body >
    <div data-server-rendered="true" id="__nuxt"><!----><div id="__layout"><div><div class="flex flex-col h-screen justify-between"><div id="topNav" class="w-full"><div class="bg-gradient-to-b from-white to-gray-100 bg-opacity-50 p-2 md:p-4"><div class="flex justify-between items-center"><div class="flex space-x-3"><a href="https://www.adpc.net/" target="_blank"><img src="images/adpc.png" class="w-auto h-6 md:h-10"></a></div> <div><a href="https://servir.adpc.net/" target="_blank"><img src="images/servir-mekong.png" class="w-auto h-6 md:h-10"></a></div></div></div> <div class="p-2 md:p-4 md:py-2" style="background: #455a64"><div class="flex justify-between"><div class="text-white text-md hidden md:block"><a href="/" aria-current="page" class="nuxt-link-exact-active nuxt-link-active">Landslide Hazard Assessment for Situational Awareness for Lower Mekong Region (LHASA-Mekong)</a></div> <div class="flex space-x-6 items-center"><a href="/" aria-current="page" class="text-white text-sm nuxt-link-exact-active nuxt-link-active">Home</a> <a href="/map" class="text-white text-sm">Map Viewer</a> <div class="relative"><button id="dropdownDefault" data-dropdown-toggle="dropdown" type="button" class="text-white text-sm text-center inline-flex items-center">Resources <svg aria-hidden="true" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" class="ml-2 w-4 h-4"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path></svg></button> <div id="dropdown" class="absolute z-10 w-40 top-8 right-0 bg-white rounded divide-y divide-gray-100 shadow dark:bg-gray-700 hidden"><ul aria-labelledby="dropdownDefault" class="py-1 text-sm text-gray-700 dark:text-gray-200"><li><a href="/documents/Landslide Hazard Assessment for Situational Awareness (LHASA).pdf" target="_blank" class="block py-2 px-4 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white">Technical Note</a></li> <li><a href="#" class="block py-2 px-4 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white">Publications</a></li> <li><a href="#" class="block py-2 px-4 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white">User Guide</a></li></ul></div></div> <div class="text-white cursor-pointer hidden">
            Menu
          </div></div></div></div></div> <main><div class="relative overflow-hidden bg-no-repeat bg-cover" style="\n          background-position: 50%;\n          background-image: url('/images/in-landslide_14.jpg');\n          height: 600px;\n        "><div class="absolute top-0 right-0 bottom-0 left-0 w-full h-full overflow-hidden bg-fixed bg-black bg-opacity-50"><div class="justify-center items-center flex flex-col-reverse md:flex-row h-full"><div class="w-full md:w-1/2 items-center text-cen"></div> <div class="w-full md:w-1/2 flex items-center content-center p-4 md:p-0"><div class="w-full md:w-3/4 text-center md:text-right"><h1 class="text-white font-bold text-6xl">LHASA-Mekong</h1> <p class="mt-6 text-white font-semibold text-xl">The LHASA-Mekong incorporates Earth Observation (EO)-based products and Artificial Intelligence (AI) models in a flexible decision  support system to quantify landslide hazard and exposure over the Lower Mekong Region</p> <div class="mt-12"><a href="/map" class="py-3 px-6 text-lg font-bold text-black bg-orange-700 rounded-full">LAUNCH TOOL</a></div></div></div></div></div></div> <div class="py-12"><div class="container mx-auto"><h2 class="font-bold text-2xl">Application Purpose</h2> <p class="font-normal leading-5 mt-4">The LHASA-Mekong maps areas of potential landslide hazard in real-time to mitigate disaster risk in the Lower Mekong Region (LMR). The application incorporates 
          landslide inventories within a machine-learning framework to estimate the relative probability of occurrence. The decision support tool relies on the following variables: 
          slope, relief, distance to rivers, the distance to roads, lithological strength, precipitation, and soil moisture. Precipitation is estimated using the Integrated Multi-Satellite 
          Retrievals for Global Precipitation Measurement (GPM-IMERG), while precipitation forecasts are derived from CHIRPS-GEFS, which merges observations from the 
          Climate Hazards Group Infrared Precipitation with Stations (CHIRPS) data set with the Global Ensemble Forecast System (GEFS). It also estimates the potential exposure 
          of local communities to landslide hazards. The model has been validated with reference to new inventories of rainfall-triggered landslide events. LHASA-Mekong is open-source 
          and produces landslide probability at a 1-kilometer resolution.</p></div></div> <div class="py-6"><div class="container mx-auto"><h2 class="font-bold text-2xl">Landslide Dashboard</h2> <div class="grid grid-cols-3 mt-4 gap-5"></div></div></div> <div class="py-6"><div class="container mx-auto"><h2 class="font-bold text-2xl">Our Partners</h2></div> <div class="container mx-auto mt-4 md:p-0"><div class="flex justify-between"><div class="items-center content-start text-center my-4"><img src="/images/SIG-Horizontal_2015-1-1.png" class="h-12 mx-auto"></div> <div class="items-center content-center text-center my-4"><img src="/images/SEI-Master-Logo-Extended-Green-RGB.png" class="h-16 mx-auto"></div> <div class="items-center content-end text-center my-4"><img src="/images/deltares-logo.png" class="h-14 mx-auto"></div></div></div></div></main> <footer><div class="py-8 mt-12" style="background-color:#f1f1f1"><div class="container flex justify-between md:flex mx-auto"><div class="w-full md:w-2/4 px-4 md:px-0"><img src="/images/servir-mekong.png" class="w-64"> <p class="font-bold">ASIAN DISASTER PREPAREDNESS CENTER (ADPC)</p> <p class="text-sm"> 
            SM Tower, 24th Floor, 979/69 Paholyothin Road, Samsen Nai Phayathai,
            Bangkok 10400 Thailand
            <ul><li>BTS Skytrain: Sanam Pao, Exit 1</li> <li>Phone: <a href="tel:+6622980681">+66 2 298 0681-92</a></li> <li>Fax: <a href="tel:+6622980012">+66 2 298 0012</a></li> <li>For technical queries: <a href="mailto:miguel.barajas@adpc.net">miguel.barajas@adpc.net</a></li></ul></p></div> <div class="w-full md:w-1/4 px-4 text-right"><p class="font-bold">Disclaimer</p> <p class="leading-4 text-xs">SERVIR-SEA, NASA, USAID and ADPC make no express or implied warranty of this data as to the merchantability or fitness for  a particular purpose. SERVIR-SEA, NASA, USAID and ADPC make no express or implied warranty as to the accuracy of the map or as to the merchantability or fitness for a particular purpose of the data. Neither the US Government nor its contractors shall be liable for special, consequential or incidental damages attributed to this data.</p></div></div></div> <div class="text-right" style="background:#19293b"><div class="container mx-auto py-2 align-middle"><p class="text-xs text-white text-center">© 2022 Asian Disaster Preparedness Center (ADPC). All Rights Reserved</p></div></div></footer></div></div></div></div><script>window.__NUXT__=(function(a,b){return {layout:"default",data:[{}],fetch:{},error:a,serverRendered:true,routePath:b,config:{_app:{basePath:b,assetsPath:"\u002F_nuxt\u002F",cdnURL:a}}}}(null,"\u002F"));</script><script src="/_nuxt/e40774e.js" defer></script><script src="/_nuxt/8ed6756.js" defer></script><script src="/_nuxt/1e44861.js" defer></script><script src="/_nuxt/1d6c15e.js" defer></script><script src="/_nuxt/cd47793.js" defer></script><script src="/_nuxt/948513d.js" defer></script>
  </body>
</html>
