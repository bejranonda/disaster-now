HTTP/1.1 200 Connection Established

HTTP/2 407 
server: nginx
date: Fri, 23 Oct 2026 19:57:34 GMT
content-type: application/json
content-length: 50
access-control-allow-origin: *
access-control-expose-headers: Content-Range,X-Request-Id
vary: Origin
x-kong-upstream-latency: 2
x-kong-proxy-latency: 0
via: kong/3.7.1
x-kong-request-id: 81a09b11e6d1f504c351f65be7667157

