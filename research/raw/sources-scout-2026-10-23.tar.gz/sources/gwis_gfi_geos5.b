GetFeatureInfo results:

Layer 'nasa_geos5.query'
  Feature 0: 
    x = '99.0625'
    y = '18.75'
    value_0 = '0.59724396'
    value_1 = '71.618652'
    value_2 = '8.7514973'
    value_3 = '78.335648'
    value_4 = '0.82990611'
    value_5 = '13.681752'
    value_list = '0.59724396,71.618652,8.7514973,78.335648,0.82990611,13.681752'
    red = '0'
    green = '71'
    blue = '8'
