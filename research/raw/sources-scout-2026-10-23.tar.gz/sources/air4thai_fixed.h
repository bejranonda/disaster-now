HTTP/1.1 200 Connection Established

HTTP/1.1 200 OK
Date: Fri, 23 Oct 2026 20:03:34 GMT
Server: Apache/2
X-Powered-By: PHP/5.3.29
Vary: Accept-Encoding,User-Agent
Content-Encoding: gzip
Content-Length: 17298
Connection: close
Content-Type: application/json; charset=UTF-8

