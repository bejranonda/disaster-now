//Find Value from geojson.io (polygon);
var startGeoJson = {
    "type": "FeatureCollection",
    "features": [
        {
            "type": "Feature",
            "properties": {},
            "geometry": {
                "type": "Point",
                "coordinates": [
                    96.3720703125,
                    5.00339434502215
                ]
            }
        },
        {
            "type": "Feature",
            "properties": {},
            "geometry": {
                "type": "Point",
                "coordinates": [
                    106.69921875,
                    20.981956742
                ]
            }
        }
    ]
};
var buttomLeftCoords = [97.386, 5.624]; //96.3720703125, 5.00339434502215, //[5.624, 97.386, 20.463, 105.609]
var topRightCoords = [105.609, 20.463]; //106.69921875, 20.981956742
var defaultMapCoords = [100.5018, 13.7563]; //Bangkok Coords, from Google

//Utility Functions
function addGeoJsonPointToLeaflet(layer, map, geoJson) {
    geoJson.features.forEach(feature => {
        layer.geoJSON(feature).addTo(map);
    });
}

//Drawn geoJSON marker to Leaflet map
function addGeoJsonPolygonToLeaflet(layer, map, geoJson) {
    layer.geoJSON(geoJson).addTo(map);
}

////Drawn geoJSON polygon to Leaflet map
function findDistanceBetweenTwoCoords(a, b) {
    var from = turf.point(a);
    var to = turf.point(b);
    var result = Math.floor(turf.distance(from, to, cellOptions));
    return result;
}

function findGridColumnNumber(gridDistance, customCellSize) {
    /*The grid width and height are the number of vertices in the grid. The grid data is for the elements, 
    *so it will have one less row and one less column than the vertex information.
    *ref: "https://opengeoscience.github.io/geojs/tutorials/grid/"*/
    var calCellSize = customCellSize;

    if (typeof (calCellSize) === 'undefined' || calCellSize == null) {
        calCellSize = cellSize;
    }

    var result = Math.floor((gridDistance / calCellSize) + 1);
    return result;
}

//Wind direction
//Head arrow point to the direction of the wind come from.
function convertWindDegreeToRadius(val) {
    return (val + 90) * (Math.PI / 180);
}

//direction ref: "https://uni.edu/storm/Wind%20Direction%20slide.pdf"
function getWindToDirection(degree) {
    if (degree > 341) return convertWindDegreeToRadius(0); //N
    if (degree > 329) return convertWindDegreeToRadius(337.5); //NNW
    if (degree > 309) return convertWindDegreeToRadius(315); //NW
    if (degree > 289) return convertWindDegreeToRadius(292.5); //WNW
    if (degree > 259) return convertWindDegreeToRadius(270); // W
    if (degree > 239) return convertWindDegreeToRadius(247.5); //WSW
    if (degree > 219) return convertWindDegreeToRadius(225); //SW
    if (degree > 199) return convertWindDegreeToRadius(202.5); //SSW
    if (degree > 169) return convertWindDegreeToRadius(180); //S
    if (degree > 149) return convertWindDegreeToRadius(157.5); //SSE
    if (degree > 129) return convertWindDegreeToRadius(135); //SE
    if (degree > 109) return convertWindDegreeToRadius(112.5); //ESE
    if (degree > 79) return convertWindDegreeToRadius(90); //E
    if (degree > 59) return convertWindDegreeToRadius(67.5); //ENE
    if (degree > 39) return convertWindDegreeToRadius(45); //NE
    if (degree > 19) return convertWindDegreeToRadius(22.5); //NNE
    if (degree > 0) return convertWindDegreeToRadius(0); //N
    if (degree == 0) return 0;
}
//End wind direction

function findNearestPosition(latitude, longitude, data) {
    for (let i = 0; i < data.length; i++) {
        data[i].distance = findDistanceBetweenTwoCoords([longitude, latitude], [data[i].lon, data[i].lat]);
    }

    var nearestPosition = data.reduce(function (prev, curr) {
        return prev.distance < curr.distance ? prev : curr;
    });

    return [nearestPosition];
}

var bboxPolygon2 = turf.bboxPolygon([87.5, 0.0, 115.0, 25.0]);
var index1 = [105.6093, 20.3587];
var index2 = [105.6093, 20.3066];
var index156 = [105.5537, 20.3587];


//calculate mesh object from grid value
function findMeshObject(data, cellSize) {
    var minX = data.minX;
    var minY = data.minY;
    var maxX = data.maxX;
    var maxY = data.maxY;
    var bbox = [minX, minY, maxX, maxY];

    //find polygon of rectangle
    var bboxPolygon = turf.bboxPolygon(bbox);

    var minPointCoordinateXY = bboxPolygon.geometry.coordinates[0][0];
    var boundPointCoordinateX = bboxPolygon.geometry.coordinates[0][1];
    var boundPointCoordinateY = bboxPolygon.geometry.coordinates[0][3];

    //find distance width and height
    var distanceHeight = findDistanceBetweenTwoCoords(minPointCoordinateXY, boundPointCoordinateX);
    var distanceWidth = findDistanceBetweenTwoCoords(minPointCoordinateXY, boundPointCoordinateY);



    var gridHeight = findGridColumnNumber(distanceHeight, cellSize);
    var gridWidth = findGridColumnNumber(distanceWidth, cellSize);

}

//End Utility Functions

var extent = [buttomLeftCoords[0], buttomLeftCoords[1], topRightCoords[0], topRightCoords[1]];

// POC API TMD area/box
var extentAreaBox = [buttomLeftCoords[0], buttomLeftCoords[1], topRightCoords[0], topRightCoords[1]];
// POC API TMD area/box  5
var cellSize = 5; //Set based on resource.
var cellOptions = {
    units: 'kilometers'
};
var pointGrid = turf.pointGrid(extent, cellSize, cellOptions);
var squareGrid = turf.squareGrid(extent, cellSize, cellOptions);

// POC API TMD area/box
var pointGridAreaBox = turf.pointGrid(extentAreaBox, cellSize, cellOptions);

var firstSquareGridCoords = squareGrid.features[0].geometry.coordinates[0];
var meshObject = {
    gridHeight: 0,
    gridWidth: 0,
    x0: 0,
    y0: 0,
    dx: 0,
    dy: 0,
    position: []
};

//Find polygon to get all extends coords
var polygonExtentBox = turf.bboxPolygon(extent);
var extendCoords = turf.getCoords(polygonExtentBox);

//Find gridWidth and gridHeight
var gridWidthDistance = findDistanceBetweenTwoCoords(extendCoords[0][0], extendCoords[0][3]);
var gridHeightDistance = findDistanceBetweenTwoCoords(extendCoords[0][0], extendCoords[0][1]);

//Mesh Object
meshObject.gridWidth = findGridColumnNumber(gridWidthDistance);
meshObject.gridHeight = findGridColumnNumber(gridHeightDistance);
meshObject.dx = firstSquareGridCoords[3][0] - firstSquareGridCoords[0][0];
meshObject.dy = firstSquareGridCoords[1][1] - firstSquareGridCoords[0][1];
meshObject.x0 = firstSquareGridCoords[0][0];
meshObject.y0 = firstSquareGridCoords[0][1];


//Check Values

function getStormType(windSpeed) {
    if (windSpeed >= 108) {
        return "พายุไต้ฝุ่น";
    } else if (windSpeed >= 63) {
        return "พายุโซนร้อน";
    } else if (windSpeed >= 30) {
        return "พายุดีเปรสชั่น";
    } else if (windSpeed >= 10) {
        return "หย่อมความกดอากาศต่ำ";
    } else {
        return "";
    }
    // return windSpeed >= 63 ? "พายุโซนร้อน" : "พายุดีเปรสชั่น";
}

function styleHurricane(feature) {
    // debugger

    //if (feature.properties.isFuture) {
    //    // debugger
    //    return {
    //        //fillColor: 'red',
    //        fileColor: 'rgba(0,0,0,0)',
    //        weight: 1,
    //        opacity: 0.87,
    //        color: 'rgba(0, 0, 0, 1)',
    //        dashArray: '8',
    //        fillOpacity: 0.38
    //    };
    //}
    //return {
    //    //fillColor: 'red',
    //    fileColor: 'rgba(235, 20, 10,0)',
    //    weight: 1,
    //    opacity: 0.6,
    //    color: 'rgba(235, 20, 10,0)',
    //    dashArray: '0',
    //    fillOpacity: 0.6
    //};

    return {
        weight: 1,
        opacity: 0.2,
        color: 'red',
        //dashArray: '8',
    };
}

function styleLine(feature) {
    if (feature.properties.isFuture) {
        return {
            //fillColor: getRandomColor(),
            //fileColor: 'blue',
            //weight: 1,
            //opacity: 0.6,
            color: 'red',
            dashArray: '8',
            //fillOpacity: 0.38
        };
    }
    return {
        //fillColor: getRandomColor(),
        //fileColor: 'blue',
        //weight: 1,
        //opacity: 0.6,
        color: 'black',
        dashArray: '',
        //fillOpacity: 0.38
    };
}

function styleCircle(feature) {
    //if (feature.isFuture) {
    //    return {
    //        //fillColor: '#0000FF',
    //        weight: 1,
    //        color: '#0000FF',
    //    };
    //}
    return {
        ////fillColor: getRandomColor(),
        //fileColor: 'transparent',
        //weight: 0,
        //opacity: 0,
        //color: 'transparent',
        //dashArray: '',
        //fillOpacity: 0
        fillColor: 'red',
        weight: 1,
        opacity: 0.2,
        color: 'red',
    };
}



//makehurricane.js - given a geoJson polyline feature, starting radius in km, 
//and increment in km, uses turf.js to return a hurricane path as a geoJson polygon feature.

var makeHurricane = function (areaPolygon, areaRadiusPolygon) {
    var points = areaPolygon;
    var numPoints = areaPolygon.length;

    var segments = [];


    //create segments for each pair of points
    for (var i = 1; i < numPoints; i++) {

        segments.push(makeSegment(points[i - 1], areaRadiusPolygon[i - 1], points[i], areaRadiusPolygon[i]));

    }

    //union together all segments
    var hurricane;
    segments.forEach(function (segment, i) {
        (i == 0 ? hurricane = segment : hurricane = turf.union(hurricane, segment));
    });


    return hurricane;

    //pass in two geoJson point features and two radii, create buffer for each point, convex hull all
    function makeSegment(coord0, radius0, coord1, radius1) {


        var feature0 = turf.point(coord0);
        var feature1 = turf.point(coord1);

        var radiusArea0 = radius0 > 0 ? radius0 : 0.1;
        var radiusArea1 = radius1 > 0 ? radius1 : 0.1;

        var buffer0 = turf.buffer(feature0, radiusArea0, { units: 'kilometers' });

        var buffer1 = turf.buffer(feature1, radiusArea1, { units: 'kilometers' });


        var result = convex(buffer0, buffer1);


        return result;
    }

    //pass in two geoJson polygon features, create one big featurecollection of points,
    //convex hull the featurecollection.  returns a "segment" of the hurricane
    function convex(polygon0, polygon1) {
        var points = [];

        polygon0.geometry.coordinates[0].map(function (coord) {
            points.push(turf.point(coord));
        })

        polygon1.geometry.coordinates[0].map(function (coord) {
            points.push(turf.point(coord));
        })

        var collection = turf.featureCollection(points);

        var hull = turf.convex(collection);

        return hull;
    }
}

function iconMarker(color) {
    const markerHtmlStyles = `
          background-color: ${color};
          width: 1.5rem;
          height: 1.5rem;
          display: block;
          position: relative;
          border-radius: 3rem 3rem 0;
          transform: rotate(45deg);
          border: 1px solid #FFFFFF`;
    const icon = L.divIcon({
        className: "my-custom-pin",
        iconAnchor: [0, 24],
        labelAnchor: [-6, 0],
        popupAnchor: [0, -36],
        html: `<span style="${markerHtmlStyles}" />`
    })
    return icon;
}

function showStormWindSpeed(data, predictData, isPredict) {
    if (isPredict == false) return data;
    if (isPredict == true) return predictData;
}

