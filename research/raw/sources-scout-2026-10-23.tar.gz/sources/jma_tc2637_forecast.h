HTTP/1.1 200 Connection Established

HTTP/2 200 
content-type: application/json
server: AmazonS3
last-modified: Fri, 23 Oct 2026 19:01:21 GMT
x-amz-expiration: expiry-date="Wed, 28 Oct 2026 00:00:00 GMT", rule-id="PublicBucketLifecycleRule50"
content-encoding: br
x-amz-server-side-encryption: AES256
date: Fri, 23 Oct 2026 19:54:43 GMT
cache-control: max-age=60
etag: W/"06d5c28b05d8f2ca74803cfe82af4d3e"
vary: Accept-Encoding
via: 1.1 7c5c7d2f4654492c5282cf92408afc02.cloudfront.net (CloudFront)
age: 6
x-xss-protection: 1; mode=block
referrer-policy: strict-origin-when-cross-origin
content-security-policy: script-src 'self' 'unsafe-inline' 'unsafe-eval' www.jma.go.jp www.jma-net.go.jp js.jma.go.jp www.data.jma.go.jp ds.data.jma.go.jp www.google.com www.gstatic.com jma.genieesspv.jp pagead2.googlesyndication.com code.jquery.com ajaxzip3.github.io cdn.jsdelivr.net ajax.aspnetcdn.com code.createjs.com unpkg.com cdnjs.cloudflare.com ajax.googleapis.com platform.twitter.com github.githubassets.com maps.gsi.go.jp img.gsspat.jp; frame-ancestors 'self' www.mlit.go.jp www.data.jma.go.jp ds.data.jma.go.jp www.jma-net.go.jp www.pref.tokushima.lg.jp www.cgr.mlit.go.jp river-bosai.ktr.mlit.go.jp mie-mizubosai.go.jp sim.mie-mizubosai.go.jp mobile.mie-mizubosai.go.jp yoshino-drs.skr.mlit.go.jp view.mie-mizubosai.cbr.mlit.go.jp sim.mie-mizubosai.cbr.mlit.go.jp mobile.mie-mizubosai.cbr.mlit.go.jp
x-content-type-options: nosniff
strict-transport-security: max-age=31536000; preload
access-control-allow-origin: *
access-control-allow-headers: X-Requested-With
x-amz-cf-pop: ORD51-P1
x-amz-cf-id: bp9Jv76bbchtLm0ocpN9kj4qFToOr4NwcltOW5KQ6yTsbF2fh3ctPQ==

