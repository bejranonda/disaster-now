HTTP/1.1 200 Connection Established

HTTP/2 200 
content-type: text/plain
content-length: 1774
server: N/A
date: Fri, 23 Oct 2026 19:54:41 GMT
access-control-allow-origin: *
access-control-allow-methods: GET, HEAD
access-control-expose-headers: ETag
access-control-max-age: 1800
last-modified: Fri, 23 Oct 2026 14:43:14 GMT
etag: "8ca28cbd0ee7bfb4873c7f1f862e4a69"
x-amz-server-side-encryption: AES256
x-amz-version-id: d.IHx6UnZ9dJYWcMsCy_LaQBTyPtK8uo
accept-ranges: bytes
vary: Origin
via: 1.1 59ab23525b194513c0e91bb1efc6f606.cloudfront.net (CloudFront)
x-amz-cf-pop: ORD51-P2
x-amz-cf-id: eWOQAH2ts9hQL2rELXEwWOmGnezyZYeXpxalsK39Ii9L3flxVBxYLg==
x-xss-protection: 1; mode=block
x-frame-options: SAMEORIGIN
referrer-policy: same-origin
content-security-policy: frame-ancestors 'self'
x-content-type-options: nosniff
strict-transport-security: max-age=31536000; includeSubDomains; preload

