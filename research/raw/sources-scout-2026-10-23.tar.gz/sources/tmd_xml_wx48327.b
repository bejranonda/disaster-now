<?xml version="1.0" encoding="utf-8"?>
<rss xmlns:content="http://purl.org/rss/1.0/modules/content/" xmlns:dc="http://purl.org/dc/elements/1.1/" version="2.0">
  <channel>
    <title>รายงานสภาวะอากาศ - สกษ.เชียงใหม่ : อ.เมือง จ.เชียงใหม่</title>
    <link>http://www.tmd.go.th</link>
    <description>รายงานสภาวะอากาศ โดย กรมอุตุนิยมวิทยา กระทรวงดิจิทัลเพื่อเศรษฐกิจและสังคม</description>
    <language>th-TH</language>
    <copyright>Copyright 2006,Thai Meteorological Deaprtment</copyright>
    <ttl>20</ttl>
    <item>
      <title>รายงานสภาวะอากาศ - สกษ.เชียงใหม่ : อ.เมือง จ.เชียงใหม่ วันที่ : 24/10/2026 เวลา 01:00 นาฬิกา </title>
      <pubDate>Sat, 24 Oct 2026 01:00:00 +07:00</pubDate>
      <guid>48327</guid>
      <link>http://www.tmd.go.th/api/xml/weather-report?stationnumber=48327</link>
      <author>กรมอุตุนิยมวิทยา</author>
      <description><![CDATA[<b> อุณหภูมิ : </b>26.2 องศาเซลเซียส <br/><b>ความชื้นสัมพัทธ์ : </b> 79 % <br/><b>ความกดอากาศ : </b> 1009.29 มิลลิบาร์ <br/><b>ทิศทางลม : </b> ลมสงบ <br/><b>ทัศนวิสัย : </b>10.0 กิโลเมตร <br/><b>ลักษณะอากาศ : </b>ท้องฟ้าโปร่ง<br/><b>ฝนสะสมวันนี้ : </ b >0.0 มิลลิเมตร<br/><b>พระอาทิตย์ขึ้นเช้าพรุ่งนี้: </b>06:21 น. <br/><b>พระอาทิตย์ตกเย็นวันนี้: </b>17:55 น.]]></description>
    </item>
  </channel>
</rss>