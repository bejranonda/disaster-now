HTTP/1.1 200 Connection Established

HTTP/1.1 200 OK
Date: Fri, 23 Oct 2026 20:00:27 GMT
Last-Modified: Thu, 23 Jan 2025 08:39:01 GMT
ETag: "80b0-62c5b8abde1fa"
Accept-Ranges: bytes
Content-Length: 32944
Connection: close
Content-Type: text/html; charset=UTF-8
Strict-Transport-Security: max-age=16000000
Cache-control: private
X-Frame-Options: SAMEORIGIN
X-Content-Type-Options: nosniff
X-XSS-Protection: 1; mode=block

