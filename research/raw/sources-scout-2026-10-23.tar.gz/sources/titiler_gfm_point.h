HTTP/1.1 200 Connection Established

HTTP/2 500 
date: Fri, 23 Oct 2026 19:59:06 GMT
server: uvicorn
content-length: 67
content-type: application/json
access-control-allow-origin: *
access-control-allow-credentials: true
content-encoding: gzip
vary: Accept-Encoding

