<!DOCTYPE html>
<!--[if IE 7]>
<html class="ie ie7" lang="en-US">
<![endif]-->
<!--[if IE 8]>
<html class="ie ie8" lang="en-US">
<![endif]-->
<!--[if !(IE 7) & !(IE 8)]><!-->
<html lang="en-US">
<!--<![endif]-->
<head>
<meta name='robots' content='index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1' />

	<!-- This site is optimized with the Yoast SEO plugin v23.6 - https://yoast.com/wordpress/plugins/seo/ -->
	<meta name="description" content="Landing page for ASMC" />
	<link rel="canonical" href="https://asmc.asean.org/home/" />
	<meta property="og:locale" content="en_US" />
	<meta property="og:type" content="article" />
	<meta property="og:title" content="Home - Regional Haze Situation - ASMC" />
	<meta property="og:description" content="Landing page for ASMC" />
	<meta property="og:url" content="https://asmc.asean.org/home/" />
	<meta property="og:site_name" content="ASMC" />
	<meta property="article:modified_time" content="2026-10-16T09:20:25+00:00" />
	<meta name="twitter:card" content="summary_large_image" />
	<meta name="twitter:label1" content="Est. reading time" />
	<meta name="twitter:data1" content="3 minutes" />
	<script type="application/ld+json" class="yoast-schema-graph">{"@context":"https://schema.org","@graph":[{"@type":"WebPage","@id":"https://asmc.asean.org/home/","url":"https://asmc.asean.org/home/","name":"Home - Regional Haze Situation - ASMC","isPartOf":{"@id":"https://asmc.asean.org/#website"},"datePublished":"2015-04-18T21:00:46+00:00","dateModified":"2026-10-16T09:20:25+00:00","description":"Landing page for ASMC","breadcrumb":{"@id":"https://asmc.asean.org/home/#breadcrumb"},"inLanguage":"en-US","potentialAction":[{"@type":"ReadAction","target":["https://asmc.asean.org/home/"]}]},{"@type":"BreadcrumbList","@id":"https://asmc.asean.org/home/#breadcrumb","itemListElement":[{"@type":"ListItem","position":1,"name":"Home","item":"https://asmc.asean.org/"},{"@type":"ListItem","position":2,"name":"Home &#8211; Regional Haze Situation"}]},{"@type":"WebSite","@id":"https://asmc.asean.org/#website","url":"https://asmc.asean.org/","name":"ASMC","description":"ASEAN Specialized Meteorological Centre","potentialAction":[{"@type":"SearchAction","target":{"@type":"EntryPoint","urlTemplate":"https://asmc.asean.org/?s={search_term_string}"},"query-input":{"@type":"PropertyValueSpecification","valueRequired":true,"valueName":"search_term_string"}}],"inLanguage":"en-US"}]}</script>
	<!-- / Yoast SEO plugin. -->


<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel="alternate" type="application/rss+xml" title="ASMC &raquo; Feed" href="https://asmc.asean.org/feed/" />
<link rel="alternate" type="application/rss+xml" title="ASMC &raquo; Comments Feed" href="https://asmc.asean.org/comments/feed/" />
<link rel="alternate" type="application/rss+xml" title="ASMC &raquo; Home &#8211; Regional Haze Situation Comments Feed" href="https://asmc.asean.org/home/feed/" />
<script type="text/javascript">
/* <![CDATA[ */
window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/15.0.3\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/15.0.3\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/asmc.asean.org\/wp-includes\/js\/wp-emoji-release.min.js?ver=6.5.12"}};
/*! This file is auto-generated */
!function(i,n){var o,s,e;function c(e){try{var t={supportTests:e,timestamp:(new Date).valueOf()};sessionStorage.setItem(o,JSON.stringify(t))}catch(e){}}function p(e,t,n){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);var t=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data),r=(e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(n,0,0),new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data));return t.every(function(e,t){return e===r[t]})}function u(e,t,n){switch(t){case"flag":return n(e,"\ud83c\udff3\ufe0f\u200d\u26a7\ufe0f","\ud83c\udff3\ufe0f\u200b\u26a7\ufe0f")?!1:!n(e,"\ud83c\uddfa\ud83c\uddf3","\ud83c\uddfa\u200b\ud83c\uddf3")&&!n(e,"\ud83c\udff4\udb40\udc67\udb40\udc62\udb40\udc65\udb40\udc6e\udb40\udc67\udb40\udc7f","\ud83c\udff4\u200b\udb40\udc67\u200b\udb40\udc62\u200b\udb40\udc65\u200b\udb40\udc6e\u200b\udb40\udc67\u200b\udb40\udc7f");case"emoji":return!n(e,"\ud83d\udc26\u200d\u2b1b","\ud83d\udc26\u200b\u2b1b")}return!1}function f(e,t,n){var r="undefined"!=typeof WorkerGlobalScope&&self instanceof WorkerGlobalScope?new OffscreenCanvas(300,150):i.createElement("canvas"),a=r.getContext("2d",{willReadFrequently:!0}),o=(a.textBaseline="top",a.font="600 32px Arial",{});return e.forEach(function(e){o[e]=t(a,e,n)}),o}function t(e){var t=i.createElement("script");t.src=e,t.defer=!0,i.head.appendChild(t)}"undefined"!=typeof Promise&&(o="wpEmojiSettingsSupports",s=["flag","emoji"],n.supports={everything:!0,everythingExceptFlag:!0},e=new Promise(function(e){i.addEventListener("DOMContentLoaded",e,{once:!0})}),new Promise(function(t){var n=function(){try{var e=JSON.parse(sessionStorage.getItem(o));if("object"==typeof e&&"number"==typeof e.timestamp&&(new Date).valueOf()<e.timestamp+604800&&"object"==typeof e.supportTests)return e.supportTests}catch(e){}return null}();if(!n){if("undefined"!=typeof Worker&&"undefined"!=typeof OffscreenCanvas&&"undefined"!=typeof URL&&URL.createObjectURL&&"undefined"!=typeof Blob)try{var e="postMessage("+f.toString()+"("+[JSON.stringify(s),u.toString(),p.toString()].join(",")+"));",r=new Blob([e],{type:"text/javascript"}),a=new Worker(URL.createObjectURL(r),{name:"wpTestEmojiSupports"});return void(a.onmessage=function(e){c(n=e.data),a.terminate(),t(n)})}catch(e){}c(n=f(s,u,p))}t(n)}).then(function(e){for(var t in e)n.supports[t]=e[t],n.supports.everything=n.supports.everything&&n.supports[t],"flag"!==t&&(n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&n.supports[t]);n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&!n.supports.flag,n.DOMReady=!1,n.readyCallback=function(){n.DOMReady=!0}}).then(function(){return e}).then(function(){var e;n.supports.everything||(n.readyCallback(),(e=n.source||{}).concatemoji?t(e.concatemoji):e.wpemoji&&e.twemoji&&(t(e.twemoji),t(e.wpemoji)))}))}((window,document),window._wpemojiSettings);
/* ]]> */
</script>
<style id='wp-emoji-styles-inline-css' type='text/css'>

	img.wp-smiley, img.emoji {
		display: inline !important;
		border: none !important;
		box-shadow: none !important;
		height: 1em !important;
		width: 1em !important;
		margin: 0 0.07em !important;
		vertical-align: -0.1em !important;
		background: none !important;
		padding: 0 !important;
	}
</style>
<link rel='stylesheet' id='wp-block-library-css' href='https://asmc.asean.org/wp-includes/css/dist/block-library/style.min.css?ver=6.5.12' type='text/css' media='all' />
<style id='classic-theme-styles-inline-css' type='text/css'>
/*! This file is auto-generated */
.wp-block-button__link{color:#fff;background-color:#32373c;border-radius:9999px;box-shadow:none;text-decoration:none;padding:calc(.667em + 2px) calc(1.333em + 2px);font-size:1.125em}.wp-block-file__button{background:#32373c;color:#fff;text-decoration:none}
</style>
<style id='global-styles-inline-css' type='text/css'>
body{--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;--wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);--wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);--wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);--wp--preset--shadow--outlined: 6px 6px 0px -3px rgba(255, 255, 255, 1), 6px 6px rgba(0, 0, 0, 1);--wp--preset--shadow--crisp: 6px 6px 0px rgba(0, 0, 0, 1);}:where(.is-layout-flex){gap: 0.5em;}:where(.is-layout-grid){gap: 0.5em;}body .is-layout-flex{display: flex;}body .is-layout-flex{flex-wrap: wrap;align-items: center;}body .is-layout-flex > *{margin: 0;}body .is-layout-grid{display: grid;}body .is-layout-grid > *{margin: 0;}:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
.wp-block-navigation a:where(:not(.wp-element-button)){color: inherit;}
:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}
:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}
.wp-block-pullquote{font-size: 1.5em;line-height: 1.6;}
</style>
<link rel='stylesheet' id='twentytwelve-fonts-css' href='https://fonts.googleapis.com/css?family=Open+Sans:400italic,700italic,400,700&#038;subset=latin,latin-ext' type='text/css' media='all' />
<link rel='stylesheet' id='twentytwelve-style-css' href='https://asmc.asean.org/wp-content/themes/asmctheme/style.css?ver=6.5.12' type='text/css' media='all' />
<!--[if lt IE 9]>
<link rel='stylesheet' id='twentytwelve-ie-css' href='https://asmc.asean.org/wp-content/themes/asmctheme/css/ie.css?ver=20121010' type='text/css' media='all' />
<![endif]-->
<script type="text/javascript" src="https://asmc.asean.org/wp-includes/js/jquery/jquery.min.js?ver=3.7.1" id="jquery-core-js"></script>
<script type="text/javascript" src="https://asmc.asean.org/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.4.1" id="jquery-migrate-js"></script>
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://asmc.asean.org/xmlrpc.php?rsd" />
<meta name="generator" content="WordPress 6.5.12" />
<link rel='shortlink' href='https://asmc.asean.org/?p=4' />
<link rel="alternate" type="application/json+oembed" href="https://asmc.asean.org/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fasmc.asean.org%2Fhome%2F" />
<link rel="alternate" type="text/xml+oembed" href="https://asmc.asean.org/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fasmc.asean.org%2Fhome%2F&#038;format=xml" />
<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style>
<!--add for GA4 -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-H51X2LHJYX"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-H51X2LHJYX');
</script>
<!--add for GA4 end -->

<link rel="shortcut icon" type="image/x-icon" href="https://asmc.asean.org/wp-content/themes/asmctheme/assets/img/favicon.ico" />
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width" />
<!--<meta http-equiv="cache-control" content="max-age=0" />
<meta http-equiv="cache-control" content="no-cache, no-store, must-revalidate" />
<meta http-equiv="expires" content="0" />
<meta http-equiv="expires" content="Tue, 01 Jan 1980 1:00:00 GMT" />
<meta http-equiv="pragma" content="no-cache" />-->

<!--Added for cache control on 28/11/2016 -->
<!-- <meta http-equiv="cache-control" content="public, max-age=60, must-revalidate" /> -->

<title>Home - Regional Haze Situation - ASMC</title>
<link rel="profile" href="http://gmpg.org/xfn/11" />
<link rel="pingback" href="https://asmc.asean.org/xmlrpc.php" />
<link href="https://asmc.asean.org/wp-content/themes/asmctheme/lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="https://asmc.asean.org/wp-content/themes/asmctheme/lib/bootstrap-datepicker/datepicker3.css" rel="stylesheet">
<link href="https://asmc.asean.org/wp-content/themes/asmctheme/lib/jquery-ui/jquery-ui.css" rel="stylesheet">
<link href="https://asmc.asean.org/wp-content/themes/asmctheme/assets/css/style.css" rel="stylesheet">
<!-- Disabling responsiveness -->
<link href="https://asmc.asean.org/wp-content/themes/asmctheme/assets/css/non-responsive.css" rel="stylesheet">
<link href="https://asmc.asean.org/wp-content/themes/asmctheme/assets/css/print.css" media="print" rel="stylesheet">
<script type="text/javascript"></script>
<script src="https://assets.wogaa.sg/scripts/wogaa.js"></script>

<script src="https://asmc.asean.org/wp-content/themes/asmctheme/lib/jquery/jquery-3.7.1.min.js"></script>
<script src="https://asmc.asean.org/wp-content/themes/asmctheme/lib/jquery-ui/jquery-ui.js"></script>
<script src="https://asmc.asean.org/wp-content/themes/asmctheme/lib/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="https://asmc.asean.org/wp-content/themes/asmctheme/lib/bootstrap-datepicker/bootstrap-datepicker.js"></script>
<script src="https://asmc.asean.org/wp-content/themes/asmctheme/assets/js/global.js"></script>     
<script src="https://asmc.asean.org/wp-content/themes/asmctheme/js/utils.js"></script>    
<script src="https://asmc.asean.org/wp-content/themes/asmctheme/lib/moment.js/moment-with-locales.js"></script> </head>

<body>

<div class="pre-loader"></div>										<link href="https://asmc.asean.org/wp-content/themes/asmctheme/styles_resizer.css" rel="stylesheet"><header>            <div class="container">                <div class="row">                    <div class="col-4" style='width:312px;'>                        <a class="logo" href="https://asmc.asean.org/home/"><img src="https://asmc.asean.org/wp-content/themes/asmctheme/assets/img/logo.png" alt="ASMC" width="312" height="79"></a>                    </div>                    <div class="col-6" style='margin-top:50px;margin-left:40px;'>						<div class="row" >							<div class="col-12 text-end">								<div class="donotresize">									<ul class="list-inline">										<li class="list-inline-item">											<div id="controls">														<span id=nowTextPercent class="donotresize"></span>												<a style="border-bottom:none;" href="#" id="decrease" class="selected">A<sup>-</sup></a>  												<a style="border-bottom:none;" href="#" id="increase">A<sup>+</sup></a>											</div>										</li>										<li class="list-inline-item"><a class="donotresize" href="https://asmc.asean.org/asmc-about/">About ASMC</a></li>										<li class="list-inline-item"><a class="donotresize" href="https://asmc.asean.org/asmc-contact-us/">Contact Us</a></li>										<li class="list-inline-item"><form role="search" method="get" id="searchform" class="searchform" action="https://asmc.asean.org/" >
	<div class="search-container">
	<button type="submit" id="searchsubmit"><img alt="search" src="https://asmc.asean.org/wp-content/themes/asmctheme/assets/img/icons/icon-search.png"></button>
	<input type="text" value="" name="s" id="s" placeholder="Search" />
	</div>
	</form>										</li>									</ul>								</div>							</div>						</div>                    </div>             <div id='asean-logo' class="col-2">								<img alt='MSS' width='79' height='79' style='margin-top:30px;margin-left:40px;' src="https://asmc.asean.org/wp-content/themes/asmctheme/assets/img/asean-logo.png"/>             </div>                          <div class="col-12">						<div class="row">							<div class="col-12 text-end">								<nav  class="main-nav navbar-expand-sm" role="navigation">									<ul class="nav navbar-nav donotresize" style='padding:0px 30px;margin-right:15px;width:100%;'>									<li class='nav-item w25'>											<a  href="#" class="navhead nav-link donotresize" data-bs-toggle="dropdown">Transboundary Haze</a>												<ul class="dropdown-menu donotresize " role="menu">                            					<li><a class="donotresize dropdown-item " href="https://asmc.asean.org/asmc-alerts/">Warnings and Alerts</a></li>                            					<li id='getLatestHazeOutlook'><a id='hazeTagReviewLink' class="donotresize dropdown-item" href='#'>Haze Review</a></li>                            					<li><a class="donotresize dropdown-item" href="https://asmc.asean.org/satellite-polar/">Satellite Images</a></li>                            					<li><a class="donotresize dropdown-item" href="https://asmc.asean.org/asmc-hotspot/">Hotspot Information</a></li>                            					<li><a class="donotresize dropdown-item" href="https://asmc.asean.org/asmc-gis-portal/">Haze Information Portal</a></li>                            					<!-- <li><a class="donotresize dropdown-item" href="https://asmc.asean.org/asmc-haze-air-quality/">Air Quality Information</a></li> -->                            					<li><a class="donotresize dropdown-item" href="https://asmc.asean.org/asmc-fire/">Fire Danger Rating System</a></li>                       </ul>										</li>									<li class='nav-item w15 ml-2P'>											<a  href="#" class="navhead nav-link donotresize" data-bs-toggle="dropdown">Weather</a>											<ul class="dropdown-menu donotresize" role="menu">                            					<li><a class="donotresize dropdown-item" href="https://asmc.asean.org/asmc-regional-weather-observation/">Regional Weather</a></li>                            					<li id='getLatestWeatherOutlook'><a id='headWeatherOutlookLink' class="donotresize dropdown-item" href='#' >Subseasonal Weather Outlook and Review</a></li>                       </ul>										</li>									<li class='nav-item w15 ml-2P'>											<a  href="#" class="navhead nav-link donotresize" data-bs-toggle="dropdown">Climate</a>											<ul class="dropdown-menu donotresize " role="menu">												<li><a class="donotresize dropdown-item" href="https://asmc.asean.org/asmc-seasonal-outlook/">Seasonal Forecast (1-month and 3-month outlook)</a></li>												<li><a class="donotresize dropdown-item" href="https://asmc.asean.org/asmc-el-nino/">El Niño / La Niña</a></li>                     </ul>										</li>									<li class='nav-item w25 ml-30'>											<a  href="#" class="navhead nav-link donotresize" data-bs-toggle="dropdown">Events & Publications</a>                     <ul class="dropdown-menu donotresize" role="menu">												<li><a id='headEventsLink' class="donotresize dropdown-item" href='#' >Events</a></li>												<li><a id='headPublicLink' class="donotresize dropdown-item" href='#' >Publication</a></li>                     </ul>										</li>									<li class='nav-item w20 ml-0''>											<a class="navhead nav-link donotresize" href="https://wis2.asmc.asean.org">Data Catalog</a>										</li>									</ul>								</nav>							</div></div></div>                </div>            </div>        </header><script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBeVymhFm8Gj3R1jHxs89gAL60A_OUjtE4&v=3.65"></script>
<div class="main">
  <style>
    a{border-bottom:0px;}
  </style>

  <div class="container">
    <p><!--div class="alert alert-warning fade show warning-bar2" role="alert">
<strong>Notice:</strong> Weather information may be temporarily unavailable or intermittent between 24 Feb 2026, 8:00 PM to 24 Feb 2026, 11:00 PM (SGT) due to scheduled system maintenance. We appreciate your understanding regarding any inconvenience this may cause.</div>


<!-- --><!--div class="alert alert-warning fade show warning-bar2" role="alert">
<strong>Notice:</strong> This website is scheduled to undergo maintenance (22 Oct 2026, 01:00 PM to 22 Oct 2026, 06:00 PM) to enhance our service to you. We appreciate your understanding regarding any inconvenience this may cause.</div>


<!-- --><!--div class="alert alert-warning fade show warning-bar2" role="alert">
<strong>Notice:</strong> This website is undergoing maintenance to enhance our service to you. We appreciate your understanding regarding any inconvenience this may cause.</div>


<!-- --><!--div class="alert alert-warning fade show warning-bar2" role="alert">
<strong>Notice:</strong> Our weather observation system is scheduled to undergo maintenance from 15 Sep 2026, 08:00 PM to 16 Sep 2026, 12:00 AM to enhance our service to you. Some weather observation data may be unavailable during this period. We appreciate your understanding regarding any inconvenience this may cause.</div>


<!-- --></p>
<p><!-- INSERT TEMPLATE HERE --></p>
<div class="warning-bar2 bg-danger">
<div class="warning-text">
<ul class="list-inline">
<li><strong> Alert Level 3 </strong> | <a href="https://asmc.asean.org/asmc-alerts/">Activation of Alert Level 3 for the Southern ASEAN Region</a></li>
<li>With the activation of Alert Level 3 for the Southern ASEAN region, the regional haze situation is updated at 0300 UTC and 0900 UTC.</li>
</ul>
</div>
</div>
<p><!-- TEMPLATE DIFFERENT TAGS FOR DIFFERENT ALERT LEVELS
for Updates


<div class="warning-bar2 bg-danger">
	<span data-mce-type="bookmark" style="display: inline-block; width: 0px; overflow: hidden; line-height: 0;" class="mce_SELRES_start"></span>


<div class="warning-text">


<ul class="list-inline">
 	

<li>The N20 hotspot data for 7 April is unavailable due to urgent systems maintenance. We apologise for any inconvenience caused.</li>


</ul>


</div>


</div>



for Level 0 or Announcement


<div class="warning-bar2 bg-success2">


<div class="warning-text">


<ul class="list-inline">
 	

<li><strong> Alert Level 0 </strong> | <a href="https://asmc.asean.org/asmc-alerts/">End of Dry Season for the Northern ASEAN Region</a></li>


 	

<li>The downgrade of Alert Level 1 to Alert Level 0 indicates the end of dry season for the northern ASEAN region. The regional haze situation will be updated daily at 0900 UTC.</li>


</ul>


</div>


</div>



for Level 1


<div class="warning-bar2 bg-success2">


<div class="warning-text">


<ul class="list-inline">
 	

<li><strong> Alert Level 1 </strong> | <a href="https://asmc.asean.org/asmc-alerts/">Start of Dry Season for the Northern ASEAN Region</a></li>


 	

<li>The upgrade of Alert Level 0 to Alert Level 1 indicates the start of dry season for the northern ASEAN region. The regional haze situation will be updated daily at 0900 UTC.</li>


</ul>


</div>


</div>



for Level 2


<div class="warning-bar2 bg-warning">


<div class="warning-text">


<ul class="list-inline">
 	

<li><strong> Alert Level 2 </strong> | <a href="https://asmc.asean.org/asmc-alerts/">Activation of Alert Level 2 for the Mekong Sub-region</a></li>


 	

<li> With the activation of Alert Level 2 for the Mekong sub-region, the regional haze situation is updated at 0300 UTC and 0900 UTC.</li>


</ul>


</div>


</div>



for Level 3


<div class="warning-bar2 bg-danger">


<div class="warning-text">


<ul class="list-inline">
 	

<li><strong> Alert Level 3 </strong> | <a href="https://asmc.asean.org/asmc-alerts/">Activation of Alert Level 3 for the Mekong Sub-region</a></li>


 	

<li> With the activation of Alert Level 3 for the Mekong sub-region, the regional haze situation is updated at 0300 UTC and 0900 UTC.</li>


</ul>


</div>


</div>



END TEMPLATE --

-- ALERT LEVEL BANNER --


<div class="warning-bar2 bg-warning">

	&nbsp;


<div class="warning-text">


<ul class="list-inline">
 	

<li><strong> Alert Level 2 </strong> | <a href="https://asmc.asean.org/asmc-alerts/">Activation of Alert Level 2 for Kalimantan</a></li>


</ul>


<span data-mce-type="bookmark" style="display: inline-block; width: 0px; overflow: hidden; line-height: 0;" class="mce_SELRES_start"></span></div>


</div>


-- ALERT LEVEL BANNER --

-- BANNER --


<div id="accordion_atmosphere" class="panel-group">


<div class="warning-bar2 bg-danger">


<div id="dailybanner" class="panel-heading collapsed" style="margin-bottom: 5px;" data-toggle="collapse" data-="" data-target="#collapseOne">


<div class="pull-left"><strong>The website will be undergoing scheduled maintenance on 7 Nov 2023, 10:00PM to 8 Nov 2023, 02:00AM to serve you better. The website may not be accessible during the scheduled maintenance period. We apologise for any inconvenience caused.</strong></div>




<div align="right">
			 <a href="#pull-right" data-toggle="modal" data-target="#modal_situpdate" aria-expanded="true">+ Show more</a></div>


</div>


</div>


</div>


-- BANNER --

-- MODAL --


<div id="modal_situpdate" class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">


<div class="modal-dialog modal-lg">

	-- MODAL


<div class="modal-content">


<div class="modal-header">

	<button class="close" type="button" data-dismiss="modal">×</button>


<h4 class="modal-title">Situation Update (4 Oct 2019 1005 UTC) – Rainy weather prevailed over the equatorial ASEAN region</h4>


</div>




<div class="modal-body">

	Showers fell over the southern ASEAN region except for southern Sumatra where dry conditions prevailed. In Sumatra, localised smoke plumes were observed in the vicinity of hotspots in South Sumatra. Elsewhere in the region, there was no smoke haze observed due to rainy and cloudy conditions. With scattered showers forecast over the equatorial region, the hotspot and smoke haze situation in the region is expected to be generally subdued except for some hotspot activities in southern Sumatra.


<table style="width: 100%;">


<tbody>


<tr>


<td style="padding: 10px;"><a href="https://asmc.asean.org/wp-content/uploads/2019/10/20191005Banner.gif"><img decoding="async" class="alignnone size-medium wp-image-5415" src="https://asmc.asean.org/wp-content/uploads/2019/10/20191004Banner.gif" alt="" width="100%" /></a></td>


</tr>


</tbody>


</table>


</div>




<div class="modal-footer"><button class="btn btn-default" type="button" data-dismiss="modal">Close</button></div>


</div>


</div>


</div>


<span data-mce-type="bookmark" style="display: inline-block; width: 0px; overflow: hidden; line-height: 0;" class="mce_SELRES_start"></span>
MODAL --

</div>


</div>


-- MODAL --></p>
  </div>
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
  <div class="page-header">
    <div class="container">

      <h1>Regional Haze Situation</h1>

    </div>
  </div>

  <div class="tab-container">

    <div class="tab-menu">
      <div class="container">
      </div>
    </div>

    <div class="container">

      <div class="tab-content">

        <div id="regional_haze_map" class="tab-pane active" role="tabpanel">

          <div class="row tab-sub-menu">
            <div class="col-12 text-end">
              <a class="print resizable" href="#" onclick="window.print();">Print this map</a>
            </div>
          </div>

          <div class="tab-pane-body">
            <div class="tab-pane-body-content">

              <div class="row">

                <div class="col-12">
                  <div class="full-map-with-overlay" style="height:486px">
                    <div style="width : 100%; height : 486px;">

                      <div id="map_canvas" style="width:100%; height:100%;"></div>

                      <div id="map_filter_collapse" class="map-filter-collapse " style="top:180px;width:260px;">

                        <div id="map_filter_slide_button" class="map-filter-slide-button" style="top:40px;">
                          <span class="visually-hidden">Map Filter Collapse</span>
                        </div>

                        <div class="map-filter-collapse-inner" style="top:-182px; height:488px; width:259px;background:rgba(255,255,255,0.8);">

                                                    <div class="map-content-group">
                                                        <h5>Select Date</h5>
                                                        <div class="input-group datepicker-input-group">
                                                            <input id="myButton" type="text" class="form-control datepicker"  aria-describedby="calendar-icon" value=""/>
                                                            <span class="input-group-addon" id="calendar-icon"><img alt="icon-calendar" src="https://asmc.asean.org/wp-content/themes/asmctheme/assets/img/icons/icon-calendar.png" width="13" height="14"></span>
                                                        </div>
                                                    </div>

                          <div class="map-content-group">
                            <h5>Overlays</h5>
                            <ul class="list-unstyled">

                              <li>
                                <label class="checkbox">
                                  <input type="checkbox" onclick="displaySatelliteImage();" id="myinput1" name="myinput1"><span></span> <span>Satellite Image</span>
                                </label>
                              </li>

                                <li>
                                    <label class="checkbox" style="display: inline">
                                        <input id="rw" type="checkbox" onchange=" removeWind();"><span></span>
                                    </label>
                                    <span href="#home_wind" class="collapsed resizable" data-bs-toggle="collapse" style="cursor: pointer;margin-left: 2px;">
                                        2500 ft Winds<i class="fa fa-chevron-down" aria-hidden="true" style="float: right"></i>
                                    </span>
                                    <ul id="home_wind" class="collapse list-unstyled" style="margin-top:11px; ">
                                      <li>
                                        <label class="radio">
                                          <input type="radio"  onclick="showWindKmlFile('analysis');" id="myinput" name="myinput"><span></span> <span>Analysis</span>
                                        </label>
                                      </li>
                                      <li>
                                        <label class="radio">
                                          <input type="radio"  onclick="showWindKmlFile('24hr');" id="wind24" name="myinput"><span></span> <span>+24-hr Forecast</span>
                                        </label>
                                      </li>
                                      <li>
                                        <label class="radio">
                                          <input type="radio"  onclick="showWindKmlFile('48hr');" id="wind48" name="myinput"><span></span> <span>+48-hr Forecast</span>
                                        </label>
                                      </li>
                                      <li>
                                        <label class="radio">
                                          <input type="radio"  onclick="showWindKmlFile('72hr');" id="wind72" name="myinput"><span></span> <span>+72-hr Forecast</span>
                                        </label>
                                      </li>
                                    </ul>
                                </li>

                                <li>
                                    <label class="checkbox" style="display: inline">
                                        <input id="rr" type="checkbox" checked onchange="removeRain()"><span></span>
                                    </label>
                                    <span href="#home_rain" class="collapsed resizable" data-bs-toggle="collapse" style="cursor: pointer;margin-left: 2px;">
                                        Rainfall Accumulation<i class="fa fa-chevron-down" aria-hidden="true" style="float: right"></i>
                                    </span>
                                    <ul id="home_rain" class="collapse list-unstyled" style="margin-top:11px; ">
                                        <li>
                                            <label class="radio">
                                                <input type="radio" disabled="disabled"  onclick="showRainKmlFile('analysis');" id="rain" name="rain" ><span></span> <span>Past 24-hr Observed Rainfall</span>
                                            </label>
                                        </li>
                                        <li>
                                            <label class="radio">
                                                <input type="radio" disabled="disabled"  onclick="showRainKmlFile('24hr');" id="rain24" name="rain" ><span></span> <span>+24-hr Forecast</span>
                                            </label>
                                        </li>
                                        <li>
                                            <label class="radio">
                                                <input type="radio" disabled="disabled"  onclick="showRainKmlFile('48hr');" id="rain48" name="rain"><span></span> <span>+48-hr Forecast</span>
                                            </label>
                                        </li>
                                        <li>
                                            <label class="radio">
                                                <input type="radio" disabled="disabled"  onclick="showRainKmlFile('72hr');" id="rain72" name="rain"><span></span> <span>+72-hr Forecast</span>
                                            </label>
                                        </li>
                                    </ul>
                                </li>

                            <li>

                                    <li>
                                          <label class="checkbox" style="display: inline;">
                                              <input type="checkbox" checked onclick="removeNoaa20HazeHotspots();" id="noaa20hotspots" name="noaa20hotspots"><span></span>
                                              <span href="#home_daynight" class="collapsed resizable" data-bs-toggle="collapse" style="cursor: pointer;">Hotspots<span class="glyphicon glyphicon-chevron-down" aria-hidden="true" style="float: right; display:none"></span></span>
                                          </label>

                                        <!--
                                        <ul id="home_daynight" class="collapse list-unstyled" style="margin-top: 11px;margin-left: 20px;">
                                          <li>
                                            <label class="checkbox">
                                              <input type="checkbox" checked onclick="removeNoaa20DayHotspots();" id="dayhs" name="dayhs"><span></span> <span>Day Time</span>
                                            </label>
                                          </li>
                                          <li>
                                            <label class="checkbox">
                                              <input type="checkbox"  onclick="removeNoaa20NightHotspots();" id="nighths" name="nighths"><span></span> <span>Night Time</span>
                                            </label>
                                          </li>
                                        </ul>
                                         -->
                                    </li>

<!--                                                            <li>-->
<!--                                                                <label class="checkbox" style="display: inline;">-->
<!--                                                                    <input type="checkbox" onclick="removeNoaa19Hotspots();" id="noaa19hotspots" name="noaa19hotspots"><span></span> <span>NOAA-19</span>-->
<!--                                                                </label>-->
<!--                                                            </li>-->
                                                            </li>
                                                        </ul>
                                                    </div>

                        </div>

                      </div>

                    </div>
                  </div>

                  <div style='margin-top: 5px;'>
                     <span style="margin-right:15px;margin-left:71px;font-size:12px;"><img alt="MSS" style="margin-right:3px;" src="https://asmc.asean.org/wp-content/themes/asmctheme/assets/img/icons/icon-circle-orange.png"/>Moderate Haze</span>
                     <span style="margin-right:15px;margin-left:15px;font-size:12px;"><img alt="MSS" style="margin-right:3px;" src="https://asmc.asean.org/wp-content/themes/asmctheme/assets/img/icons/icon-circle-brown.png"/>Dense Haze</span>
<!--                     <span style="margin-right:15px;margin-left:15px;font-size:12px;"><img alt="MSS" style="margin-right:3px;" src="--><!--/assets/img/icons/icon-full-circle-red.png"/>Hotspot</span>-->
                     <span style="margin-right:15px;margin-left:15px;font-size:12px;"><img alt="MSS" style="margin-right:0px;" src="https://asmc.asean.org/wp-content/themes/asmctheme/assets/img/icons/icon-arrow-sign-right.png"/> 2500 ft Wind</span>

                     <span style="margin-right:15px;margin-left:15px;font-size:12px;"><img alt="MSS" style="margin-right:3px;" src="https://asmc.asean.org/wp-content/themes/asmctheme/assets/img/hotspots/yellow-circle.png"/>Low Confidence Hotspot</span>
                     <span style="margin-right:15px;margin-left:15px;font-size:12px;"><img alt="MSS" style="margin-right:3px;" src="https://asmc.asean.org/wp-content/themes/asmctheme/assets/img/hotspots/orange-circle.png"/>Medium Confidence Hotspot</span>
                     <span style="margin-right:15px;margin-left:15px;font-size:12px;"><img alt="MSS" style="margin-right:3px;" src="https://asmc.asean.org/wp-content/themes/asmctheme/assets/img/hotspots/red-circle.png"/>High Confidence Hotspot</span>
                     <p></p>
                     <span style="margin-right:15px;margin-left: 240px;font-size:12px;margin-top: 5px;"><img alt="MSS" style="height:21px;" src="https://asmc.asean.org/wp-content/themes/asmctheme/assets/img/wind_legend.png" /> Wind Speed (km/h)</span>
                     <span style="margin-right:15px;font-size:12px;padding-top: 5px;"><img alt="MSS" style="height:23px;" src="https://asmc.asean.org/wp-content/themes/asmctheme/assets/img/rain_legend.png" /> Rainfall (mm)</span>
                 </div>


                  <div style='width:1050px;margin-top:5px;' class="map-content-group" id="hazeupdate">
                    <div class="bg-gray warning">
                      <p class="text-gray">Latest Weather and Haze Situation</p>
                      <p id="myContent">
                        Dry conditions were observed over the southern ASEAN region today, except for showers over the northern parts of Sumatra, Borneo, and parts of Peninsular Malaysia. Scattered hotspots were detected in the southern parts of Kalimantan and Sumatra. Moderate to dense transboundary smoke haze was observed over parts of Kalimantan, Singapore, the southern parts of Peninsular Malaysia, the southern and central parts of Sumatra and the western parts of Sarawak. Moderate to dense smoke haze was also observed over Papua. Some air quality stations in southern parts of Peninsular Malaysia and Singapore recorded Unhealthy levels, while air quality stations in Borneo and Sumatra reported Unhealthy to Hazardous levels. The full extent of the hotspot and smoke haze situation over the southern ASEAN region could not be determined due to extensive cloud cover. It was relatively dry over the northern ASEAN region today, except for some showers over the Philippines as well as the northern and southern parts of the sub-region. Hotspot activity over the northern ASEAN region remained low.                         <p style='font-weight:bold;margin-top: 10px;margin-bottom: 5px;'>Weather and Haze Outlook</p>
                        <p id = "WHoutlook">In the coming days, dry weather is likely to persist over parts of the southern ASEAN region, except over Peninsular Malaysia, as well as parts of Java, Sumatra and Borneo where showers are forecast. While showers may bring some improvement, the hotspot and smoke haze situation is expected to remain elevated especially over areas experiencing prolonged dry conditions, with a continued risk of severe transboundary haze occurrence. The prevailing winds over the southern ASEAN region are likely to blow generally from the southeast to the southwest, except over Peninsular Malaysia and the northern parts of Sumatra where the winds are expected to blow from the west to northwest. Wet weather is forecast to continue over the northern ASEAN region, apart from the northern, central and eastern parts of the Mekong sub-region where it is expected to be relatively drier. Hotspot activity is likely to remain low. The prevailing winds over the northern ASEAN region are likely to be light and variable in direction. </p>
                      </p>
                    </div>
                  </div>

                </div>

              </div>

            </div>
          </div>

          
            

			<div class="tab-pane-extra">
<div class="row">
<div class="col-11">
<ul>
<li style="font-size: 12px;">All maps are to be used solely for displaying meteorological/geophysical information, and not for any other purpose. All maps are not to scale and for illustrative purpose only.</li>
<li style="font-size: 12px;">The hotspots depicted on the map are derived from the NOAA satellite and they represent locations with possible fires. Hotspots may go undetected due to cloudy conditions or incomplete satellite pass.</li>
<li style="font-size: 12px;">At Alert Level 0 and Alert Level 1, the regional haze situation is updated once a day at 0900 UTC. The regional haze situation is updated more frequently at 0300 UTC and 0900 UTC upon activation of Alert Level 2 or Alert Level 3. Updates at 0300 UTC display hotspot information from night-time passes of the NOAA-20 satellite. Fewer hotspots were typically detected at night as fire activities usually peak during the day.</li>
<li style="font-size: 12px;">Reprocessed satellite data will be availed at a later timing. The hotspot information derived from satellite data reprocessed may differ slightly from that received near real-time but reprocessing is necessary for better quality data.</li>
<li style="font-size: 12px;">The 2500 ft winds (depicted by arrows) are model analysis winds.</li>
</ul>
</div>
</div>
</div>
<div class="related-section">
<div class="container">
<div class="row">
<div class="col-8">
<div class="related-section-block">
<h3>Seasonal Forecast for October &#8211; December 2026</h3>
<div class="calendar-list-group list-group">
<p><!---item entry SEASONAL FORECAST starts here--></p>
<div class="list-group-item">
<div class="calendar-list-body">
<h4>Summary of Outlook</h4>
<p>In September 2026, Southwest Monsoon conditions prevailed over the ASEAN region, with prevailing winds blowing mostly from the southeast or southwest. During this period, the southern ASEAN region continues to experience its dry season, while the northern ASEAN region experiences its wet season. Towards the end of October, the Southwest Monsoon is expected to gradually transition into inter-monsoon conditions, characterised by light and variable winds. Rainfall is anticipated to return over the southern ASEAN region as the monsoon rainband shifts southwards towards the Equator.</p>
<div style="height: 20px;"></div>
<p>For October 2026, below-normal rainfall is predicted for much of the Maritime Continent, with the highest probability over the southern half of the region. During October – December (OND), models predict a high chance of below-normal rainfall over parts of eastern Mainland Southeast Asia and much of the Maritime Continent, apart from the northwestern portion and parts of western Borneo. El Niño conditions are present and predicted to strengthen in October-November 2026. El Niño conditions tend to lead to an increased chance of below-normal rainfall for much of the Maritime Continent region and parts of eastern Mainland Southeast Asia at this time of the year. During October and OND 2026, above-normal temperature is predicted over most of the ASEAN region.</p>
<div style="height: 20px;"></div>
<p>Under El Niño conditions and below-normal rainfall expected across most of the southern ASEAN region, the hotspot and smoke haze situation is expected to remain escalated in the region. The risk of transboundary haze persists under prevailing southeasterly or southwesterly wind conditions. Increased showers under the inter-monsoon conditions towards the end of October could start to alleviate the hotspot and smoke haze situation over the region. Towards the end of the year, the northern ASEAN region is expected to enter its dry season, which could lead to a rise in hotspot and smoke haze activity, particularly over areas experiencing below-normal rainfall conditions.</p>
</div>
</div>
</div>
<div class="calendar-list-group list-group">
<div class="list-group-item">
<div class="calendar-list-body">
<p><a href="https://asmc.asean.org/asmc-seasonal-outlook/">Click here for details</a></p>
</div>
</div>
<div class="related-section-block"></div>
</div>
</div>
</div>
<div class="col-4">
<div class="related-section-block">
<h3>ASEAN Climate Outlook Forum</h3>
<p>The ASEAN Climate Outlook Forum (ASEANCOF) is an avenue to collaboratively develop consensus-based seasonal climate outlooks and related information on a regional scale.</p>
<p><a href="https://asmc.asean.org/events-twenty-sixth-session-of-the-asean-climate-outlook-forum-aseancof-26/">26th ASEAN COF</a></p>
</div>
<div class="related-section-block">
<h3>Related Website</h3>
<p><a class="external" href="https://hazeportal.asean.org/" target="_blank" rel="noopener">ASEAN Haze Online</a></p>
</div>
</div>
</div>
<div class="row">
<div class="col-11">
<div class="related-section-block">
<h3>Recent Updates</h3>
<div class="calendar-list-group list-group">
<p><!---item entry 1 starts here--></p>
<div class="list-group-item">
<div class="calendar-list-date">
<h3>16</h3>
<p>Oct</p>
</div>
<div class="calendar-list-body"><a href="https://asmc.asean.org/asmc-el-nino/">Regional Climate &#8211; El Niño / La Niña</a><br />
The El Niño – Southern Oscillation (ENSO) monitoring system state is “El Niño Conditions”. The Relative Nino3.4 index supports the presence of strong El Niño conditions. Key atmospheric indicators (cloudiness and trade wind anomalies) support&#8230;</div>
<div class="calendar-list-link"><a href="https://asmc.asean.org/asmc-el-nino/"><span class="sr-only">More details</span></a></div>
</div>
<p><!---item entry 1 ends here--></p>
<p><!---item entry 2 starts here--></p>
<div class="list-group-item">
<div class="calendar-list-date">
<h3>7</h3>
<p>Oct</p>
</div>
<div class="calendar-list-body"><a href="https://asmc.asean.org/subseasonal-weather-outlook-12-25-october-2026/">Subseasonal Weather Outlook (12 – 25 October 2026)</a><br />
Drier than usual conditions are predicted over most of the southern ASEAN region in the next fortnight (12 – 25 October). Drier than usual conditions are also predicted for much of&#8230;</div>
<div class="calendar-list-link"><a href="https://asmc.asean.org/subseasonal-weather-outlook-12-25-october-2026/"><span class="sr-only">More details</span></a></div>
</div>
<p><!---item entry 2 ends here--></p>
<p><!---item entry 3 starts here--></p>
<div class="list-group-item">
<div class="calendar-list-date">
<h3>23</h3>
<p>Sep</p>
</div>
<div class="calendar-list-body"><a href="https://asmc.asean.org/subseasonal-weather-outlook-28-september-11-october-2026/">Subseasonal Weather Outlook (28 September – 11 October 2026)</a><br />
Drier than usual conditions are predicted over most of the southern ASEAN region in the next fortnight (28 September – 11 October). Drier than usual conditions are also predicted for&#8230;</div>
<div class="calendar-list-link"><a href="https://asmc.asean.org/subseasonal-weather-outlook-28-september-11-october-2026/"><span class="sr-only">More details</span></a></div>
</div>
<p><!---item entry 3 ends here--></p>
</div>
</div>
</div>
</div>
</div>
</div>
						<!-- .entry-content -->
		<footer class="entry-meta">
					</footer><!-- .entry-meta -->


          
        </div>

<script type="text/javascript">
var map;
var bo=false;
var bo1=true;

var northEast = new google.maps.LatLng(60, 165);
var southWest = new google.maps.LatLng(-60, 45);
var allowedBounds = new google.maps.LatLngBounds(southWest, northEast);
var ctaLayer = new google.maps.KmlLayer({
    url:'https://asmc.asean.org/files/warnadv/haze/wind/Haze_Wind_20261023_000000.kml',
    preserveViewport: true,
    clickable: false,
    suppressInfoWindows:false,
    zIndex: 9999
});
var imageBounds = new google.maps.LatLngBounds(
    new google.maps.LatLng(-18.6, 86),
    new google.maps.LatLng(32.6, 144));
var historicalOverlayDate = "22/10/2026";
var historicalOverlayUrl = "https:\/\/asmc.asean.org\/files\/warnadv\/haze\/mtsat\/MTSAT_IR_Haze_20261022_163000.png";
var historicalOverlay = new google.maps.GroundOverlay(historicalOverlayUrl,imageBounds);

var ctaLayerBounds = new google.maps.KmlLayer({});

function checkBounds() {
  if ((allowedBounds.getNorthEast().lat()<(map.getBounds().getNorthEast().lat()))||(allowedBounds.getSouthWest().lat()>(map.getBounds().getSouthWest().lat()))||(allowedBounds.getNorthEast().lng()<(map.getBounds().getNorthEast().lng()))||(allowedBounds.getSouthWest().lng()>(map.getBounds().getSouthWest().lng()))) {
    map.setCenter(new google.maps.LatLng(5, 115));
  }
}

function initialize() {
  var mapProp = {
    center:new google.maps.LatLng(6, 110),
    zoom:5,
    minZoom:4,
    disableDefaultUI:true,
    panControl: true,
    zoomControl:true,
    streetViewControl:false,
    disableDoubleClickZoom:true,
    disableScrollSheelZoom:true,
    mapTypeId:google.maps.MapTypeId.ROADMAP
  };
  map = new google.maps.Map(document.getElementById("map_canvas"), mapProp);
  google.maps.event.addListener(map, 'center_changed', function() {
    window.setTimeout(function() {
      checkBounds();
    }, 1000);
  });
  
  // Haze Boundary KML - Server-side rendering pattern
  // Get the KML URL server-side and embed it directly in JavaScript
  var ASMC_KML_URL = "https:\/\/asmc.asean.org\/files\/warnadv\/haze\/boundaries\/HazeBoundaries_20261023_172833.kml";
  console.log("ASMC Haze Boundary KML URL:", ASMC_KML_URL);
  
  // Initialize the global KmlLayer with the embedded URL
  ctaLayerBounds = new google.maps.KmlLayer({
      url: ASMC_KML_URL,
      preserveViewport: true,
      clickable: false,
      suppressInfoWindows: false,
      zIndex: 9999
  });
  
  // Attach the layer to the map
  ctaLayerBounds.setMap(map);
  
  // Add status change listener for diagnostic logging
  ctaLayerBounds.addListener("status_changed", function () {
      console.log(
          "Haze Boundary KML Status:",
          ctaLayerBounds.getStatus()
      );
  });
  
  // Hotspots NOAA-19 KML - Server-side rendering pattern
  var ASMC_HOTSPOT_NOAA19_URL = "https:\/\/asmc.asean.org\/files\/warnadv\/haze\/hotspots\/Haze_Hotspots_20261023_164300.kml";
  console.log("ASMC Hotspots NOAA-19 KML URL:", ASMC_HOTSPOT_NOAA19_URL);
  
  // Initialize the NOAA-19 KmlLayer with the embedded URL
  ctaLayerHotNoaa19 = new google.maps.KmlLayer({
      url: ASMC_HOTSPOT_NOAA19_URL,
      preserveViewport: true,
      clickable: false,
      suppressInfoWindows: false
  });
  
  // Add status change listener for diagnostic logging
  ctaLayerHotNoaa19.addListener("status_changed", function () {
      console.log(
          "Hotspots NOAA-19 KML Status:",
          ctaLayerHotNoaa19.getStatus()
      );
  });
  
  // Hotspots NOAA-20 Day KML - Server-side rendering pattern
  var ASMC_HOTSPOT_NOAA20_DAY_URL = "https:\/\/asmc.asean.org\/files\/warnadv\/haze\/hotspotsday\/NOAA20_DayHotspot_20261023_021001.kml";
  console.log("ASMC Hotspots NOAA-20 Day KML URL:", ASMC_HOTSPOT_NOAA20_DAY_URL);
  
  // Initialize the NOAA-20 Day KmlLayer with the embedded URL
  ctaLayerHotNoaa20Day = new google.maps.KmlLayer({
      url: ASMC_HOTSPOT_NOAA20_DAY_URL,
      preserveViewport: true,
      clickable: false,
      suppressInfoWindows: false
  });
  
  // Attach the layer to the map (checkbox is checked by default)
  ctaLayerHotNoaa20Day.setMap(map);
  
  // Add status change listener for diagnostic logging
  ctaLayerHotNoaa20Day.addListener("status_changed", function () {
      console.log(
          "Hotspots NOAA-20 Day KML Status:",
          ctaLayerHotNoaa20Day.getStatus()
      );
  });
  
  // Hotspots NOAA-20 Night KML - Server-side rendering pattern
  var ASMC_HOTSPOT_NOAA20_NIGHT_URL = "https:\/\/asmc.asean.org\/files\/warnadv\/haze\/hotspotsnight\/NOAA20_NightHotspot_20261023_021001.kml";
  console.log("ASMC Hotspots NOAA-20 Night KML URL:", ASMC_HOTSPOT_NOAA20_NIGHT_URL);
  
  // Initialize the NOAA-20 Night KmlLayer with the embedded URL
  ctaLayerHotNoaa20Night = new google.maps.KmlLayer({
      url: ASMC_HOTSPOT_NOAA20_NIGHT_URL,
      preserveViewport: true,
      clickable: false,
      suppressInfoWindows: false
  });
  
  // Add status change listener for diagnostic logging
  ctaLayerHotNoaa20Night.addListener("status_changed", function () {
      console.log(
          "Hotspots NOAA-20 Night KML Status:",
          ctaLayerHotNoaa20Night.getStatus()
      );
  });
  
  return map;
}
google.maps.event.addDomListener(window, 'load', initialize);

function displayWindKml(){
  var date=$("#myButton").val();
  viewWind(date);
}

function viewWind(date){
  var url = "https://asmc.asean.org/wp-content/themes/asmctheme/page-functions/functions-ajax-haze-wind.php";
  var data={date:date};
  var options = {data:data, url:url};

  callAjax(options,showWindURL);
}

function showWindURL(data){
	showMarkers(data);
}

function showMarkers(){
  var myButton=$("#myButton").val();
  var mapcanvas=document.getElementById("map_canvas");
  if(bo){
    ctaLayer = new google.maps.KmlLayer({
      url: url,
      preserveViewport: true,
      clickable: false,
      suppressInfoWindows:false,
      zIndex: 9999
    });
    ctaLayer.setMap(map);
    bo=false;

  }else{
    ctaLayer.setMap(null);
    bo=true;
  }
}
function setCtalayer(myButton,url){
  ctaLayer = new google.maps.KmlLayer({
    url: url,
    preserveViewport: true,
    clickable: false,
    suppressInfoWindows:false
  });
  return ctaLayer;
}

function displaySatelliteImage(){
  var date=$("#myButton").val();
  viewSatelliteImage(date);
}

function viewSatelliteImage(date){
  var url = "https://asmc.asean.org/wp-content/themes/asmctheme/page-functions/functions-ajax-haze-satellite-image.php";
  var data={date:date};
  var options = {data:data, url:url};
  callAjax(options,showSatelliteImageURL);
}

function showSatelliteImageURL(data){
  toggleOverlay(data);
}

function toggleOverlay(url){
  if(bo1){
    historicalOverlay= new google.maps.GroundOverlay(url,imageBounds);
    historicalOverlay.setMap(map);
    bo1=false;
  }else{
    historicalOverlay.setMap(null);
    bo1=true;
  }
}

function viewPast(){
  bo=true;
  bo1=true;
  var elementsToCheck = ['#myinput', '#rain', '#dayhs', '#rw', '#noaa20hotspots'];
  var elementsToUncheck = ['#noaa19hotspots', '#rr', '#myinput1', '#wind24', '#wind48', '#wind72', '#rain24', '#rain48', '#rain72', '#nighths'];

  for(var i=0;i<elementsToCheck.length;i++){
    doAction(elementsToCheck[i], 'check');
  }

  for(var i=0;i<elementsToUncheck.length;i++){
    doAction(elementsToUncheck[i], 'uncheck');
  }

  function doAction(element, action) {
  	var isElementExists = $(element).length > 0;
  	if (!isElementExists) return
  	switch (action) {
  		case 'check':
  			return $(element).attr('checked', 'checked')
  		case 'uncheck':
  			return $(element).removeAttr('checked')
  		default:
  			throw new Error('Unknown Action Parameter');
  	}
  }

  var date=$("#myButton").val();
  var mapProp = {
    center:new google.maps.LatLng(5, 115),
    zoom:5,
    minZoom:4,
    disableDefaultUI:true,
    streetViewControl: false,
    fullscreenControl:true,
      fullscreenControlOptions:{
          position: google.maps.ControlPosition.TOP_LEFT
      },
    zoomControl:true,
      panControl: true,
    disableDoubleClickZoom:true,
    disableScrollSheelZoom:true,
    mapTypeId:google.maps.MapTypeId.ROADMAP
  };
  map=new google.maps.Map(document.getElementById("map_canvas")
      ,mapProp);
  google.maps.event.addListener(map, 'center_changed', function() {
    window.setTimeout(function() {
      checkBounds();
    }, 1000);
  });
  viewHazeBounds(date);
  if($('#noaa19hotspots').prop("checked")){
     viewHazeHotspots(date);
  }

  viewHazeContent(date);
  viewHazeOutlook(date);
  if($('#noaa20hotspots').prop("checked")){
    viewDayHazeHotspots(date);
  }
  //viewWind(date);
  // viewRain(date);

}
function viewHazeBounds(date){
  var url = "https://asmc.asean.org/wp-content/themes/asmctheme/page-functions/functions-ajax-haze-bounds.php";
  var data={date:date};
  var options = {data:data, url:url};
  callAjax(options,showHazeBoundsURL);
}
function showHazeBoundsURL(data){
  pastHazeBoundsURL(data);
}
function pastHazeBoundsURL(url){
    ctaLayerBounds.setMap(null);
    
    ctaLayerBounds = new google.maps.KmlLayer({
        url: url,
        preserveViewport: true,
        clickable: false,
        suppressInfoWindows: false,
        zIndex: 9999
    });
    
    ctaLayerBounds.setMap(map);
}

var ctaLayerHotNoaa19; // Initialized in initialize() function with server-side URL
var ctaLayerHotNoaa20Day; // Initialized in initialize() function with server-side URL
var ctaLayerHotNoaa20Night; // Initialized in initialize() function with server-side URL

function displayHazeHotspots(){
    ctaLayerHotNoaa19.setMap(null);
    var date=$("#myButton").val();
    viewHazeHotspots(date);
}

function viewHazeHotspots(date){
    //alert("in noaa-19");
    if(document.getElementById("noaa19hotspots").checked){
        //alert("unchecked");
        var url = "https://asmc.asean.org/wp-content/themes/asmctheme/page-functions/functions-ajax-haze-hotspots.php";
        var data={date:date};
        var options = {data:data, url:url};
        callAjax(options,showHazeHotspotsURL);
    }else{
        ctaLayerHotNoaa19.setMap(null);
    }
}

function showHazeHotspotsURL(data){
  pastHazeHotspotsURL(data);

}

function pastHazeHotspotsURL(url){
    // Trim whitespace from URL (important for AJAX responses)
    url = url.trim();
    
    // Remove old layer before creating new one
    ctaLayerHotNoaa19.setMap(null);
    
    ctaLayerHotNoaa19 = new google.maps.KmlLayer({
        url: url,
        preserveViewport: true,
        clickable: false,
        suppressInfoWindows:false
    });
    
    // Add status monitoring for historical date KML loads
    ctaLayerHotNoaa19.addListener("status_changed", function () {
        console.log(
            "Hotspots NOAA-19 KML Status (Historical):",
            ctaLayerHotNoaa19.getStatus()
        );
    });
    
    ctaLayerHotNoaa19.setMap(map);
}

function displayNightHazeHotspots(){
    ctaLayerHotNoaa20Night.setMap(null);
    var date=$("#myButton").val();
    viewNightHazeHotspots(date);
}

function viewNightHazeHotspots(date){
    var url = "https://asmc.asean.org/wp-content/themes/asmctheme/page-functions/functions-ajax-haze-hotspots-night.php";
    var data={date:date};
    var options = {data:data, url:url};
    callAjax(options,showNightHazeHotspotsURL);
}

function showNightHazeHotspotsURL(data){
    pastNightHazeHotspotsURL(data);
}

function pastNightHazeHotspotsURL(url){
    // Trim whitespace from URL (important for AJAX responses)
    url = url.trim();
    
    // Remove old layer before creating new one
    ctaLayerHotNoaa20Night.setMap(null);
    
    ctaLayerHotNoaa20Night = new google.maps.KmlLayer({
        url: url,
        preserveViewport: true,
        clickable: false,
        suppressInfoWindows:false
    });
    
    // Add status monitoring for historical date KML loads
    ctaLayerHotNoaa20Night.addListener("status_changed", function () {
        console.log(
            "Hotspots NOAA-20 Night KML Status (Historical):",
            ctaLayerHotNoaa20Night.getStatus()
        );
    });
    
    ctaLayerHotNoaa20Night.setMap(map);
}
function displayDayHazeHotspots(){
    ctaLayerHotNoaa20Day.setMap(null);
    var date=$("#myButton").val();
    viewDayHazeHotspots(date);
}

function viewDayHazeHotspots(date){
    var url = "https://asmc.asean.org/wp-content/themes/asmctheme/page-functions/functions-ajax-haze-hotspots-day.php";
    var data={date:date};
    var options = {data:data, url:url};
    callAjax(options,showDayHazeHotspotsURL);
}

function showDayHazeHotspotsURL(data){
    pastDayHazeHotspotsURL(data);
}

function pastDayHazeHotspotsURL(url){
    // Trim whitespace from URL (important for AJAX responses)
    url = url.trim();
    
    // Remove old layer before creating new one
    ctaLayerHotNoaa20Day.setMap(null);
    
    ctaLayerHotNoaa20Day = new google.maps.KmlLayer({
        url: url,
        preserveViewport: true,
        clickable: false,
        suppressInfoWindows:false
    });
    
    // Add status monitoring for historical date KML loads
    ctaLayerHotNoaa20Day.addListener("status_changed", function () {
        console.log(
            "Hotspots NOAA-20 Day KML Status (Historical):",
            ctaLayerHotNoaa20Day.getStatus()
        );
    });
    
    ctaLayerHotNoaa20Day.setMap(map);
}

function viewHazeContent(date){
  var url = "https://asmc.asean.org/wp-content/themes/asmctheme/page-functions/functions-ajax-haze-content.php";
  var data={date:date};
  var options = {data:data, url:url};
  callAjax(options,showHazeContent);
}

function showHazeContent(data){
  $("#myContent").html(data);
}

function viewHazeOutlook(date){
    var url = "https://asmc.asean.org/wp-content/themes/asmctheme/page-functions/functions-ajax-haze-outlook.php";
    var data={date:date};
    var options = {data:data, url:url};
    callAjax(options,showHazeOutlook);
}
function showHazeOutlook(data){
    $("#WHoutlook").html(data);
}

$('#myButton').datepicker({
  format: "d M, yyyy",
  startDate: "-89d",
  endDate:"-0d",
  multidate: false,
  autoclose: true
});
var ctaLayerWind = new google.maps.KmlLayer({});
var ctaLayerWind24 = new google.maps.KmlLayer({});
var ctaLayerWind48 = new google.maps.KmlLayer({});
var ctaLayerWind72 = new google.maps.KmlLayer({});

function showWindKmlFile(type){
    var date=$("#myButton").val();
    var url="https://asmc.asean.org/wp-content/themes/asmctheme/page-functions/functions-ajax-asmc-gis-wind.php";
    var data={date:date,type:type};
    var options={data:data,url:url};

    if(type=="analysis"){
        ctaLayerWind.setMap(null);
        if(document.getElementById("myinput").checked){
            callAjax(options,showWindKmlUrl);
        }
    }
    if(type=="24hr"){
        ctaLayerWind24.setMap(null);
        if(document.getElementById("wind24").checked){
            callAjax(options,showWindKmlUrl);
        }
    }
    if(type=="48hr"){
        ctaLayerWind48.setMap(null);
        if(document.getElementById("wind48").checked){
            callAjax(options,showWindKmlUrl);
        }
    }
    if(type=="72hr"){
        ctaLayerWind72.setMap(null);
        if(document.getElementById("wind72").checked){
            callAjax(options,showWindKmlUrl);
        }
    }
}

function showWindKmlUrl(jsonData){
    var data = JSON.parse(jsonData);
    var type=data["type"];
    var url=data["url"];//.replace("\\","/");

    if(type=="analysis"){
        ctaLayerWind24.setMap(null);
        ctaLayerWind48.setMap(null);
        ctaLayerWind72.setMap(null);
        ctaLayerWind = new google.maps.KmlLayer({
            url: url,
            preserveViewport: true,
            clickable: false,
            suppressInfoWindows:false
        });
        ctaLayerWind.setMap(map);
    }
    if(type=="24hr"){
        ctaLayerWind.setMap(null);
        ctaLayerWind48.setMap(null);
        ctaLayerWind72.setMap(null);
        ctaLayerWind24 = new google.maps.KmlLayer({
            url: url,
            preserveViewport: true,
            clickable: false,
            suppressInfoWindows: false
        });
        ctaLayerWind24.setMap(map);
    }
    if(type=="48hr"){
        ctaLayerWind24.setMap(null);
        ctaLayerWind.setMap(null);
        ctaLayerWind72.setMap(null);
        ctaLayerWind48 = new google.maps.KmlLayer({
            url: url,
            preserveViewport: true,
            clickable: false,
            suppressInfoWindows:false
        });
        ctaLayerWind48.setMap(map);
    }
    if(type=="72hr"){
        ctaLayerWind24.setMap(null);
        ctaLayerWind48.setMap(null);
        ctaLayerWind.setMap(null);
        ctaLayerWind72 = new google.maps.KmlLayer({
            url: url,
            preserveViewport: true,
            clickable: false,
            suppressInfoWindows:false
        });
        ctaLayerWind72.setMap(map);
    }

}
var ctaLayerRain = new google.maps.KmlLayer({});
var ctaLayerRain24 = new google.maps.KmlLayer({});
var ctaLayerRain48 = new google.maps.KmlLayer({});
var ctaLayerRain72 = new google.maps.KmlLayer({});

function showRainKmlFile(type){
    var date=$("#myButton").val();
    var url="https://asmc.asean.org/wp-content/themes/asmctheme/page-functions/functions-ajax-haze-rain.php";
    var data={date:date,type:type};
    var options={data:data,url:url};
    if(type=="analysis"){
        ctaLayerRain.setMap(null);
        if(document.getElementById("rain").checked){
            callAjax(options,showRainKmlUrl);
        }
    }
    if(type=="24hr"){
        ctaLayerRain24.setMap(null);
        if(document.getElementById("rain24").checked){
            callAjax(options,showRainKmlUrl);
        }
    }
    if(type=="48hr"){
        ctaLayerRain48.setMap(null);
        if(document.getElementById("rain48").checked){
            callAjax(options,showRainKmlUrl);
        }
    }
    if(type=="72hr"){
        ctaLayerRain72.setMap(null);
        if(document.getElementById("rain72").checked){
            callAjax(options,showRainKmlUrl);
        }
    }
}

function showRainKmlUrl(jsonData){
    var data = JSON.parse(jsonData);
    var type=data["type"];
    var url=data["url"];//.replace("\\","/");

    if(type=="analysis"){
        ctaLayerRain24.setMap(null);
        ctaLayerRain48.setMap(null);
        ctaLayerRain72.setMap(null);
        ctaLayerRain = new google.maps.KmlLayer({
            url: url,
            preserveViewport: true,
            clickable: false,
            suppressInfoWindows:false
        });
        ctaLayerRain.setMap(map);
    }
    if(type=="24hr"){
        ctaLayerRain.setMap(null);
        ctaLayerRain48.setMap(null);
        ctaLayerRain72.setMap(null);
        ctaLayerRain24 = new google.maps.KmlLayer({
            url: url,
            preserveViewport: true,
            clickable: false,
            suppressInfoWindows:false
        });
        ctaLayerRain24.setMap(map);
    }
    if(type=="48hr"){
        ctaLayerRain.setMap(null);
        ctaLayerRain24.setMap(null);
        ctaLayerRain72.setMap(null);
        ctaLayerRain48 = new google.maps.KmlLayer({
            url: url,
            preserveViewport: true,
            clickable: false,
            suppressInfoWindows:false
        });
        ctaLayerRain48.setMap(map);
    }
    if(type=="72hr"){
        ctaLayerRain.setMap(null);
        ctaLayerRain24.setMap(null);
        ctaLayerRain48.setMap(null);
        ctaLayerRain72 = new google.maps.KmlLayer({
            url: url,
            preserveViewport: true,
            clickable: false,
            suppressInfoWindows:false
        });
        ctaLayerRain72.setMap(map);
    }
}
function removeWind(){

    if($('#rw').prop("checked")){
        if($('#myinput').prop("checked")){
            showWindKmlFile('analysis');
        } else if ($('#wind24').prop("checked")){
            showWindKmlFile('24hr');
        } else if ($('#wind48').prop("checked")){
            showWindKmlFile('48hr');
        } else if ($('#wind72').prop("checked")){
            showWindKmlFile('72hr');
        }
        $("#myinput").removeAttr("disabled");
        $("#wind24").removeAttr("disabled");
        $("#wind48").removeAttr("disabled");
        $("#wind72").removeAttr("disabled");
    }else{
        $("#myinput").attr("disabled","disabled");
        $("#wind24").attr("disabled","disabled");
        $("#wind48").attr("disabled","disabled");
        $("#wind72").attr("disabled","disabled");
        ctaLayerWind.setMap(null);
        ctaLayerWind24.setMap(null);
        ctaLayerWind48.setMap(null);
        ctaLayerWind72.setMap(null);
    }
}
function removeRain(){

    if($('#rr').prop("checked")){
        if($('#rain').prop("checked")){
            showRainKmlFile('analysis');
        } else if ($('#rain24').prop("checked")){
            showRainKmlFile('24hr');
        } else if ($('#rain48').prop("checked")){
            showRainKmlFile('48hr');
        } else if ($('#rain72').prop("checked")){
            showRainKmlFile('72hr');
        }
        $("#rain").removeAttr("disabled");
        $("#rain24").removeAttr("disabled");
        $("#rain48").removeAttr("disabled");
        $("#rain72").removeAttr("disabled");
    }else{
        $("#rain").attr("disabled","disabled");
        $("#rain24").attr("disabled","disabled");
        $("#rain48").attr("disabled","disabled");
        $("#rain72").attr("disabled","disabled");
        ctaLayerRain.setMap(null);
        ctaLayerRain24.setMap(null);
        ctaLayerRain48.setMap(null);
        ctaLayerRain72.setMap(null);
    }
}

function removeNoaa19Hotspots(){
    if($('#noaa19hotspots').prop("checked")){
        displayHazeHotspots();
    }else{
        ctaLayerHotNoaa19.setMap(null);
    }
}
function removeNoaa20HazeHotspots(){
    if($('#noaa20hotspots').prop("checked")){
        if($('#dayhs').prop("checked")){
            displayDayHazeHotspots();
        } else if ($('#nighths').prop("checked")){
            displayNightHazeHotspots();
        }else{
            if(document.getElementById('dayhs')){
                document.getElementById('dayhs').checked="checked";
            }
            displayDayHazeHotspots();
        }
        $("#dayhs").removeAttr("disabled");
        $("#nighths").removeAttr("disabled");
    }else{
        //alert(        // $("#dayhs").attr("disabled","disabled");
        // $("#nighths").attr("disabled","disabled");
        $("#dayhs").removeAttr("checked");
        $("#nighths").removeAttr("checked");
        ctaLayerHotNoaa20Night.setMap(null);
        ctaLayerHotNoaa20Day.setMap(null);
    }
}

function removeNoaa20DayHotspots(){
    if($('#dayhs').prop("checked")){
        if(!$('#noaa20hotspots').prop("checked")){
            document.getElementById('noaa20hotspots').checked="checked";
        }
        displayDayHazeHotspots();
    }else{
        if(!$('#nighths').prop("checked")){
            $("#noaa20hotspots").removeAttr("checked");
        }
        ctaLayerHotNoaa20Day.setMap(null);
    }
}
function removeNoaa20NightHotspots(){
    if($('#nighths').prop("checked")){
        if(!$('#noaa20hotspots').prop("checked")){
            document.getElementById('noaa20hotspots').checked="checked";
        }
        displayNightHazeHotspots();
    }else{
        if(!$('#dayhs').prop("checked")){
            $("#noaa20hotspots").removeAttr("checked");
        }
        ctaLayerHotNoaa20Night.setMap(null);
    }
}

$(document).ready(function() {
  console.log('version-826')
  var startupDatePayload = {"rawIssueDate":"2026-10-23 17:28:33","renderedRawDate":"23 Oct, 2026","effectiveDate":"23 Oct, 2026","usedFallback":true,"firstAllowedDate":"25 Jul, 2026","todayDate":"23 Oct, 2026"};
  var hasInitializedHomeDatepicker = false;

  $('#myButton').datepicker().on('changeDate', function(e){
	if(!hasInitializedHomeDatepicker){
	  hasInitializedHomeDatepicker = true;
	  return;
	}
	var selectedDate = $('#myButton').datepicker('getDate');
	var todayDate = new Date();
	var firstDate=new Date(todayDate.getTime()-90*1000*60*60*24);

	viewPast();
    if($('#rw').prop("checked")){
	  showWindKmlFile('analysis');
    }
    if($('#rr').prop("checked")){
	  showRainKmlFile('analysis');
    }

	var isOutOfRange = selectedDate > todayDate || selectedDate < firstDate;
	if(isOutOfRange) {
	  $('#myButton').datepicker('setDate', '23 Oct, 2026');
	  alert('Please selected dates range within the 90 days period');
	}
  });

  $('#map_filter_slide_button').click(function(){
    if ($('#map_filter_collapse').hasClass('collapsed')) {
      $('#map_filter_collapse').attr('style', 'top:180px;width:0px');
    } else {
      $('#map_filter_collapse').attr('style', 'top:180px;width:260px');
    }
    $(".map-filter-collapse-inner").toggle();
  });
    $('#myButton').datepicker('setDate', startupDatePayload.effectiveDate);
    
    // Load haze content via AJAX on initial page load to show timestamp
    viewHazeContent(startupDatePayload.effectiveDate);
    viewHazeOutlook(startupDatePayload.effectiveDate);

});

</script>
<!--
	</div><!-- #main .wrapper 
	<footer id="colophon" role="contentinfo">
		<div class="site-info">
						<a href="http://wordpress.org/" title="Semantic Personal Publishing Platform">Proudly powered by WordPress</a>
		</div><!-- .site-info 
	</footer><!-- #colophon 
</div><!-- #page -->

<!-- Footer -->
<footer>
  <div class="container">
    <div class="footer-top">
      <div class="row">

        <div style="width:27%;float:left;padding-left:10px;">
          <h5 class="donotresize">Transboundary Haze</h5>
          <div class="row">
            <div class="col-12">
              <ul class="list-unstyled donotresize">
                <li class="donotresize">
                  <ul class="list-unstyled">
                    <li><a class="donotresize" href="https://asmc.asean.org/asmc-alerts/">Warnings and Alerts</a></li>
                    <li><a class="donotresize" href='#' id='hazeTagReviewLink'>Haze Review</a></li>
                    <li><a class="donotresize" href="https://asmc.asean.org/satellite-polar/">Satellite Images</a></li>
                    <li><a class="donotresize" href="https://asmc.asean.org/asmc-hotspot/">Hotspot Information</a></li>
                    <li><a class="donotresize" href="https://asmc.asean.org/asmc-gis-portal/">Haze Information Portal</a></li>
                    <!-- <li><a class="donotresize" href="https://asmc.asean.org/asmc-haze-air-quality/">Air Quality Information</a></li> -->
                    <li><a class="donotresize" href="https://asmc.asean.org/asmc-fire/">Fire Danger Rating System</a></li>
                  </ul>
                </li>
              </ul>
            </div>
          </div>
        </div>

        <div style="width:15%;float:left;padding-left:10px;">
          <h5 class="donotresize">Weather</h5>
          <div class="row">
            <div class="col-12">
              <ul class="list-unstyled donotresize">
                <li class="donotresize">
                  <ul class="list-unstyled">
                    <li><a class="donotresize" href="https://asmc.asean.org/asmc-regional-weather-observation/">Regional Weather</a></li>
                    <li><a class="donotresize" href='#' id='footWeatherOutlookLink'>Subseasonal Weather Outlook and Review</a></li>
                  </ul>
                </li>
              </ul>
            </div>
          </div>
        </div>

        <div style="width:15%;float:left;padding-left:10px;">
          <h5 class="donotresize">Climate</h5>
          <div class="row">
            <div class="col-12">
              <ul class="list-unstyled donotresize">
                <li class="donotresize">
                  <ul class="list-unstyled">
                    <li><a class="donotresize" href="https://asmc.asean.org/asmc-seasonal-outlook/">Seasonal Forecast (1-month and 3-month outlook)</a></li>
                    <li><a class="donotresize" href="https://asmc.asean.org/asmc-el-nino/">El Niño / La Niña</a></li>
                  </ul>
                </li>
              </ul>
            </div>
          </div>
        </div>

        <div style="width:25%;float:left;padding-left:10px;">
          <h5 class="donotresize">Events & Publications</h5>
          <div class="row">
            <div class="col-12">
              <ul class="list-unstyled donotresize">
                <li class="donotresize">
                  <ul class="list-unstyled">
                    <li><a class="donotresize" href='#' id="footEventsLink">Events</a></li>
                    <li><a class="donotresize" href='#' id="footPublicationsLink">Publication</a></li>
                  </ul>
                </li>
              </ul>
            </div>
          </div>
        </div>

        <div style="width:18%;float:left;padding-left:10px;">
          <ul class="list-unstyled title-list donotresize">
            <li><a class="donotresize" href="https://wis2.asmc.asean.org">Data Catalog</a></li>
            <li><a class="donotresize" href="https://asmc.asean.org/asmc-about/">About</a></li>
            <!-- <li><a href="https://asmc.asean.org/asmc-faq/">FAQs</a></li> -->
            <li><a class="donotresize" href="https://asmc.asean.org/asmc-contact-us/">Contact Us</a></li>
            <li>Follow us on <a class="donotresize" href="https://asmc.asean.org/feed/"><img width="22" height="21" alt="RSS" src="https://asmc.asean.org/wp-content/themes/asmctheme/assets/img/icon-rss.png"></a></li>
          </ul>
        </div>
      </div>
    </div>
    <!-- / .footer-top -->

    <div class="footer-bottom">
      <div class="row">
        <div class="col-6">
          <ul class="list-inline donotresize" style="width: max-content">
            <li class="list-inline-item"><a class="donotresize" href="https://asmc.asean.org/terms-of-use/">Terms &amp; Conditions</a></li>
            <li class="list-inline-item"><span>|</span></li>
            <li class="list-inline-item"><a class="donotresize" href="https://asmc.asean.org/privacy-statement/">Privacy Policy</a></li>
            <li class="list-inline-item"><span>|</span></li>
            <li class="list-inline-item"><a class="donotresize" href="https://asmc.asean.org/asmc-supported-browsers/">Supported Browsers</a></li>
            <li class="list-inline-item"><span>|</span></li>
            <li class="list-inline-item"><a class="donotresize" href="https://www.tech.gov.sg/report_vulnerability">Report Vulnerability</a></li>
          </ul>
        </div>
        <div class="col-6">
          <p class="text-end copyright donotresize">&copy;2026 ASEAN Specialised Meteorological Centre</p>
        </div>
      </div>
    </div>
    <!-- / .footer-bottom -->
  </div>
</footer>
<script type="text/javascript" src="https://asmc.asean.org/wp-includes/js/comment-reply.min.js?ver=6.5.12" id="comment-reply-js" async="async" data-wp-strategy="async"></script>
<script type="text/javascript" src="https://asmc.asean.org/wp-content/themes/asmctheme/js/navigation.js?ver=20140711" id="twentytwelve-navigation-js"></script>
<script src="https://asmc.asean.org/wp-content/themes/asmctheme/js/function_resizer.js" id="resizeFunction" type="text/javascript"></script>
<script type="text/javascript">
  $('#headEventsLink').click(function(){
    deleteCookieCategoryName();
    window.location.href = 'https://asmc.asean.org/events-twenty-sixth-session-of-the-asean-climate-outlook-forum-aseancof-26/';
  });
  $('#headPublicLink').click(function(){
    deleteCookieCategoryName();
    window.location.href = 'https://asmc.asean.org/asmc-annual-report-2025-2026/';
  });
  $('#headWeatherOutlookLink').click(function(){
    deleteCookieCategoryName();
    window.location.href = 'https://asmc.asean.org/subseasonal-weather-outlook-12-25-october-2026/';
  });
  $('#headHazeOutlookLink').click(function(){
    deleteCookieCategoryName();
    window.location.href = 'https://asmc.asean.org/haze-outlook-for-land-fires-and-smoke-haze-situation-16-31-january-2020/';
  });
  $('#weatherTagOutlookLink').click(function(){
    deleteCookieCategoryName();
    window.location.href = 'https://asmc.asean.org/subseasonal-weather-outlook-12-25-october-2026/';
  });
  $('#weatherTagReviewLink').click(function(){
    deleteCookieCategoryName();
    window.location.href = 'https://asmc.asean.org/subseasonal-weather-review-of-regional-weather-for-september-2026/';
  });
  $('#hazeTagOutlookLink').click(function(){
    deleteCookieCategoryName();
    window.location.href = 'https://asmc.asean.org/haze-outlook-for-land-fires-and-smoke-haze-situation-16-31-january-2020/';
  });
  $('#hazeTagReviewLink').click(function(){
    deleteCookieCategoryName();
    window.location.href = 'https://asmc.asean.org/review-of-regional-haze-situation-for-august-2026/';
  });
  $('.breadcrumb').find('*').click(function(){
    deleteCookieCategoryName();
  });

  $('#footEventsLink').click(function(){
    deleteCookieCategoryName();
    window.location.href = 'https://asmc.asean.org/events-twenty-sixth-session-of-the-asean-climate-outlook-forum-aseancof-26/';
  });
  $('#footPublicationsLink').click(function(){
    deleteCookieCategoryName();
    window.location.href = 'https://asmc.asean.org/asmc-annual-report-2025-2026/';
  });
  $('#footWeatherOutlookLink').click(function(){
    deleteCookieCategoryName();
    document.cookie="weatherOutlook=active;path=/";
    document.cookie="weatherReview=inactive;path=/";
    window.location.href = 'https://asmc.asean.org/subseasonal-weather-outlook-12-25-october-2026/';
  });
  $('#footHazeOutlookLink').click(function(){
    deleteCookieCategoryName();
    document.cookie="hazeOutlook=active;path=/";
    document.cookie="hazeReview=inactive;path=/";
    window.location.href = 'https://asmc.asean.org/haze-outlook-for-land-fires-and-smoke-haze-situation-16-31-january-2020/';
  });

</script>

</body>
</html>
<!-- Dynamic page generated in 0.368 seconds. -->
<!-- Cached page generated by WP-Super-Cache on 2026-10-23 19:02:26 -->

<!-- super cache -->