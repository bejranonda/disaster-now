HTTP/1.1 200 OK
server: nginx/1.14.2
date: Fri, 23 Oct 2026 20:08:52 GMT
content-type: text/html
content-length: 127
last-modified: Thu, 06 Nov 2025 22:16:46 GMT
etag: "6e6231e-89-642f46baf596e"
accept-ranges: bytes
vary: Accept-Encoding,User-Agent
content-encoding: gzip

