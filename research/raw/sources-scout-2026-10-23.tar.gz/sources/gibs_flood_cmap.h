HTTP/1.1 200 Connection Established

HTTP/2 404 
content-type: text/html; charset=iso-8859-1
content-length: 58
date: Fri, 23 Oct 2026 19:59:28 GMT
server: ServerTokens ProductOnly
cache-control: public, max-age=3600
x-frame-options: SAMEORIGIN
strict-transport-security: max-age=31536000; includeSubDomains; preload
x-content-type-options: nosniff
x-xss-protection: 1; mode=block
via: 1.1 083eaf3abfded847b96b132a2fc045fc.cloudfront.net (CloudFront)
x-amz-cf-pop: ORD56-P7
x-amz-cf-id: PSdBxQzz-M6AwWeIJ6JOZmDoRPE_-cdhFf6dUO4kwpmWNnJZ1630OA==

