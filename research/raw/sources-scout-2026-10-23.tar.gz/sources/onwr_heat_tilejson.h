HTTP/1.1 200 Connection Established

HTTP/2 200 
content-type: application/json
cache-control: public, max-age=30
access-control-allow-origin: https://disaster-now.example
access-control-allow-credentials: true
vary: Origin
x-cloud-trace-context: f04b024e4eafbce5856b8c70ac0683d9
date: Fri, 23 Oct 2026 20:09:58 GMT
server: Google Frontend
content-length: 360

