<!DOCTYPE html>
<html style="" lang="en">

<head>
  <title>Lightning & Thunderstorms - Impress / Contact</title>
  <meta name="description" content="Blitzortung.org provides lightning and thunderstorm information in real-time on maps for USA, United Kingdom, Australia, new Zealand, Europa, Africa, Asia and other Countries.">
  <meta name="keywords" content="lightning maps, lightning radar, thunderstorm infos, lightning location, rainfall radar, weather">
  <meta name="page-topic" content="Weather">
  <meta name="author" content="Egon Wanke">
  <meta name="page" content="contact">
  <meta charset="utf-8">

  <link rel="SHORTCUT ICON" href="Icons/favicon.ico">
  <link rel="apple-touch-icon" href="Icons/apple-touch-icon.png">
  <meta name="viewport" content="width=device-width, user-scalable=yes, initial-scale=1.0">

  <link rel="stylesheet" href="CSS/font-awesome-4.5.0/css/font-awesome.min.css" type="text/css">
  <link rel="stylesheet" href="CSS/blitzortung.css" type="text/css">
  <link rel="stylesheet" href="CSS/CookiesConsent.css" type="text/css">

  <meta name="robots" content="index,follow">
  <meta name="robots" content="all">
  <meta name="google-site-verification" content="4q9QezdXd17RpC2HbMhJB9VAQDX-mP7_7bZgeptCZjI">

  <script src="JS/lbr.js"></script>
  <script src="JS/jquery-3.4.1.min.js"></script>

  <script>
    document.addEventListener("touchstart", function(){}, true);
    var lang= "en";
    var logged_in= 0;
  </script>

  <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

</head>

<body onload="load()">

<div style="display: table; width:100%; background-color: white; height: 100%">

<div id="nav">
  <div class="left_side" style="display: inline-block;">
    <div id="bo_banner_left">
<svg class="logo_img" height="32" viewBox="70 35.3 221 353">
        <path d="M188.062,42.625c15.504-1.554,31.141-4.362,46.645-5.972c11.543-1.716,9.205,5.483,8.48,7.864
                c-7.863,25.782-16.736,53.557-24.621,79.34c-0.693,2.275-1.344,4.515-2.111,6.99c0.697,0,1.191,0,1.688,0
                c10.926,0,21.857,0,32.791,0c4.457,0,6.842,3.626,5.039,7.601c-18.834,41.238-37.648,82.479-56.488,123.702
                c-4.381,9.625-8.768,19.318-13.191,28.908c-1.109,2.402-3.475,3.52-5.986,2.924c-2.285-0.611-3.871-2.854-3.719-5.307
                c0.691-9.947,1.363-19.881,2.066-29.846c0.83-11.918,1.68-23.816,2.518-35.773c0.785-11.193,1.582-22.388,2.357-33.601
                c0.127-1.915,0.227-3.882,0.354-5.834c-0.398,0.038-0.633,0.038-0.85,0.057c-9.685,1.245-19.382,2.474-29.07,3.735
                c-1.311,0.164-2.592,0.361-3.898,0.469c-2.756,0.22-6.564-1.169-5.166-7.056c1.533-6.303,3.061-12.589,4.559-18.923
                c6.637-27.481,13.254-55.019,19.898-82.537c2.42-10.147,4.885-20.26,7.328-30.441C176.684,48.926,178.25,42.875,188.062,42.625z"
        fill="#41bcda"></path>

        <path d="M247.152,250.332
                l0.354,0.689c5.115,10.748,7.717,22.881,7.086,35.604c-2.041,41.025-36.953,72.629-77.978,70.588
                c-41.025-2.039-72.629-36.951-70.59-77.977c0.947-19.025,8.961-36.023,21.376-48.58l0.937-0.947"
        fill="none" stroke="#FFF" stroke-width="8" stroke-linecap="round" stroke-miterlimit="10"></path>

        <path d="M107.458,207.005
                c-18.481,18.769-29.744,44.632-29.374,73.054c0.735,56.457,47.101,101.631,103.556,100.891
                c56.457-0.734,101.626-47.098,100.894-103.553c-0.188-14.266-3.285-27.811-8.725-40.076l-0.848-1.734"
        fill="none" stroke="#FFF" stroke-width="15" stroke-linecap="round" stroke-miterlimit="10"></path>

        <path d="M220.865,268.004
                c2.84,6.428,4.264,13.633,3.887,21.178c-1.258,25.223-22.178,44.678-46.722,43.455c-24.545-1.227-43.424-22.668-42.166-47.891
                c0.572-11.492,5.227-21.787,12.445-29.473l0.404-0.455"
        fill="none" stroke="#FFF" stroke-width="5.0686" stroke-linecap="round" stroke-miterlimit="10"></path>
</svg>
	Blitzortung.org</div>
    <div id="menu_icon">
      <div class="menu_item">
        <span style="color: #39C0E0; font-size: 2em; vertical-align: middle;"><i class="fa fa-bars" style="vertical-align: middle; margin: 4px 0px;"></i></span>
        <div class="vertical" style="position: absolute; left: 0px;">
          <a href="live_lightning_maps.php" >Realtime Maps: Fixed Size</a>
          <a href="live_dynamic_maps3.php" >Realtime Maps: Dynamic Size</a>
          <a href="https://maps.blitzortung.org" target="_blank" >Realtime Maps: Vector Map</a>
          <a href="historical_maps.php" >Historical Data: Historical Maps</a>
          <a href="archive_data.php" >Historical Data: Customized Archive Data</a>
          <a href="whats_new.php" >Further Info: What’s New?</a>
          <a href="cover_your_area.php" >Further Info: Cover your Area</a>
          <a href="forum.php" >Further Info: Forum</a>
          <div class="aa" >Project Area: User Data</div>
          <div class="aa" >Project Area: Compendium</div>
          <a href="station_list.php" >Project Area: Station List</a>
          <a href="map_generator.php" >Project Area: Map Generator</a>
          <a href="login.php" ><b class="fa fa-sign-in"></b>Login</a>
        </div>
      </div>
    </div>
  </div>
  <div class="right_side">
    <div id="bo_banner_right">
<svg class="logo_img" height="32" viewBox="70 35.3 221 353">
        <path d="M188.062,42.625c15.504-1.554,31.141-4.362,46.645-5.972c11.543-1.716,9.205,5.483,8.48,7.864
                c-7.863,25.782-16.736,53.557-24.621,79.34c-0.693,2.275-1.344,4.515-2.111,6.99c0.697,0,1.191,0,1.688,0
                c10.926,0,21.857,0,32.791,0c4.457,0,6.842,3.626,5.039,7.601c-18.834,41.238-37.648,82.479-56.488,123.702
                c-4.381,9.625-8.768,19.318-13.191,28.908c-1.109,2.402-3.475,3.52-5.986,2.924c-2.285-0.611-3.871-2.854-3.719-5.307
                c0.691-9.947,1.363-19.881,2.066-29.846c0.83-11.918,1.68-23.816,2.518-35.773c0.785-11.193,1.582-22.388,2.357-33.601
                c0.127-1.915,0.227-3.882,0.354-5.834c-0.398,0.038-0.633,0.038-0.85,0.057c-9.685,1.245-19.382,2.474-29.07,3.735
                c-1.311,0.164-2.592,0.361-3.898,0.469c-2.756,0.22-6.564-1.169-5.166-7.056c1.533-6.303,3.061-12.589,4.559-18.923
                c6.637-27.481,13.254-55.019,19.898-82.537c2.42-10.147,4.885-20.26,7.328-30.441C176.684,48.926,178.25,42.875,188.062,42.625z"
        fill="#41bcda"></path>

        <path d="M247.152,250.332
                l0.354,0.689c5.115,10.748,7.717,22.881,7.086,35.604c-2.041,41.025-36.953,72.629-77.978,70.588
                c-41.025-2.039-72.629-36.951-70.59-77.977c0.947-19.025,8.961-36.023,21.376-48.58l0.937-0.947"
        fill="none" stroke="#FFF" stroke-width="8" stroke-linecap="round" stroke-miterlimit="10"></path>

        <path d="M107.458,207.005
                c-18.481,18.769-29.744,44.632-29.374,73.054c0.735,56.457,47.101,101.631,103.556,100.891
                c56.457-0.734,101.626-47.098,100.894-103.553c-0.188-14.266-3.285-27.811-8.725-40.076l-0.848-1.734"
        fill="none" stroke="#FFF" stroke-width="15" stroke-linecap="round" stroke-miterlimit="10"></path>

        <path d="M220.865,268.004
                c2.84,6.428,4.264,13.633,3.887,21.178c-1.258,25.223-22.178,44.678-46.722,43.455c-24.545-1.227-43.424-22.668-42.166-47.891
                c0.572-11.492,5.227-21.787,12.445-29.473l0.404-0.455"
        fill="none" stroke="#FFF" stroke-width="5.0686" stroke-linecap="round" stroke-miterlimit="10"></path>
</svg>
    Blitzortung.org</div>
    <div id="menu_main">
      <div class="menu_item">
        <span ><i class="fa fa-caret-down"></i>Realtime Maps</span>
        <div id="top0_vertical" class="vertical">
          <a href="live_lightning_maps.php" >Fixed Size</a>
          <a href="live_dynamic_maps3.php" >Dynamic Size</a>
          <a href="https://maps.blitzortung.org" target="_blank" > Vector Map</a>
        </div>
      </div>

      <div class="menu_item">
        <span ><b class="fa fa-caret-down"></b>Historical Data</span>
        <div class="vertical">
          <a href="historical_maps.php" >Historical Maps</a>
          <a href="archive_data.php" >Customized Archive Data</a>
        </div>
      </div>

      <div class="menu_item">
        <span ><b class="fa fa-caret-down"></b>Further Info</span>
        <div class="vertical">
          <a href="whats_new.php" >What’s New?</a>
          <a href="cover_your_area.php" >Cover your Area</a>
          <a href="forum.php" >Forum</a>
        </div>
      </div>

      <div class="menu_item">
        <span ><b class="fa fa-caret-down"></b>Project Area</span>
        <div class="vertical">
          <div class="aa" >User Data</div>
          <div class="aa" >Compendium</div>
          <a href="station_list.php" >Station List</a>
          <a href="map_generator.php" >Map Generator</a>
        </div>
      </div>

      <div class="menu_item">
        <a href="login.php" ><b class="fa fa-sign-in"></b>Login</a>
      </div>
    </div>
  </div>
</div>

<div id="motd" style="background-color: #F6F6F6;"> <span style="white-space: nowrap; font-size: 9pt; font-weight: normal;">Network for Lightning and Thunderstorms in Real Time</span> - <span style="white-space: nowrap; font-size: 9pt; font-weight: normal;"><a href="https://maps.blitzortung.org" target="_blank"><i class="fa fa-external-link"></i> Real time lightning map</a></span></div>

<table style="width: 100%; background: white; margin-top: 5px;">
  <tr>
    <td style="padding: 5px 10px; width: 100%; text-align: center;">
      <div style="display: inline-block; vertical-align: top; width: auto; max-width: 935px; text-align: left;">

        

        <a id="contribution_1"></a>
        <div class="contribution">
          <div class="head">Important information for our visitors</div>
          <div class="content"><img src="Menu_Images/Blitzortung_Logo_klein_2014.jpg" alt="" class="deco" style="float: right;">
"Blitzortung.org" is not an official authority for lightning or thunderstorm data.
The data shown on our website is provided only for private and entertainment purposes.
The project "Blitzortung.org" is for the contributors merely a voluntary leisure activity.
<div style="clear: both;"></div></div>
          <div class="content"><span style="font-weight: bold; color: red;">It is not allowed to use our lightning data for storm warning systems, for plausibility checks of overvoltage damages, or risk analysis for precautionary protection of high-quality technology, even if the data are not obtained directly from our site but from third-party websites.</span>
<div style="clear: both;"></div></div>
          <div class="content">All images marked by "CC BY-SA" are licensed under the "Creative Commons Attribution-ShareAlike 4.0" license <a href="https://creativecommons.org/licenses/by-sa/4.0/">(CC BY-SA 4.0)</a> and may therefore be included on other websites under this license without further approval from us.
The use of our raw lightning data is allowed only to the participants of the project or to those we explicitly have allowed it.
<div style="clear: both;"></div></div>
        </div>

        <a id="contribution_2"></a>
        <div class="contribution">
          <div class="head"></div>
          <div class="content"><div style="clear: both;"></div></div>
          <div class="content"><div class="center">Server load:&nbsp;&nbsp;&nbsp;0.00&nbsp;&nbsp;&nbsp;0.02&nbsp;&nbsp;&nbsp;0.00&nbsp;&nbsp;&nbsp;2/635&nbsp;&nbsp;&nbsp;1937077
<div style="clear: both;"></div></div></div>
        </div>

        <a id="contribution_3"></a>
        <div class="contribution">
          <div class="head">Disclaimer</div>
          <div class="content">We are not liable for the completeness, timeliness, quality and accuracy of the information on our website.
We are not responsible for damages, resulting from trusting the content of our website or its use.
This also holds if our data is obtained from third-party websites.
<div style="clear: both;"></div></div>
          <div class="content">Our sites contain links to other websites, whose contents are subject to change at any time.
We are not responsible for the content of linked websites.
<div style="clear: both;"></div></div>
        </div>

        <a id="contribution_4"></a>
        <div class="contribution">
          <div class="head">Privacy Policy</div>
          <div class="content"><u>What data we store:</u>
We store any information you enter on our website or give us in any other way whenever you interact with us, with our web servers, or by email.
Our web servers obtain certain information when your web browser accesses "Blitzortung.org".
You should ask the provider of your web browser what information your browser passes to web servers (IP address, operationg system, supported languages, ...) and how you can restrict this information.
<div style="clear: both;"></div></div>
          <div class="content"><u>Why we store data:</u>
We mainly store data (depending on the type of the data)
<ul>
<li>to compute lightning and thunderstorm areas,</li>
<li>to get in contact with the participants,</li>
<li>to control access rights,</li>
<li>to ensure a smooth operation of our computing and web servers,</li>
<li>to improve the usability of our website, or</li>
<li>to comply with law.</li>
<ul>
<div style="clear: both;"></div></div>
          <div class="content"><u>What other services and third-party software we use:</u>
Our website use <a href="https://www.google.com/adsense/start/">Google AdSense</a> (a program run by Google to serve automatic advertisements), <a href="https://matomo.org/">Matomo</a> (an open source web analytics platform), and <a href="https://www.mybb.com/">MyBB</a> (a free and open source forum software).
</ul>
<div style="clear: both;"></div></div>
        </div>

        <a id="contribution_5"></a>
        <div class="contribution">
          <div class="head">Cookie Policy <div style="font-size: 8pt;">(Google Inc. demand of us to publish the following information, because we use Google AdSense.)</div></div>
          <div class="content">Our sites use browser cookies.
Browser cookies allow us to store small pieces of information on your device (computer, notebook/laptop, tablet, mobile phone) that can be read at a later time when you call our website again.
"Blitzortung.org" mainly uses cookies to store the basic settings you have selected on your last visit. For example, we store in browser cookies the last choosed zoom level of the dynamic map and whether you have confirmed reading the cookie policy.
At your next visit you will proceed with the same dynamic map view and you will not see again the request to read the cookies policy.
<div style="clear: both;"></div></div>
          <div class="content">The used services and third-party software <a href="https://www.google.com/adsense/start/">Google AdSense</a>,  <a href="https://matomo.org/">Matomo</a>, and <a href="https://www.mybb.com/">MyBB</a> use also browser cookies whose use is not always known to us.
<div style="clear: both;"></div></div>
          <div class="content"><div style="clear: both;"></div></div>
        </div>

        <a id="contribution_6"></a>
        <div class="contribution">
          <div class="head">Contact</div>
          <div class="content"><table style="background-color:#E7E7E7; margin: 0px auto;">
<tr><td style="border: 1px solid #606060; padding: 0px;"><img style="margin: 0px; padding: 0px; width: 443px" src="../../Menu_Images/Address.png" alt="Address"></img></td></tr>
<tr><td style="border: 1px solid #606060; padding: 4px;">We receive a lot of emails every day. Because Blitzortung.org is purely a leisure project and we all have jobs to earn our living, we unfortunately cannot answer every email. Please use the forums.<br></td></tr>
<tr><td style="border: 1px solid #606060; padding: 4px; color: red; font-weight: bold;">Please do <u>NOT</u> use this contact information for requests about lightning strikes in your area at certain times. Please contact commercial location services for such queries.</td></tr>
</table>
<div style="clear: both;"></div></div>
        </div>

        <a id="contribution_7"></a>
        <div class="contribution">
          <div class="head">Services that use our data</div>
          <div class="content"><ul>
<li><a href="https://www.blitzortung.org">www.blitzortung.org</a></li>
<li><a href="https://map.blitzortung.org">map.blitzortung.org</a></li>
<li><a href="https://www.lightningmaps.org">www.lightningmaps.org</a></li>
<li><a href="https://play.google.com/store/apps/details?id=org.blitzortung.android.app">Blitzortung Gewitter-Monitor (Android App)</a></li>
</ul>
Our real-time and archived data can also be used for external projects.
<ul>
<li> The project may not represent commercial interests. </li>
<li> It must be of general interest for the participants of Blitzortung.org.</li>
<li> It must be different from existing projects. Do not just reimplement other projects. Do not setup yet another visualization of online data.</li>
<li> All applications that use our data must be freely accessible.</li>
<li> The source of the data must be clearly identified.</li>
<li> The operator must prevent any possible misuse of the data provided, as far as this is possible.</li>
</ul>
The applications (web sites, apps, ...) have to retrieve their data from a separate server and not from the servers of Blitzortung.org. All data remain under the CC-BY-SA 4.0 license.
<p>
Schools, scientific institutions, and research facilities that use our data.
<ul>
<li></li>
<li></li>
<li></li>
</ul>
<div style="clear: both;"></div></div>
        </div>

        <a id="contribution_8"></a>
        <div class="contribution">
          <div class="head">Make a donation for Blitzortung.org to continue this services free of charge.</div>
          <div class="content"><div class="center"><a href="https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=XHDY4N8WTJ87A" target="_blank"><img style="margin: 0px; width: 98%; max-width: 728px;" src="../../Menu_Images/donate.png" alt="Make a donation to Blitzortung.org!"></img></a><br><span style="font-size: 9pt; font-weight: normal;">Please note: Contributions to Blitzortung.org are not tax deductible.</span></div>
<div style="clear: both;"></div></div>
        </div>

        <a id="contribution_9"></a>
        <div class="contribution">
          <div class="head">And finally!</div>
          <div class="content">A big thanks to all the participants of the project who have been sending data to Blitzortung.org over the years, making the project possible.<div style="clear: both;"></div></div>
          <div class="content"><div style="float: right"><a href="https://gmt.soest.hawaii.edu" target="_blank"><img style="margin-bottom: 20px; width: 223px;" src="../../Menu_Images/logo-gmt5.png" alt="GMT Logo"></img></a></div>
A big thanks to the developers of the Generic Mapping Tools. The Generic Mapping Tools, GMT, are an open source collection of tools for manipulating geographic and Cartesian data sets (including filtering, trend fitting, gridding, projecting, etc.) and producing PostScript illustrations ranging from simple x–y plots via contour maps to artificially illuminated surfaces and 3D perspective views. It is released under the GNU Lesser General Public License.
<a href="https://github.com/GenericMappingTools" target="_blank"><i class="fa fa-github" aria-hidden="true"></i></a><div style="clear: both;"></div></div>
          <div class="content"><div style="float: right"><a href="https://www.openstreetmap.org" target="_blank"><img style="margin-bottom: 20px; width: 128px;" src="../../Menu_Images/osm_logo.svg" alt="OpenStreetMap Logo"></img></a></div>
A big thanks to OpenStreetMap and the contributors of Openstreetmap. OpenStreetMap is a map of the world, created by people like you and free to use under an open license. <a href="https://github.com/OpenStreetMap" target="_blank"><i class="fa fa-github" aria-hidden="true"></i></a><div style="clear: both;"></div></div>
        </div>

        </div>
      </div>

    </td>

    <td>
      <div id="banner_right" style="width: 120px; height: 600px; margin-left: 5px; margin-right: 5px;"><div>
<!-- map_120_600 -->
<ins class="adsbygoogle" style="display:inline-block;width:120px;height:600px" data-ad-client="ca-pub-6007590914292843" data-ad-slot="7404676758"></ins>
<script> (adsbygoogle = window.adsbygoogle || []).push({}); </script></div></div>
    </td>
  </tr>
</table>
<div id="banner_center" style="width: 100%; padding: 10px 0px; background: white;"><div style="max-width: 728px; max-height: 90px; margin: 0px auto;">
<!-- map_728_90 -->
<ins class="adsbygoogle" style="display:inline-block;width:100%;height:90px" data-ad-client="ca-pub-6007590914292843" data-ad-slot="5851092018"></ins>
<script> (adsbygoogle = window.adsbygoogle || []).push({}); </script></div></div>

<div style="width: 100%; text-align: center; background-color: #F6F6F6; color: #161616;">
</div>

<div style="width: 100%; text-align: center; background-color: #F6F6F6; color: #161616; padding-bottom: 10px;">
  <div id="copy_rights" style="padding: 8px 12px;"></div>

  <div id="quick_links">
    <div class="bot_head">Quick Links</div>
    <a href="contact.php">Important Advices</a>
    <a href="contact.php#contribution_3">Disclaimer</a>
    <a href="contact.php#contribution_4">Privacy Policy</a>
    <a href="contact.php#contribution_5">Cookie Policy</a>
    <a href="contact.php#contribution_6">Imprint / Contact</a>
    <a href="contact.php#contribution_7">Projects</a>
    <a href="contact.php#contribution_8">Donations</a>
  </div>

  <div id="social_nets">
    <div class="bot_head">Social Networks</div>
    <a href="https://www.facebook.com/Blitzortung" target="_blank"><div class="sni_f"><img src="Menu_Images/facebook.png" width="32" height="32" alt="facebook" style="vertical-align: middle;"> LIKE US ON FACEBOOK</div></a>
    <a href="https://twitter.com/Blitzortung_Org" target="_blank"><div class="sni_t"><img src="Menu_Images/twitter.png" width="32" height="32" alt="twitter" style="vertical-align: middle;"> FOLLOW US IN TWITTER</div></a>
  </div>

  <div id="select_language">
    <div class="bot_head">Select your menu language</div>
    <a href="../index.php?lang=cs">čeština</a><a href="../index.php?lang=da">dansk</a><a href="../index.php?lang=de">deutsch</a><a href="../index.php?lang=el">ελληνικά</a><a href="../index.php?lang=en"><span style="color: #39C0E0;">english</span></a><a href="../index.php?lang=es">español</a><a href="../index.php?lang=fi">suomeksi</a><a href="../index.php?lang=fr">français</a><a href="../index.php?lang=hu">magyar</a><a href="../index.php?lang=it">italiano</a><a href="../index.php?lang=jp">日本語</a><a href="../index.php?lang=lv">latviski</a><a href="../index.php?lang=nl">nederlandse</a><a href="../index.php?lang=nb">norsk</a><a href="../index.php?lang=mk">македонски</a><a href="../index.php?lang=pl">polski</a><a href="../index.php?lang=pt">português</a><a href="../index.php?lang=ru">русский</a><a href="../index.php?lang=sr">српски</a><a href="../index.php?lang=sv">svenska</a><a href="../index.php?lang=tr">türk</a><a href="../index.php?lang=uk">український</a>
    <div class="only_en">If your language is not supported and if you want to adapt the menu language, then write an email to info ☺ blitzortung.org.</div>
  </div>
</div>
</div>

<p>

<footer>
A worldwide, real-time, community collaborative lightning location network. © 2003-2026 Blitzortung.org Contributors
</footer>

<script>
  var L_motd= "Network for Lightning and Thunderstorms in Real Time";
  var L_copy_rights= "A worldwide, real-time, community collaborative lightning location network. © 2003-2026 Blitzortung.org Contributors";
</script>
<script src="JS/index.js"></script>
<script src="JS/contact.js"></script>
<div id="topdiv" class="topdiv">

<div class="cookie_div">

<p style="font-weight: bold; max-width: 640px; font-size: large;">

This website uses cookies
<img id="cookieImage" src="https://www.blitzortung.org/CookiesConsent/cookie.jpg" alt="Cookie" style="vertical-align: middle; display: none;" width="50">


<p style="max-width: 640px;">

We use cookies to personalise content, to analyse our traffic, and to show advertisements. Displaying advertisements could share information about your use of our site with advertising partners who may combine it with other information that you are provided to them or that they have collected from your use of their services. Choose the type of cookies you're happy for us to use (you can change them anytime), or just accept.

<span id="selection" style="max-width: 640px; display: none;">

<br>
Certain types of cookie are essential to use our site. We store the time and the selection of your consent anonymously under the identification stored in cookie "ID".

<br>
<br>

<span style="padding:3px; display: inline-block;" title="">
<input style="width: 20px; height: 20px;" type="checkbox" id="necessary_checkbox" name="necessary" onclick="change(10)">
<label for="necessary_checkbox">Technically necessary</label>

<span id="necessary_info" style="display: inline-block;">Necessary cookies make a website usable by enabling basic functions like page navigation and access to secure areas of the website. The website cannot function properly without these cookies.</span>
</span>

<br>

<span style="padding:3px; display: inline-block;" title="">
<input style="width: 20px; height: 20px;" type="checkbox" id="preferences_checkbox" name="preferences" onclick="change(11)">
<label for="preferences_checkbox">Preferences</label>

<span id="preferences_info" style="display: inline-block;">Preference cookies enable a website to remember information that changes the way the website behaves or looks, like your preferred language or the map you are looking at. These include the cookies LANGUAGE, MAP, DISPLAYSTR, DISPLAYDET and SOUND, which were used for the language currently set, the last map displayed, the settings last used to display strikes and detectors and the setting currently used for playing sound.
</span>
</span>

<br>

<span style="padding:3px; display: inline-block;" title="">
<input style="width: 20px; height: 20px;" type="checkbox" id="statistic_checkbox" name="statistic" onclick="change(12)">
<label for="statistic_checkbox">Statistic</label>

<span id="statistic_info" style="display: inline-block;">Statistic cookies help us to understand how, when, and from where visitors interact with our websites by collecting and reproting information anonymously.</span>
</span>

</span>

<p style="max-width: 640px;">

<span style="display: inline-block; width: 100%; text-align: right;">

<a style="color: gray; text-decoration: underline; float: left;" href="https://www.blitzortung.org/en/contact.php?PrivacyPolicy=1#contribution_4">Privacy &amp; Cookies Policy</a>

<span class="button" style="background-color: white; color: #2196F3; display: none;" onclick="change(1)">Use necessary cookies only</span>

<span id="select_cookies" class="button" style="background-color: white; color: #2196F3; display: inline-block;" onclick="change(2)">Select settings</span>

<span id="decline" class="button" style="border-color: #BFBFBF; background-color: #FFFFFF; color: #BFBFBF; display: none;" onclick="change(5)">Decline</span>

<span id="allow_selection" class="button" style="background-color: #FFFFFF; color: #2196F3; display: none;" onclick="change(3)">Accept selection</span>

<span class="button" style="background-color: #2196F3; color: white; margin-left: auto;" onclick="change(4)">Accept all</span>

</span>

</div>

</div>

<script>
function getCookie(name) {
	const decodedCookie = decodeURIComponent(document.cookie);
	const ca = decodedCookie.split(';');
	name = name + "=";

	for(let i = 0; i < ca.length; i++) {
		let c = ca[i];
		while (c.charAt(0) === ' ') {
			c = c.substring(1);
		}
		if (c.indexOf(name) === 0) {
			return c.substring(name.length, c.length);
		}
	}
	return "";
}

function setCookie(name, value, days) {
	const date = new Date();
	if (days == 0) { // set time to one hour
		date.setTime(date.getTime() + (1*60*60*1000));
	}
	else {
		date.setTime(date.getTime() + (days*24*60*60*1000));
	}
	const expires = "expires=" + date.toUTCString();
	document.cookie = name + "=" + value + ";" + expires + ";path=/" + "; SameSite=Lax; Secure";
}

//
//
//
var topdiv= document.getElementById('topdiv');

//
// cookies
//
function setSelection (consent) {
	var CookiesNecessary= 0x01;
	var CookiesPreferences= 0x02;
	var CookiesStatistic= 0x04;
	var CookiesMarketing= 0x08;

	//
	var ID= getCookie("ID");
	if ( (ID == "") || (ID.length != 32) ) {
		setCookie("ID", "dafdb91715886ef2893b24a2c6cd40ab", 365);
	}

	//
	if (consent & CookiesNecessary) {
		//
	}

	//
	if (consent & CookiesPreferences) {
		//
	}

	if (consent & CookiesStatistic) {
		//
	}

	//
	if (consent & CookiesMarketing) {
		(adsbygoogle = window.adsbygoogle || []).pauseAdRequests=0;
		setCookie("CONSENT", consent, 365);
	}
	else {
		setCookie("CONSENT", consent, 1);
	}

	//
	topdiv.style.display= 'none';

	//
	$.get ('CookiesConsent/logCookiesConsent.php');
}

function change (n)
{

	var cookieImage= document.getElementById('cookieImage');

	var necessary_checkbox= document.getElementById('necessary_checkbox');
	var preferences_checkbox= document.getElementById('preferences_checkbox');
	var statistic_checkbox= document.getElementById('statistic_checkbox');

	var necessary_info= document.getElementById('necessary_info');
	var preferences_info= document.getElementById('preferences_info');
	var statistic_info= document.getElementById('statistic_info');

	var select_cookies= document.getElementById('select_cookies');
	var allow_selection= document.getElementById('allow_selection');
	var selection= document.getElementById('selection');
	var decline= document.getElementById('decline');



	var newConsent= 0x00;

	//
	// Necessary checked
	//
	necessary_checkbox.checked= true;
	newConsent|= 0x01;

	//
	// Preferences checked
	//
	if (preferences_checkbox.checked) {
		newConsent|= 0x02;
	}

	//
	// Statistic checked
	//
	if (statistic_checkbox.checked) {
		newConsent|= 0x04;
	}

	//
	// null run
	//
	if (n == 0) {
		//
	}
	//
	// accept necessary cookies
	//
	else if (n == 1) {
		setSelection(newConsent);
	}
	//
	// chanche to "select setting"
	//
	else if (n == 2) {
		select_cookies.style.display= 'none';
		cookieImage.style.display= 'inline-block';
		allow_selection.style.display= 'inline-block';
		selection.style.display= 'inline-block';
		// decline.style.display= 'inline-block';
	}
	//
	// accept slected cookies
	//
	else if (n == 3) { // accept selection
		setSelection(newConsent);
	}
	//
	// accept all cookies
	//
	else if (n == 4) { // accept all
		setSelection(0x0F);
	}
	//
	// decline adverticing cookies
	//
	else if (n == 5) { // decline
		setSelection(0x09);
	}

}

$(document).ready(function() {
	setTimeout (function(){
		var consent= getCookie("CONSENT");
		if (consent == "") {
			change(0);
			topdiv.style.display= 'flex';
		}
	}, 500);
});

</script>
</body>
</html>
