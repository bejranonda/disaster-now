<html>
<head>
	<title>
		sound24thai
	</title>
	<meta http-equiv="refresh" content="0; url=index.php" />
</head>
<body>
</body>

</html>
