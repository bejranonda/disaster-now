HTTP/1.1 200 Connection Established

HTTP/2 200 
date: Fri, 23 Oct 2026 19:55:21 GMT
content-type: text/html; charset=utf-8
vary: Accept-Encoding
server: cloudflare
x-powered-by: PHP/5.3.28
x-powered-by: ASP.NET
access-control-allow-origin: https://wxmap.tmd.go.th
access-control-allow-methods: GET, OPTIONS
access-control-allow-headers: Content-Type
access-control-allow-private-network: true
cf-cache-status: DYNAMIC
content-encoding: gzip

