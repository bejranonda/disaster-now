HTTP/1.1 200 Connection Established

HTTP/2 200 
content-type: image/png
date: Fri, 23 Oct 2026 19:58:40 GMT
strict-transport-security: max-age=31536000; includeSubDomains; preload
x-content-type-options: nosniff
server: ServerTokens ProductOnly
pragma: no-cache
expires: Thu, 1 Jan 1970 00:00:00 GMT
cache-control: max-age=0, no-store, no-cache, must-revalidate
access-control-allow-origin: *
x-xss-protection: 1; mode=block
x-frame-options: SAMEORIGIN
via: 1.1 ee577eca64c62b377915121bc88081d2.cloudfront.net (CloudFront)
x-amz-cf-pop: IAD61-P5
x-amz-cf-id: _YQHcOF5dVuvR-SuMWyhM7w8vM-G0BYn-iKeSFZG37SxXY4e_oLK4A==

