﻿<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=Edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="keywords" content="#">
  <meta name="description" content="#">
  <!-- Facebook Meta Tags -->
  <meta property="og:url" content="Sentinel Asia,Asia-Pacific Regional,International Disaster Management,space technology">
  <meta property="og:type" content="website">
  <meta property="og:title" content="#">
  <meta property="og:description" content="Sentinel Asia, an international cooperation project launched with the aim of contributing to disaster management in the Asia-Pacific region using space technology.">
  <meta property="og:image" content="#">
  <!-- Twitter Meta Tags -->
  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:title" content="#">
  <meta name="twitter:description" content="#">
  <meta name="twitter:image" content="#">
  <!-- Title -->
  <title>Emergency Observation</title>
  <!-- Favicon -->
  <link rel="apple-touch-icon" sizes="57x57" href="#">
  <link rel="apple-touch-icon" sizes="60x60" href="#">
  <link rel="apple-touch-icon" sizes="72x72" href="#">
  <link rel="apple-touch-icon" sizes="76x76" href="#">
  <link rel="apple-touch-icon" sizes="114x114" href="#">
  <link rel="apple-touch-icon" sizes="120x120" href="#">
  <link rel="apple-touch-icon" sizes="144x144" href="#">
  <link rel="apple-touch-icon" sizes="152x152" href="#">
  <link rel="apple-touch-icon" sizes="180x180" href="#">
  <link rel="icon" type="image/png" sizes="192x192" href="#">
  <link rel="icon" type="image/png" sizes="32x32" href="#">
  <link rel="icon" type="image/png" sizes="96x96" href="#">
  <link rel="icon" type="image/png" sizes="16x16" href="#">
  <link rel="shortcut icon" href="https://sentinel-asia.org/favicon.ico" type="image /vnd.microsoft.icon">
  <!-- CSS -->
  <link rel="stylesheet" href="../css/slick/slick.css">
  <link rel="stylesheet" href="../css/slick/slick-theme.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v6.5.1/css/all.css">
  <link rel="stylesheet" href="../css/style.css">
  <link rel="stylesheet" href="../css/2nd.css">
<!-- Page Include -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="../js/include.js"></script>
<script>
  var dir = '../'
  headerInclude(dir);
  footerInclude(dir);
</script>
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0], j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-NM69TQ3N');</script>
<!-- End Google Tag Manager -->
</head>

<body>
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-NM69TQ3N"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
<header></header>

<main>
	<article>
	<div class="container">

	<h1 class="title">
	<span class="has-icon">Emergency Observation</span>
	</h1>
			
			
<!-- ■■　開始　■■ -->
			
<div style="border: 3px solid #1981c3; border-radius:8px; box-shadow:0px 1px 2px 1px rgba(25,129,195, 0.5); margin:0px 0px 11px 0px; padding:8px;">
<a href="#2026">2026</a> | <a href="#2025">2025</a> | <a href="#2024">2024</a> | <a href="#2023">2023</a> | <a href="#2022">2022</a> | <a href="#2021">2021</a> | <a href="#2020">2020</a> | <a href="#2019">2019</a> | <a href="#2018">2018</a> | <a href="#2017">2017</a> | <a href="#2016">2016</a> | <a href="#2015">2015</a> | <a href="#2014">2014</a> | <a href="#2013">2013</a> | <a href="#2012">2012</a> | <a href="#2011">2011</a> | <a href="#2010">2010</a> | <a href="#2009">2009</a> | <a href="#2008">2008</a> | <a href="#2007">2007</a>
			</div>
				
			<a name="2026" id="2026"></a>
			 <input id="acd-check2026" class="acd-check" type="checkbox">
  <label class="acd-label" for="acd-check2026">2026</label>
  <span class="acd-content">
				<ul class="defaultlist note">
					 
			<li><a href="2026/article20261014TR.html">2026-10-14: Flood in Istanbul, Turkey on 14 October, 2026</a><img src="../image/new019_06.gif" /></li>
			<li><a href="2026/article20261010NP.html">2026-10-10: Flood and Landslide in Gorkha District, Nepal on 10 October, 2026</a><img src="../image/new019_06.gif" /></li>
			<li><a href="2026/article20261001MM.html">2026-10-01: Flood and Landslide in Dawei District, Myanmar on 01 October, 2026</a><img src="../image/new019_06.gif" /></li>
			<li><a href="2026/article20260926TH.html">2026-09-26: Flood in Bangkok, Thailand on 26 September, 2026</a><img src="../image/new019_06.gif" /></li>
			<li><a href="2026/article20260913VN.html">2026-09-13: Flood in Central Region, Vietnam on 13 September, 2026</a><img src="../image/new019_06.gif" /></li>
			<li><a href="2026/article20260828PH.html">2026-08-28: Flood and Landslide in Luzon Island, Philippines on 28 August, 2026</a></li>
			<li><a href="2026/article20260826NP.html">2026-08-26: Flash Flood in Rasuwa District, Nepal on 26 August, 2026</a></li>
			<li><a href="2026/article20260822VN.html">2026-08-22: Flood Concerns Due to Storm Narra in Northern Vietnam on 22 August, 2026</a></li>
			<li><a href="2026/article20260815ID.html">2026-08-15: Earthquake in Flores region, Indonesia on 15 August, 2026</a></li>
			<li><a href="2026/article20260803MM.html">2026-08-03: Flood in Laymyethna Township, Myanmar on 03 August, 2026</a></li>
			<li><a href="2026/article20260718VN.html">2026-07-18: Flood and Landslide in Northern Vietnam on 18 July, 2026</a></li>
			<li><a href="2026/article20260728JP.html">2026-07-28: Earthquake in Kumamoto Prefecture, Japan on 28 July, 2026</a></li>
			<li><a href="2026/article20260714KZ.html">2026-07-14: Wildfire in Akmola Region, Kazakhstan on 14 July, 2026</a></li>
			<li><a href="2026/article20260713KG.html">2026-07-13: Flood in Nooken District, Kyrgyzstan on 13 July, 2026</a></li>
			<li><a href="2026/article20260711TJ.html">2026-07-11: Flood and Mudflow in Ayni District, Tajikistan on 11 July, 2026</a></li>
			<li><a href="2026/article20260708PH.html">2026-07-08: Flood and Landslide in Mindanao, Philippines on 08 July, 2026</a></li>
			<li><a href="2026/article20260704KG-2.html">2026-07-04: Landslide in Jalal-Abad Region, Kyrgyzstan on 04 July, 2026</a></li>
			<li><a href="2026/article20260704KG.html">2026-07-04: Mudflow Descended in Grigoryevsky Gorge, Kyrgyzstan on 04 July, 2026</a></li>
			<li><a href="2026/article20260703VN.html">2026-07-03: Flood Concerns Due to Intense Rainfall in Northern Vietnam on 03 July, 2026</a></li>
			<li><a href="2026/article20260701KZ.html">2026-07-01: Flood in Almaty Region, Kazakhstan on 01 July, 2026</a></li>
			<li><a href="2026/article20260622TW.html">2026-06-22: Barrier Lake Concerns Due to Landslide in Eastern Taiwan on 22 June, 2026</a></li>
			<li><a href="2026/article20260608PH.html">2026-06-08: Earthquake in Southern Mindanao, Philippines, on 08 June, 2026</a></li>
			<li><a href="2026/article20260604KG.html">2026-06-04: Large Rockfall in Jalal-Abad Region, Kyrgyzstan on 04 June, 2026</a></li>
			<li><a href="2026/article20260605KG.html">2026-06-05: Landslide along the shore of Lake Issyk-Kul, Kyrgyzstan on 05 June, 2026</a></li>
			<li><a href="2026/article20260524UZ.html">2026-05-24: Flood in Samarkand Region, Uzbekistan on 24 May, 2026</a></li>
			<li><a href="2026/article20260524KG.html">2026-05-24: Mudflow in Jalal-Abad Region, Kyrgyzstan on 24 May, 2026</a></li>
			<li><a href="2026/article20260504KG.html">2026-05-04: Flood in Kyrgyzstan on 04 May, 2026</a></li>
			<li><a href="2026/article20260501TJ.html">2026-05-01: Flood and Landslide in Tajikistan on 01 May, 2026</a></li>
			<li><a href="2026/article20260502PH.html">2026-05-02: Eruption Occurred Mayon Volcano in Philippines on 02 May, 2026</a></li>
			<li><a href="2026/article20260406KZ.html">2026-04-06: Flood Due to Collapsed of Dam in Kazakhstan on 06 April, 2026</a></li>
					 
				</ul>
	      </span>
<br>
<br>
			<a name="2025" id="2025"></a>
			 <input id="acd-check2025" class="acd-check" type="checkbox">
  <label class="acd-label" for="acd-check2025">2025</label>
  <span class="acd-content">
				<ul class="defaultlist note">
					 
			<li><a href="2025/article20251126LK.html">2025-11-26: Flood Due to Cyclone Ditwah in Sri Lanka on 26 November, 2025</a></li>
			<li><a href="2025/article20251128ID.html">2025-11-28: Flood and Landslide in North Sumatra, Indonesia on 28 November, 2025</a></li>
			<li><a href="2025/article20251119TH.html">2025-11-19: Heavy Rains Flood in Southern Thailand on 19 November, 2025</a></li>
			<li><a href="2025/article20251119VN.html">2025-11-19: Flood in Central Vietnam on 19 November, 2025</a></li>
			<li><a href="2025/article20251119ID.html">2025-11-19: Volcano Eruption at Mt. Semeru in Indonesia on 19 November, 2025</a></li>
			<li><a href="2025/article20251108PH.html">2025-11-08: Flood Due to Typhoon FUNG-WONG in Philippines on 08 November, 2025</a></li>
			<li><a href="2025/article20251106VN.html">2025-11-06: Flood Due to Typhoon KALMAEGI in Vietnam on 06 November, 2025</a></li>
			<li><a href="2025/article20251104PH.html">2025-11-04: Flood Due to Typhoon KALMAEGI in Philippines on 04 November, 2025</a></li>
			<li><a href="2025/article20251026VN.html">2025-10-26: Flood in Central Vietnam on 26 October, 2025</a></li>
			<li><a href="2025/article20251025TJ.html">2025-10-25: Convergence of Glacier in Safedob, Tajikobat district, Tajikistan on 25 October, 2025</a></li>
			<li><a href="2025/article20251010PH.html">2025-10-10: Earthquake in coast of southeast Mindanao, Philippines on 10 October, 2025</a></li>
			<li><a href="2025/article20251007VN.html">2025-10-07: Flood in Thai Nguyen Province, Vietnam on 07 October, 2025</a></li>
			<li><a href="2025/article20251004NP.html">2025-10-04: Heavy Rains Flood in Nepal on 04 October, 2025</a></li>
			<li><a href="2025/article20251001PH.html">2025-10-01: Earthquake in Northern Cebu, Philippines on 01 October, 2025</a></li>
			<li><a href="2025/article20250929VN.html">2025-09-29: Flood Due to Typhoon BUALOI in Vietnam on 29 September, 2025</a></li>
			<li><a href="2025/article20250925PH.html">2025-09-25: Flood Due to Cyclone BUALOI in Philippines on 25 September, 2025</a></li>
			<li><a href="2025/article20250926VN.html">2025-09-26: Flood Due to Typhoon RAGASA concerns in Vietnam on 26 September, 2025</a></li>
			<li><a href="2025/article20250920PH.html">2025-09-20: Flood Due to Tropical Storm RAGASA in Philippines on 20 September, 2025</a></li>
			<li><a href="2025/article20250917PH.html">2025-09-17: Flood Due to Tropical Depression concerns in Philippines on 17 September, 2025</a></li>
			<li><a href="2025/article20250831NP.html">2025-08-31: Flood in Kanchanpur district, Nepal on 31 August, 2025</a></li>
			<li><a href="2025/article20250830KZ.html">2025-08-30: Forest Fire in Almaty Region, Kazakhstan on 30 August, 2025</a></li>
			<li><a href="2025/article20250825VN.html">2025-08-25: Flood by Typhoon KAJIKI in Vietnam on 25 August, 2025</a></li>
			<li><a href="2025/article20250817KG.html">2025-08-17: Forest Fire in Kyrgyzstan on 17 August, 2025</a></li>
			<li><a href="2025/article20250813NP.html">2025-08-13: Flood in Western Nepal on 13 August, 2025</a></li>
			<li><a href="2025/article20250811TM.html">2025-08-11: Mudflow in Nokhur Village, Turkmenistan on 11 August, 2025</a></li>
			<li><a href="2025/article20250801VN.html">2025-08-01: Flood in Dien Bien and Son La, Vietnam on 01 August, 2025</a></li>
			<li><a href="2025/article20250725LA.html">2025-07-25: Heavy Rains Flood in Lao PDR(Laos) on 25 July, 2025</a></li>
			<li><a href="2025/article20250728TW.html">2025-07-28: Heavy Rains Flood in Taiwan on 28 July, 2025</a></li>
			<li><a href="2025/article20250723UZ.html">2025-07-23: Forest Fire in Uzbekistan on 23 July, 2025</a></li>
			<li><a href="2025/article20250725KZ.html">2025-07-25: Forest Fire in Kazakhstan on 25 July, 2025</a></li>
			<li><a href="2025/article20250724KG.html">2025-07-24: Slope Collapse on the Highway in Kyrgyzstan on 24 July, 2025</a></li>
			<li><a href="2025/article20250717TH.html">2025-07-17: Flood due to TC WIPHA in Northern Thailand on 17 July, 2025</a></li>
			<li><a href="2025/article20250721LA.html">2025-07-21: Flood by Tropical Cyclone WIPHA in Lao PDR(Laos) on 21 July, 2025</a></li>
			<li><a href="2025/article20250721VN.html">2025-07-21: Flood by Typhoon WIPHA in Vietnam on 21 July, 2025</a></li>
			<li><a href="2025/article20250716PH.html">2025-07-16: Flood by Southwest Monsoon and TC WIPHA in Philippines on 16 July, 2025</a></li>
			<li><a href="2025/article20250630NP.html">2025-06-30: Flood in Western Nepal on 30 June, 2025</a></li>
			<li><a href="2025/article20250627KG.html">2025-06-27: GLOF at Lake Takyr-Tor in Kyrgyzstan on 27 June, 2025</a></li>
			<li><a href="2025/article20250621VN.html">2025-06-21: Flood and Landslide in Central Vietnam on 21 June, 2025</a></li>
			<li><a href="2025/article20250617ID.html">2025-06-17: Lewotobi Laki-laki Volcano Eruption in Indonesia on 17 June, 2025</a></li>
			<li><a href="2025/article20250612VN.html">2025-06-12: Flood Due to Storm Wutip in Vietnam on 12 June, 2025</a></li>
			<li><a href="2025/article20250608VN.html">2025-06-08: Flood and Landslide in Lai Chau, Vietnam on 08 June, 2025</a></li>
			<li><a href="2025/article20250525IN.html">2025-05-25: Oil and Chemical spill in India on 25 May, 2025</a></li>
			<li><a href="2025/article20250525VN.html">2025-05-25: Flood and Landslide in Central Vietnam on 25 May, 2025</a></li>
			<li><a href="2025/article20250518VN.html">2025-05-18: Flood and Landslide in Northern Vietnam on 18 May, 2025</a></li>
			<li><a href="2025/article20250515NP.html">2025-05-15: GLOF in Humla, Nepal on 15 May, 2025</a></li>
			<li><a href="2025/article20250413TJ.html">2025-04-13: Earthquake in Central Tajikistan on 13 April, 2025</a></li>
			<li><a href="2025/article20250328TH.html">2025-03-28: Earthquake damage across Thailand on 28 March, 2025</a></li>
			<li><a href="2025/article20250328MM.html">2025-03-28: Earthquake in Mandalay, Myanmar on 28 March, 2025</a></li>
			<li><a href="2025/article20250223FJ.html">2025-02-23: Heavy Rains by Tropical Cyclone in Fiji on 23 February, 2025</a></li>
			<li><a href="2025/article20250209PH.html">2025-02-09: Flood in Palawan, Philippines on 9 February, 2025</a></li>
			<li><a href="2025/article20250107CN.html">2025-01-07: Earthquake in Xizang, Southwest China on 7 January, 2025</a></li>
					 
				</ul>
	      </span>
<br>
<br>
			<a name="2024" id="2024"></a>
			 <input id="acd-check2024" class="acd-check" type="checkbox">
  <label class="acd-label" for="acd-check2024">2024</label>
  <span class="acd-content">
				<ul class="defaultlist note">
					 
			<li><a href="2024/article20241217VU.html">2024-12-17: Earthquake in Vanuatu on 17 December, 2024</a></li>
			<li><a href="2024/article20241209PH.html">2024-12-09: Eruption Occurred Kanlaon Volcano in Philippines on 09 December, 2024</a></li>
			<li><a href="2024/article20241203ID.html">2024-12-03: Flood and Landslide in West Java, Indonesia on 03 December, 2024</a></li>
			<li><a href="2024/article20241126TH.html">2024-11-26: Flood by Northeast Monsoon in Southern Thailand on 26 November, 2024</a></li>
			<li><a href="2024/article20241116PH.html">2024-11-16: Flood by Typhoon Man-yi in Philippines on 16 November, 2024</a></li>
			<li><a href="2024/article20241111PH.html">2024-11-11: Flood and Landslide in Philippines on 11 November, 2024</a></li>
			<li><a href="2024/article20241103ID.html">2024-11-03: Lewotobi Laki-laki Volcano Eruption in Indonesia on 03 November, 2024</a></li>
			<li><a href="2024/article20241024PH.html">2024-10-24: Flood and Landslide in Philippines on 24 October, 2024</a></li>
			<li><a href="2024/article20241025IN.html">2024-10-25: Cyclone Dana in India on 25 October, 2024</a></li>
			<li><a href="2024/article20241027VN.html">2024-10-27: Flood by Tropical Storm Trami in Vietnam on 27 October, 2024</a></li>
			<li><a href="2024/article20241023PH.html">2024-10-23: Flood by Tropical Storm Trami in Philippines on 23 October, 2024</a></li>
			<li><a href="2024/article20240929PH.html">2024-09-29: Flood by Typhoon Krathon in Philippines on 29 September, 2024</a></li>
			<li><a href="2024/article20240928NP.html">2024-09-28: Widespread Floods in Nepal on 28 September, 2024</a></li>
			<li><a href="2024/article20240919VN.html">2024-09-19: Tropical Storm Floods in Central Vietnam on 19 September, 2024</a></li>
			<li><a href="2024/article20240912LA.html">2024-09-12: Flood in Lao PDR (Laos) on 12 September, 2024</a></li>
			<li><a href="2024/article20240911MM.html">2024-09-11: Flood in Naypyidaw, Myanmar on 11 September, 2024</a></li>
			<li><a href="2024/article20240910TH.html">2024-09-10: Flood in Northern Thailand, Thailand on 10 September, 2024</a></li>
			<li><a href="2024/article20240908VN.html">2024-09-08: Tropical Storm Floods in Vietnam on 08 September, 2024</a></li>
			<li><a href="2024/article20240901PH.html">2024-09-01: Tropical Storm Floods in Philippines on 01 September, 2024</a></li>
			<li><a href="2024/article20240827IN.html">2024-08-27: Flood in Gujarat State, India on 27 August, 2024</a></li>
			<li><a href="2024/article20240824VN.html">2024-08-24: Flood and Landslide in Cao Bang City, Vietnam on 24 August, 2024</a></li>
			<li><a href="2024/article20240823NP.html">2024-08-23: Avalanche blocks Boksi River in Mustang, Nepal on 23 August, 2024</a></li>
			<li><a href="2024/article20240823VN.html">2024-08-23: Flood and Landslide in Thai Nguyen City, Vietnam on 23 August, 2024</a></li>
			<li><a href="2024/article20240821BD.html">2024-08-21: Flood in Bangladesh on 21 August, 2024</a></li>
			<li><a href="2024/article20240818KG.html">2024-08-18: Mudflows flood in Issyk-Kul district, Kyrgyzstan on 18 August, 2024</a></li>
			<li><a href="2024/article20240816NP.html">2024-08-16: GLOF in Solukhumbu, Nepal on 16 August, 2024</a></li>
			<li><a href="2024/article20240810BT.html">2024-08-10: Flood and Landslide in Bhutan on 10 August, 2024</a></li>
			<li><a href="2024/article20240806TJ.html">2024-08-06: Flood and Landslide in Tajikistan on 06 August, 2024</a></li>
			<li><a href="2024/article20240730NP.html">2024-07-30: Flood in Kathmandu, Nepal on 30 July, 2024</a></li>
			<li><a href="2024/article20240725TW.html">2024-07-25: Flood by Typhoon Gaemi in Taiwan on 25 July, 2024</a></li>
			<li><a href="2024/article20240725PH.html">2024-07-25: Oil Spill in Philippines on 25 July, 2024</a></li>
			<li><a href="2024/article20240723KG.html">2024-07-23: Mudflow in Arstanbap, Kyrgyzstan on 23 July, 2024</a></li>
			<li><a href="2024/article20240723PH.html">2024-07-23: Flood by Typhoon Gaemi in Philippines on 23 July, 2024</a></li>
			<li><a href="2024/article20240723VN.html">2024-07-23: Flood and Landslide in Son La City, Vietnam on 23 July, 2024</a></li>
			<li><a href="2024/article20240718PH.html">2024-07-18: Flood and Landslide in Philippines on 18 July, 2024</a></li>
			<li><a href="2024/article20240714KG.html">2024-07-14: Flood and Mudflow in Kyrgyzstan on 14 July, 2024</a></li>
			<li><a href="2024/article20240714UZ.html">2024-07-14: Flood and Mudflow in Uzbekistan on 14 July, 2024</a></li>
			<li><a href="2024/article20240713TJ.html">2024-07-13: Flood and Mudflow in Tajikistan on 13 July, 2024</a></li>
			<li><a href="2024/article20240715PH.html">2024-07-15: Flood in Mindanao Island, Philippines on 15 July, 2024</a></li>
			<li><a href="2024/article20240714VN.html">2024-07-14: Flood and Landslide in Vietnam on 14 July, 2024</a></li>
			<li><a href="2024/article20240710IN.html">2024-07-10: Flood in Uttar Pradesh of India on 10 July, 2024</a></li>
			<li><a href="2024/article20240707NP.html">2024-07-07: Flood in Western Region, Nepal on 07 July, 2024</a></li>
			<li><a href="2024/article20240706NP.html">2024-07-06: Flood in Gandaki Province, Nepal on 06 July, 2024</a></li>
			<li><a href="2024/article20240703VN.html">2024-07-03: Flood and Landslide in Northern Vietnam on 03 July, 2024</a></li>
			<li><a href="2024/article20240701MM.html">2024-07-01: Flood in Kachin state, Myanmar on 01 July, 2024</a></li>
			<li><a href="2024/article20240628KG.html">2024-06-28: Flood and Mudflow in Nookat district, Kyrgyzstan on 28 June, 2024</a></li>
			<li><a href="2024/article20240626NP.html">2024-06-26: Flood in Nepal on 26 June, 2024</a></li>
			<li><a href="2024/article20240624KG.html">2024-06-24: Mudflow and Mudslide in Kyrgyzstan on 24 June, 2024</a></li>
			<li><a href="2024/article20240609VN.html">2024-06-09: Flood and Landslide in Vietnam on 09 June, 2024</a></li>
			<li><a href="2024/article20240601BD.html">2024-06-01: Flood in Bangladesh on 01 June, 2024</a></li>
			<li><a href="2024/article20240527IN.html">2024-05-27: Heavy Rains by Cyclone in India on 27 May, 2024</a></li>
			<li><a href="2024/article20240516TM.html">2024-05-16: Flood in Turkmenistan on 16 May, 2024</a></li>
			<li><a href="2024/article20240511ID.html">2024-05-11: Flash Flood in West Sumatra, Indonesia on 11 May, 2024</a></li>
			<li><a href="2024/article20240502ID.html">2024-05-02: Flood and Landslide in Indonesia on 02 May, 2024</a></li>
			<li><a href="2024/article20240502AE.html">2024-05-02: Storm flooding in United Arab Emirates (UAE) on May 2, 2024</a></li>
			<li><a href="2024/article20240420KG.html">2024-04-20: Raining, Mudflow and Mudslide in Kyrgyzstan on 20 April, 2024</a></li>
			<li><a href="2024/article20240421NP.html">2024-04-21: GLOF at Birendra Lake in Nepal on 21 April, 2024</a></li>
			<li><a href="2024/article20240414PK.html">2024-04-14: Flood in Pakistan on 14 April, 2024</a></li>
			<li><a href="2024/article20240416ID.html">2024-04-16: Volcano eruption in Indonesia on 16 April, 2024</a></li>
			<li><a href="2024/article20240403TW.html">2024-04-03: Earthquake in Taiwan on 03 April, 2024</a></li>
			<li><a href="2024/article20240330KZ.html">2024-03-30: Flood in Kazakhstan on 30 March, 2024</a></li>
			<li><a href="2024/article20240315ID.html">2024-03-15: Flood in Central Java Island, Indonesia on 15 March, 2024</a></li>
			<li><a href="2024/article20240122CN.html">2024-01-22: Earthquake in western Xinjiang, China on 22 January, 2024</a></li>
			<li><a href="2024/article20240101JP.html">2024-01-01: Earthquake in Japan on 01 January, 2024</a></li>
					 
				</ul>
	      </span>
<br>
<br>
			<a name="2023" id="2023"></a>
			 <input id="acd-check2023" class="acd-check" type="checkbox">
  <label class="acd-label" for="acd-check2023">2023</label>
  <span class="acd-content">
				<ul class="defaultlist note">
					 
			<li><a href="2023/article20231218CN.html">2023-12-18: Earthquake in China on 18 December, 2023</a></li>
			<li><a href="2023/article20231203ID.html">2023-12-03: Volcano eruption in Indonesia on 03 December, 2023</a></li>
			<li><a href="2023/article20231117PH.html">2023-11-17: Earthquake in Southern Mindanao, Philippines on 17 November, 2023</a></li>
			<li><a href="2023/article20231117BD.html">2023-11-17: Cyclone Midhili in Bangladesh on 17 November, 2023</a></li>
            <li><a href="2023/article20231115VN.html">2023-11-15: Flood in Thua Thien Hue province, Vietnam on 15 November, 2023</a></li>
			<li><a href="2023/article20231103NP.html">2023-11-03: Earthquake in Nepal on 03 November, 2023</a></li>
			<li><a href="2023/article20231030VN.html">2023-10-30: Heavy Rains Flood in Ha Tinh province, Vietnam on 30 October, 2023</a></li>
			<li><a href="2023/article20231013VN.html">2023-10-13: Heavy Rains Flood in Central Vietnam on 13 October, 2023</a></li>
			<li><a href="2023/article20231007AF.html">2023-10-07: Earthquake in Afghanistan on 07 October, 2023</a></li>
			<li><a href="2023/article20230926VN.html">2023-09-26: Heavy Rains Flood in Central Vietnam on 26 September, 2023</a></li>
			<li><a href="2023/article20230912VN.html">2023-09-12: Flood, Landslide and Storm in Vietnam on 12 September, 2023</a></li>
			<li><a href="2023/article20230827TJ.html">2023-08-27: Landslide in Tajikistan on 27 August, 2023</a></li>
			<li><a href="2023/article20230816VN.html">2023-08-16: Landslide in Vietnam on 16 August, 2023</a></li>
			<li><a href="2023/article20230805VN.html">2023-08-05: Flood, Landslide and Storm in Vietnam on 05 August, 2023</a></li>		 
			<li><a href="2023/article20230725PH.html">2023-07-25: Typhoon Doksuri in Philippines on 25 July, 2023</a></li>
			<li><a href="2023/article20230720BT.html">2023-07-20: Flood in Bhutan on 20 July, 2023</a></li>
			<li><a href="2023/article20230718VN.html">2023-07-18: Flood, Landslide and Storm in Vietnam on 18 July, 2023</a></li>
			<li><a href="2023/article20230713IN.html">2023-07-13: Flood, Landslide and Storm in India on 13 July, 2023</a></li>
			<li><a href="2023/article20230608KZ.html">2023-06-08: Forest Fire in Kazakhstan on 08 June, 2023</a></li>
			<li><a href="2023/article20230615IN.html">2023-06-15: Cyclone Biparjoy in India on 15 June, 2023</a></li>
			<li><a href="2023/article20230527PH.html">2023-05-27: Typhoon Mawar in Philippines on 27 May, 2023</a></li>
			<li><a href="2023/article20230514BD.html">2023-05-14: Cyclone MOCHA in Bangladesh on 14 May, 2023</a></li>
			<li><a href="2023/article20230514MM.html">2023-05-14: Cyclone MOCHA in Myanmar on 14 May, 2023</a></li>
			<li><a href="2023/article20230306ID.html">2023-03-06: Landslide in Indonesia on 06 March, 2023</a></li>
			<li><a href="2023/article20230228PH.html">2023-02-28: Oil spill in Philippines on 28 February, 2023</a></li>
			<li><a href="2023/article20230216PH.html">2023-02-16: Earthquake in Philippines on 16 February, 2023</a></li>
			<li><a href="2023/article20230206TR.html">2023-02-06: Earthquake in Turkey on 06 February, 2023</a></li>
					 
				</ul>
	      </span>
<br>
<br>
			<a name="2022" id="2022"></a>
			 <input id="acd-check2022" class="acd-check" type="checkbox">
  <label class="acd-label" for="acd-check2022">2022</label>
  <span class="acd-content">
				<ul class="defaultlist note">
					 
			<li><a href="2022/article20221227PH.html">2022-12-27: Flood and Landslide in Philippines on 27 December, 2022</a></li>
			<li><a href="2022/article20221204ID.html">2022-12-04: Volcano eruption in Indonesia on 04 December, 2022</a></li>
			<li><a href="2022/article20221121ID.html">2022-11-21: Earthquake in Indonesia on 21 November, 2022</a></li>
			<li><a href="2022/article20221029PH.html">2022-10-29: Storm, Flood and Landslide in Philippines on 29 October, 2022</a></li>
			<li><a href="2022/article20221019TH.html">2022-10-19: Flood in Thailand on 19 October, 2022</a></li>
			<li><a href="2022/article20221013IN.html">2022-10-13: Flood in India on 13 October, 2022</a></li>
			<li><a href="2022/article20221002NP.html">2022-10-02: Manaslu avalanche in Nepal on 2 October, 2022</a></li>
			<li><a href="2022/article20220928VN.html">2022-09-28: Storm, Flood and Landslide in Vietnam on 28 September, 2022</a></li>
			<li><a href="2022/article20220925PH.html">2022-09-25: Storm, Flood and Landslide in Philippines on 25 September, 2022</a></li>
			<li><a href="2022/article20220917TW.html">2022-09-17: Earthquake in Taiwan on 17 September, 2022</a></li>
			<li><a href="2022/article20220905CN.html">2022-09-05: Earthquake in China on 5 September, 2022</a></li>
			<li><a href="2022/article20220823IN.html">2022-08-23: Flood in India on 23 August, 2022</a></li>
			<li><a href="2022/article20220823PH.html">2022-08-23: Storm, Flood and Landslide in Philippines on 23 August, 2022</a></li>
			<li><a href="2022/article20220817PK.html">2022-08-17: Flood in Pakistan on 17 August, 2022</a></li>
			<li><a href="2022/article20220727PH.html">2022-07-27: Earthquake in Philippines on 27 July, 2022</a></li>
			<li><a href="2022/article20220713IN.html">2022-07-12: Flood in Gujarat, India on 12 July, 2022</a></li>
			<li><a href="2022/article20220712IN.html">2022-07-12: Flood in Andhra Pradesh, India on 12 July, 2022</a></li>
			<li><a href="2022/article20220707VN.html">2022-07-07: Flood, Landslide and Storm in Vietnam on 7 July, 2022</a></li>
			<li><a href="2022/article20220622AF.html">2022-06-22: Earthquake in Afghanistan on 22 June, 2022</a></li>
			<li><a href="2022/article20220618BD.html">2022-06-18: Flood in Bangladesh on 18 June, 2022</a></li>
			<li><a href="2022/article20220615IN.html">2022-06-15: Flood in India on 15 June, 2022</a></li>
			<li><a href="2022/article20220605PH.html">2022-06-05: Volcano eruption in Philippines on 5 June, 2022</a></li>
			<li><a href="2022/article20220523ID.html">2022-05-23: Coastal Flood in Indonesia on 23 May, 2022</a></li>
			<li><a href="2022/article20220515IN.html">2022-05-15: Flood in India on 15 May, 2022</a></li>
			<li><a href="2022/article20220412PH.html">2022-04-12: Flood and Landslide in Philippines on 12 April, 2022</a></li>
			<li><a href="2022/article20220224TH.html">2022-02-24: Flood in Thailand on 24 February, 2022</a></li>
			<li><a href="2022/article20220210TH.html">2022-02-10: Oil spill in Thailand on 10 February, 2022</a></li>
			<li><a href="2022/article20220115TO.html">2022-01-15: Volcano eruption in Tonga on 15 January, 2022</a></li>
					 
				</ul>
	      </span>
<br>
<br>
			<a name="2021" id="2021"></a>
			 <input id="acd-check2021" class="acd-check" type="checkbox">
  <label class="acd-label" for="acd-check2021">2021</label>
  <span class="acd-content">
				<ul class="defaultlist note">
					 
			<li><a href="2021/article20211214PH.html">2021-12-14: Tropical Storm Odette in Philippines on 14 December, 2021</a></li>
			<li><a href="2021/article20211204ID.html">2021-12-04: Volcano eruption in Indonesia on 04 December, 2021</a></li>
			<li><a href="2021/article20211123PH.html">2021-11-23: Volcanic eruption influence in Philippines on 23 November, 2021</a></li>
			<li><a href="2021/article20211105LK.html">2021-11-05: Flood and Landslide in Sri Lanka on 5 November, 2021</a></li>
			<li><a href="2021/article20211107IN.html">2021-11-07: Flood in India on 7 November, 2021</a></li>
			<li><a href="2021/article20211022VN.html">2021-10-22: Flood and Landslide in Vietnam on 22 October, 2021</a></li>
			<li><a href="2021/article20211020JP.html">2021-10-20: Volcano eruption in Japan on 20 October, 2021</a></li>
			<li><a href="2021/article20211016IN.html">2021-10-16: Flood, Landslide and Storm in India on 16 October, 2021</a></li>
			<li><a href="2021/article20211012PH.html">2021-10-12: Flood and Landslide in Philippines on 12 October, 2021</a></li>
			<li><a href="2021/article20211014VN.html">2021-10-14: Typhoon KOMPASU in Vietnam on 14 October, 2021</a></li>
			<li><a href="2021/article20211006VN.html">2021-10-06: Flood, Landslide and Storm in Vietnam on 6 October, 2021</a></li>
			<li><a href="2021/article20211001TH.html">2021-10-01: Tropical Storm Dianmu Flood in Thailand on 1 October, 2021</a></li>
			<li><a href="2021/article20210913VN.html">2021-09-13: Typhoon Conson in Vietnam on 13 September, 2021</a></li>
			<li><a href="2021/article20210908PH.html">2021-09-08: Tropical Storm Jolina in Philippines on 8 September, 2021</a></li>
			<li><a href="2021/article20210814JP.html">2021-08-14: Flood and Landslide in Japan on 14 August, 2021</a></li>
			<li><a href="2021/article20210811TR.html">2021-08-11: Flood and Landslide in Turkey on 11 August, 2021</a></li>
			<li><a href="2021/article20210727MM.html">2021-07-27: Flood in Myanmar on 27 July, 2021</a></li>
			<li><a href="2021/article20210725PH.html">2021-07-25: Typhoon Fabian in Philippines on 25 July, 2021</a></li>
			<li><a href="2021/article20210720KG.html">2021-07-20: Flood and Mudflow in Kyrgyzstan on 20 July, 2021</a></li>
			<li><a href="2021/article20210713UZ.html">2021-07-13: Flood in Uzbekistan on 13 July, 2021</a></li>
			<li><a href="2021/article20210712KG.html">2021-07-12: Flood in Kyrgyzstan on 12 July, 2021</a></li>
			<li><a href="2021/article20210707TJ.html">2021-07-07: Earthquake in Tajikistan on 7 July, 2021</a></li>
			<li><a href="2021/article20210615NP.html">2021-06-15: Flood, Landslide in Nepal on 15 June, 2021</a></li>
			<li><a href="2021/article20210603LK.html">2021-06-03: Flood in Sri Lanka on 3 June, 2021</a></li>
			<li><a href="2021/article20210525LK.html">2021-05-25: Oil spill emergency in Sri Lanka on 25 May, 2021</a></li>
			<li><a href="2021/article20210602PH.html">2021-06-02: Typhoon Choi-wan (Dante) in Philippines on 2 June, 2021</a></li>
			<li><a href="2021/article20210526IN.html">2021-05-26: Cyclone YAAS in India on 26 May, 2021</a></li>
			<li><a href="2021/article20210517IN.html">2021-05-17: Flood, Storm in India on 17 May, 2021</a></li>
			<li><a href="2021/article20210511TJ.html">2021-05-11: Landslide, Mudflows in Tajikistan on 11 May, 2021</a></li>
			<li><a href="2021/article20210404TL.html">2021-04-04: Flood, Landslide in Timor-Leste on 4 April, 2021</a></li>
			<li><a href="2021/article20210404ID.html">2021-04-04: Flood, Landslide in Indonesia on 4 April, 2021</a></li>
			<li><a href="2021/article20210221PH.html">2021-02-21: Flood, Landslide and Storm in the Philippines on 21 February, 2021</a></li>
			<li><a href="2021/article20210115ID.html">2021-01-15: Earthquake in Indonesia on 15 January, 2021</a></li>
			
				</ul>
	      </span>

<br>
<br>
			
			<a name="2020" id="2020"></a>
			 <input id="acd-check2020" class="acd-check" type="checkbox">
  <label class="acd-label" for="acd-check2020">2020</label>
  <span class="acd-content">
			     <ul class="defaultlist note">
					 
			<li><a href="2020/article20201202LK.html">2020-12-02: Storm BUREVI in Sri Lanka on 2 December, 2020</a></li>		 
			<li><a href="2020/article20201125IN.html">2020-11-25: Storm NIVAR in India on 25 November, 2020</a></li>		 
			<li><a href="2020/article20201115VN.html">2020-11-15: Flood and Landslides in Vietnam on 15 November, 2020</a></li>
			<li><a href="2020/article20201111PH.html">2020-11-11: Flood and Storm in the Philippines on 11 November, 2020</a></li>
			<li><a href="2020/article20201101PH.html">2020-11-01: Typhoon GONI in the Philippines on 01 November, 2020</a></li>
			<li><a href="2020/article20201030TR.html">2020-10-30: Earthquake in Turkey on 30 October, 2020</a></li>
			<li><a href="2020/article20201027VN.html">2020-10-27: Storm Molave in Vietnam on 29 October, 2020 </a></li>
			<li><a href="2020/article20201017KH.html">2020-10-17: Flood in Cambodia on 17 October, 2020</a></li>
			<li><a href="2020/article20201007VN.html">2020-10-07: Flood and Landslides in Vietnam on 07 October, 2020 </a></li>
			<li><a href="2020/article20200917VN.html">2020-09-17: Tropical Storm Noul in Vietnam on 18 September, 2020 </a></li>
			<li><a href="2020/article20200904JP.html">2020-09-04: Typhoon HAISHEN in Japan on 04 September, 2020</a></li>
			<li><a href="2020/article20200818PH.html">2020-08-18: Earthquake in Philippines on 18 August, 2020</a></li>
			<li><a href="2020/article20200808LB.html">2020-08-08: Explosion in Beirut, Lebanon on 08 August, 2020</a></li>
			<li><a href="2020/article20200720VN.html">2020-07-22: Flood and Landslide in Vietnam on 20 July, 2020 </a></li>
			<li><a href="2020/article20200716ID.html">2020-07-16: Flood in Indonesia on 13 July, 2020</a></li>
			<li><a href="2020/article20200713IN2.html">2020-07-13: Flood in India on 13 July, 2020</a></li>
			<li><a href="2020/article20200713IN.html">2020-07-13: Flood in India on 13 July, 2020</a></li>
			<li><a href="2020/article20200706JP.html">2020-07-06: Flood and Landslide in Japan on 06 July, 2020</a></li>
			<li><a href="2020/article20200604IN.html">2020-06-04: Storm and Flood in India on 04 June, 2020</a></li>
			<li><a href="2020/article20200518BD.html">2020-05-18: Storm and Flood in Bangladesh on 18 May, 2020</a></li>
			<li><a href="2020/article20200518IN.html">2020-05-18: Storm and Flood in India on 18 May, 2020</a></li>
			<li><a href="2020/article20200508ID.html">2020-05-08: Flood in Indonesia on 08 May, 2020</a></li>
			<li><a href="2020/article20200407VU.html">2020-04-07: Tropical Cyclone in Vanuatu on 07 April, 2020</a></li>
			<li><a href="2020/article20200225ID.html">2020-02-25: Flood in Indonesia on 25 February, 2020</a></li>
			<li><a href="2020/article20200124TR.html">2020-01-24: Earthquake in Turkey on 24 January, 2020</a></li>
			<li><a href="2020/article20200112PH.html">2020-01-12: Volcano Eruption in Philippines on 12 January, 2020</a></li>
			<li><a href="2020/article20200111IR.html">2020-01-11: Flood in Iran on 11 January, 2020</a></li>
			<li><a href="2020/article20200101ID.html">2020-01-01: Flood in Indonesia on 01 January, 2020</a></li>
	     </ul>
	      </span>

<br>
<br>



			
			<a name="2019" id="2019"></a>	
<input id="acd-check2019" class="acd-check" type="checkbox">
  <label class="acd-label" for="acd-check2019">2019</label>
  <span class="acd-content">
	  
	         <ul class="defaultlist note">
          <li><a href="2019/article20191228FJ.html">2019-12-28: Flood due to Storm in Fiji on 28 December, 2019</a></li>
          <li><a href="2019/article20191215PH.html">2019-12-15: Earthquake in Philippines on 15 December, 2019</a></li>
          <li><a href="2019/article20191203PH.html">2019-12-03: Flood and Landslide due to Typhoon in Philippines on 03 December, 2019</a></li>
          <li><a href="2019/article20191201KG.html">2019-12-01: Landslide in Kyrgyzstan on 01 December, 2019</a></li>
          <li><a href="2019/article20191111VN.html">2019-11-11: Flood in Vietnam on 11 November, 2019</a></li>
          <li><a href="2019/article20191031PH.html">2019-10-31: Earthquake in Philippines on 31 October, 2019</a></li>
          <li><a href="2019/article20191012JP.html">2019-10-12: Typhoon in Japan on 12 October, 2019</a></li>
          <li><a href="2019/article20190930IN.html">2019-09-30: Flood due to Heavy rain in India on 30 September, 2019</a></li>
          <li><a href="2019/article20190920TH.html">2019-09-20: Flood in Thailand on 20 September, 2019</a></li>
          <li><a href="2019/article20190906LA.html">2019-09-06: Flood in Lao PDR (Laos) on 06 September, 2019</a></li>
          <li><a href="2019/article20190905VN.html">2019-09-05: Heavy rain in Vietnam on 05 September, 2019</a></li>
          <li><a href="2019/article20190828JP.html">2019-08-28: Flood due to Heavy rain in Northern Kyushu, Japan on 28 August, 2019</a></li>
          <li><a href="2019/article20190808MM.html">2019-08-08: Flood in Myanmar on 08 August, 2019</a></li>
          <li><a href="2019/article20190714ID.html">2019-07-14: M7.3 Earthquake in North Maluku, Eastern Indonesia on 14 July, 2019</a></li>
          <li><a href="2019/article20190624VN.html">2019-06-24: Flash flood in Lai Chau province, Vietnam on 24 June, 2019</a></li>
          <li><a href="2019/article20190620BT.html">2019-06-20: Glacier Lake Breach Flood in Bhutan on 20 June, 2019</a></li>
          <li><a href="2019/article20190617CN.html">2019-06-17: Earthquake in Sichuan, China on 17 June, 2019</a></li>
          <li><a href="2019/article20190516TR.html">2019-05-16: Landslide in Ordu Aybasti district, Turkey on 16 May, 2019</a></li>
          <li><a href="2019/article20190502ID.html">2019-05-02: Flood due to Cyclone Fani in India on 02 May, 2019</a></li>
          <li><a href="2019/article20190423PH.html">2019-04-23: Earthquake in Samar Island, Philippines on 23 April, 2019</a></li>
          <li><a href="2019/article20190422PH.html">2019-04-22: Earthquake in Zambales, Pampanga, Philippines on 22 April, 2019</a></li>
          <li><a href="2019/article20190404KR.html">2019-04-04: Wildfire in South Korea on 04 April, 2019</a></li>
          <li><a href="2019/article20190331NP.html">2019-03-31: Storm in Nepal on 31 March, 2019</a></li>
          <li><a href="2019/article20190316ID.html">2019-03-16: Flood in Indonesia on 16 March, 2019</a></li>
          <li><a href="2019/article20190117JP.html">2019-01-17: Volcano eruption in Japan on 17 January, 2019</a></li>
	     </ul>
	  </span>

<br>
<br>
			
			<a name="2018" id="2018"></a>
<input id="acd-check2018" class="acd-check" type="checkbox">
  <label class="acd-label" for="acd-check2018">2018</label>
  <span class="acd-content">
	  
	          <ul class="defaultlist note">
          <li><a href="2018/article20181222LK.html">2018-12-22: Flood in Sri Lanka on 22 December, 2018</a></li>
          <li><a href="2018/article20181222ID.html">2018-12-22: Tsunami in Indonesia on 22 December, 2018</a></li>
          <li><a href="2018/article20181216IN.html">2018-12-16: Flood in India on 16 December, 2018</a></li>
          <li><a href="2018/article20181124VN.html">2018-11-24: Typhoon in Vietnam on 24 December, 2018</a></li>
          <li><a href="2018/article20181118VN.html">2018-11-18: Typhoon in Vietnam on 18 November, 2018</a></li>
          <li><a href="2018/article20181116IN.html">2018-11-16: Cyclone in India Tamil Nadu on 16 November, 2018</a></li>
				  
				  <!-- archive -->
				  
          <li><a href="2018/article20181012AE.html">2018-10-12: Cyclone in United Arab Emirates on 12 October, 2018</a></li>
          <li><a href="2018/article20180928ID.html">2018-09-28: Earthquake in Indonesia on 28 September, 2018</a></li>
          <li><a href="2018/article20180917VN.html">2018-09-17: Typhoon in Vietnam on 17 September, 2018</a></li>
          <li><a href="2018/article20180915PH.html">2018-09-15: Typhoon in Philippines on 15 September, 2018</a></li>
          <li><a href="2018/article20180906JP.html">2018-09-06: Earthquake in Japan on 06 September, 2018</a></li>
          <li><a href="2018/article20180829MM.html">2018-08-29: Flood in Myanmar on 29 August, 2018</a></li>
          <li><a href="2018/article20180827VN.html">2018-08-27: Flood in Vietnam on 27 August, 2018</a></li>
          <li><a href="2018/article20180825TW.html">2018-08-25: Flood in Taiwan on 25 August, 2018</a></li>
          <li><a href="2018/article20180809IN.html">2018-08-09: Flood in India on 09 August, 2018</a></li>
          <li><a href="2018/article20180806ID.html">2018-08-06: Earthquake in Indonesia on 06 August, 2018</a></li>
          <li><a href="2018/article20180730ID.html">2018-07-30: Earthquake in Indonesia on 30 July, 2018</a></li>
          <li><a href="2018/article20180729TH.html">2018-07-29: Flood in Thailand on 29 July, 2018</a></li>
          <li><a href="2018/article20180726MM.html">2018-07-26: Flood in Myanmar on 26 July, 2018</a></li>
          <li><a href="2018/article20180724LA.html">2018-07-24: Flood in Laos on 24 July, 2018</a></li>
          <li><a href="2018/article20180718VN.html">2018-07-18: Flood in Vietnam on 18 July, 2018</a></li>
          <li><a href="2018/article20180709TH.html">2018-07-09: Oil Spill in Thailand on 09 July, 2018</a></li>
          <li><a href="2018/article20180707JP.html">2018-07-07: Flood in Japan on 07 July, 2018</a></li>
          <li><a href="2018/article20180623VN.html">2018-06-23: Flood in Vietnam on 23 June, 2018</a></li>
          <li><a href="2018/article20180520LK.html">2018-05-20: Flood in Sri Lanka on 20 May, 2018</a></li>
          <li><a href="2018/article20180212TO.html">2018-02-12: Tropical cyclone in Tonga on 12 February, 2018</a></li>
          <li><a href="2018/article20180211KR.html">2018-02-11: Earthquake in Korea on 11 February, 2018</a></li>
          <li><a href="2018/article20180207TW.html">2018-02-07: Earthquake in Taiwan on 07 February, 2018</a></li>
          <li><a href="2018/article20180115PH.html">2018-01-15: Volcano eruption in Philippines on 15 January, 2018</a></li>
          <li><a href="2018/article20180105PG.html">2018-01-05: Volcano eruption in Papua New Guinea on 05 January, 2018</a></li>

        </ul></span>

<br>
<br>
			
			<a name="2017" id="2017"></a>
						
  <input id="acd-check2017" class="acd-check" type="checkbox">
  <label class="acd-label" for="acd-check2017">2017</label>
  <span class="acd-content">
	  
	          <ul class="defaultlist note">
          <li><a href="2017/article20171225VN.html">2017-12-25: Flood in Vietnam on 25 December, 2017</a></li>
          <li><a href="2017/article20171202IN.html">2017-12-02: Disaster Due to Cyclone in India on 02 December, 2017</a></li>
          <li><a href="2017/article20171121ID.html">2017-11-21: Volcano eruption in Indonesia on 21 November, 2017</a></li>
          <li><a href="2017/article20171119VN.html">2017-11-19: Flood in Vietnam on 19 November, 2017</a></li>
          <li><a href="2017/article20171115KR.html">2017-11-15: Earthquake in Korea on 15 November, 2017</a></li>
          <li><a href="2017/article20171105VN.html">2017-11-05: Flood in Vietnam on 05 November, 2017</a></li>
          <li><a href="2017/article20171102VN.html">2017-11-02: Flood in Vietnam on 02 November, 2017</a></li>
          <li><a href="2017/article20171019PH.html">2017-10-19: Flood in Philippines on 19 October, 2017</a></li>
          <li><a href="2017/article20171018VN.html">2017-10-18: Flood in Vietnam on 18 October, 2017</a></li>
          <li><a href="2017/article20171014TW.html">2017-10-14: Flood in Taiwan on 14 October, 2017</a></li>
          <li><a href="2017/article20171012VN.html">2017-10-12: Flood in Vietnam on 12 October, 2017</a></li>
          <li><a href="2017/article20171010VN.html">2017-10-10: Flood in Vietnam on 10 October, 2017</a></li>
          <li><a href="2017/article20170916VN.html">2017-09-16: Flood in Vietnam on 16 September, 2017</a></li>
          <li><a href="2017/article20170823VN.html">2017-08-23: Flood in Vietnam on 23 August, 2017</a></li>
          <li><a href="2017/article20170812NP.html">2017-08-12: Flood in Nepal on 12 August, 2017</a></li>
          <li><a href="2017/article20170810BD.html">2017-08-10: Flood in Bangladesh on 10 August, 2017</a></li>
          <li><a href="2017/article20170808CN.html">2017-08-08: Earthquake in China on 08 August, 2017</a></li>
          <li><a href="2017/article20170803VN.html">2017-08-03: Flood in Vietnam on 03 August, 2017</a></li>
          <li><a href="2017/article20170730TW.html">2017-07-30: Typhoon in Taiwan on 30 July, 2017</a></li>
          <li><a href="2017/article20170726VN.html">2017-07-26: Flood in Vietnam on 26 July, 2017</a></li>
          <li><a href="2017/article20170718VN.html">2017-07-18: Typhoon in Vietnam on 18 July, 2017</a></li>
          <li><a href="2017/article20170707PH.html">2017-07-07: Earthquake in Philippines on 07 July, 2017</a></li>
          <li><a href="2017/article20170624CN.html">2017-06-24: Landslide in China on 24 June, 2017</a></li>
          <li><a href="2017/article20170613BD.html">2017-06-13: Landslide in Bangladesh on 13 June, 2017</a></li>
          <li><a href="2017/article20170602TW.html">2017-06-02: Flash flood in Taiwan on 02 June, 2017</a></li>
          <li><a href="2017/article20170524LK.html">2017-05-24: Flood in Sri Lanka on 24 May, 2017</a></li>
          <li><a href="2017/article20170420NP.html">2017-04-20: Flash flood in Nepal on 20 April, 2017</a></li>
          <li><a href="2017/article20170214ID.html">2017-02-14: Flood in Indonesia on 14 February, 2017</a></li>
          <li><a href="2017/article20170211PH.html">2017-02-11: Earthquake in Philippines on 11 February, 2017</a></li>
          <li><a href="2017/article20170209ID.html">2017-02-09: Landslide in Indonesia on 09 February, 2017</a></li>
          <li><a href="2017/article20170116PH.html">2017-01-16: Flood in Philippines on 16 January, 2017</a></li>
          <li><a href="2017/article20170106TH.html">2017-01-06: Flood in Thailand on 06 January, 2017</a></li>

			
				          </ul></span>

<br>
<br>
			
			<a name="2016" id="2016"></a>		
<input id="acd-check2016" class="acd-check" type="checkbox">
  <label class="acd-label" for="acd-check2016">2016</label>
  <span class="acd-content">
	  
	          <ul class="defaultlist note">
		  <li><a href="2016/article20161225PH.html">2016-12-25: Disaster Due to Typhoon in Philippines on 25 December, 2016</a></li>
          <li><a href="2016/article20161218NP.html">2016-12-18: Flash flood in Nepal on 18 December, 2016</a></li>
          <li><a href="2016/article20161212IN.html">2016-12-12: Tropical cyclone in India on 12 December, 2016</a></li>
          <li><a href="2016/article20161207ID.html">2016-12-07: Earthquake in Indonesia on 07 December, 2016</a></li>
          <li><a href="2016/article20161028VN.html">2016-10-28: Flood in Vietnam on 28 October, 2016</a></li>
          <li><a href="2016/article20161020PH.html">2016-10-20: Typhoon in Philippines on 20 October, 2016</a></li>
          <li><a href="2016/article20161014VN.html">2016-10-14: Flood in Vietnam on 14 October, 2016</a></li>
          <li><a href="2016/article20160928TW.html">2016-09-28: Typhoon in Taiwan on 28 September, 2016</a></li>
          <li><a href="2016/article20160920_1ID.html">2016-09-20: Flash flood in Indonesia on 20 September, 2016</a></li>
          <li><a href="2016/article20160920_2ID.html">2016-09-20: Landslide in Indonesia on 20 September, 2016</a></li>
          <li><a href="2016/article20160915TW.html">2016-09-15: Typhoon in Taiwan on 15 September, 2016</a></li>
          <li><a href="2016/article20160914PH.html">2016-09-14: Cyclone in Philippines on 14 September, 2016</a></li>
          <li><a href="2016/article20160825IN.html">2016-08-25: Flood in India on 25 August, 2016</a></li>
          <li><a href="2016/article20160824_1LA.html">2016-08-24: Flash flood in Laos on 24 August, 2016</a></li>
          <li><a href="2016/article20160824_2MM.html">2016-08-24: Earthquake in Myanmar on 24 August, 2016</a></li>
          <li><a href="2016/article20160803MM.html">2016-08-03: Flood in Myanmar on 03 August, 2016</a></li>
          <li><a href="2016/article20160731BD.html">2016-07-31: Flood in Bangladesh on 31 July, 2016</a></li>
          <li><a href="2016/article20160730BT.html">2016-07-30: Flood in Bhutan on 30 July, 2016</a></li>
          <li><a href="2016/article20160708TW.html">2016-07-08: Typhoon in Taiwan on 08 July, 2016</a></li>
          <li><a href="2016/article20160706NP.html">2016-07-06: Flood in Nepal on 06 July, 2016</a></li>
          <li><a href="2016/article20160619ID.html">2016-06-19: Landslide in Indonesia on 19 June, 2016</a></li>
          <li><a href="2016/article20160522BD.html">2016-05-22: Tropical cyclone in Bangladesh on 22 May, 2016</a></li>
          <li><a href="2016/article20160521ID.html">2016-05-21: Volcano eruption in Indonesia on 21 May, 2016</a></li>
          <li><a href="2016/article20160515LK.html">2016-05-15: Flood in Sri Lanka on 15 May, 2016</a></li>
          <li><a href="2016/article20160416JP.html">2016-04-16: Earthquake in Japan on 16 April, 2016</a></li>
          <li><a href="2016/article20160412PK.html">2016-04-12: Landslide in Pakistan on 12 April, 2016</a></li>
          <li><a href="2016/article20160404PK.html">2016-04-04: Landslide in Pakistan on 04 April, 2016</a></li>
          <li><a href="2016/article20160326PH.html">2016-03-26: Forest fire in Philippines on 26 March, 2016</a></li>
          <li><a href="2016/article20160312TW.html">2016-03-12: Oil Spill in Taiwan on 12 March, 2016</a></li>
          <li><a href="2016/article20160308ID.html">2016-03-08: Flood in Indonesia on 08 March, 2016</a></li>
          <li><a href="2016/article20160227ID.html">2016-02-27: Flood in Indonesia on 27 February, 2016</a></li>
          <li><a href="2016/article20160222MM.html">2016-02-22: Flood in Myanmar on 22 February, 2016</a></li>
          <li><a href="2016/article20160220FJ.html">2016-02-20: Tropical cyclone in Fiji on 20 February, 2016</a></li>
          <li><a href="2016/article20160206TW.html">2016-02-06: Earthquake in Taiwan on 06 February, 2016</a></li>			
				          </ul></span>
			
<br>
<br>
			
			<a name="2015" id="2015"></a>

<input id="acd-check2015" class="acd-check" type="checkbox">
  <label class="acd-label" for="acd-check2015">2015</label>
  <span class="acd-content">
	  
	          <ul class="defaultlist note">
			
          <li><a href="2015/article20151214PH.html">2015-12-14: Typhoon in Philippines on 14 December, 2015</a></li>
          <li><a href="2015/article20151201IN.html">2015-12-01: Flood in India on 01 December, 2015</a></li>
          <li><a href="2015/article20151026PK.html">2015-10-26: Earthquake in Pakistan on 26 October, 2015</a></li>
          <li><a href="2015/article20151018PH.html">2015-10-18: Typhoon in Philippines on 18 October, 2015</a></li>
          <li><a href="2015/article20150930LK.html">2015-09-30: Flood in Sri Lanka on 30 September, 2015</a></li>
          <li><a href="2015/article20150928TW.html">2015-09-28: Typhoon in Taiwan on 28 September, 2015</a></li>
          <li><a href="2015/article20150909JP.html">2015-09-09: Typhoon in Japan on 09 September, 2015</a></li>
          <li><a href="2015/article20150904BD.html">2015-09-04: Flood in Bangladesh on 04 September, 2015</a></li>
          <li><a href="2015/article20150807TW.html">2015-08-07: Typhoon in Taiwan on 07 August, 2015</a></li>
          <li><a href="2015/article20150806MM.html">2015-08-06: Landslide in Myanmar on 06 August, 2015</a></li>
          <li><a href="2015/article20150728_1PK.html">2015-07-28: Flood in Pakistan on 28 July, 2015</a></li>
          <li><a href="2015/article20150728_2VN.html">2015-07-28: Flood in Vietnam on 28 July, 2015</a></li>
          <li><a href="2015/article20150720TJ.html">2015-07-20: Landslide in Tajikistan on 20 July, 2015</a></li>
          <li><a href="2015/article20150716MM.html">2015-07-16: Flood in Myanmar on 16 July, 2015</a></li>
          <li><a href="2015/article20150628BT.html">2015-06-28: Flood in Bhutan on 28 June, 2015</a></li>
          <li><a href="2015/article20150610NP.html">2015-06-10: Flood in Nepal on 10 June, 2015</a></li>
          <li><a href="2015/article20150529JP.html">2015-05-29: Volcano eruption in Japan on 29 May, 2015</a></li>
          <li><a href="2015/article20150525NP.html">2015-05-25: Landslide in Nepal on 25 May, 2015</a></li>
          <li><a href="2015/article20150512NP.html">2015-05-12: Earthquake in Nepal on 12 May, 2015</a></li>
          <li><a href="2015/article20150425NP.html">2015-04-25: Earthquake in Nepal on 25 April, 2015</a></li>
          <li><a href="2015/article20150314VN.html">2015-03-14: Tropical cyclone in Vanuatu on 14 March, 2015</a></li>
          <li><a href="2015/article20150227VN.html">2015-02-27: Oil Spill in Vietnam on 27 February, 2015</a></li>
          <li><a href="2015/article20150209ID.html">2015-02-09: Flood in Indonesia on 09 February, 2015</a></li>
          <li><a href="2015/article20150103ID.html">2015-01-03: Forest fire in Indonesia on 03 January, 2015</a></li>
		
				          </ul></span>	
<br>
<br>
			
			<a name="2014" id="2014"></a>
			
<input id="acd-check2014" class="acd-check" type="checkbox">
  <label class="acd-label" for="acd-check2014">2014</label>
  <span class="acd-content">
	  
	          <ul class="defaultlist note">
			
          <li><a href="2014/article20141221MY.html">2014-12-21: Flood in Malaysia on 21 December, 2014</a></li>
          <li><a href="2014/article20141212ID.html">2014-12-12: Landslide in Indonesia on 12 December, 2014</a></li>
          <li><a href="2014/article20141206PH.html">2014-12-06: Typhoon in Philippines on 06 December, 2014</a></li>
          <li><a href="2014/article20141029LK.html">2014-10-29: Landslide in Sri Lanka on 29 October, 2014</a></li>
          <li><a href="2014/article20141012IN.html">2014-10-12: Flood in India on 12 October, 2014</a></li>
          <li><a href="2014/article20140927JP.html">2014-09-27: Volcano eruption in Japan on 27 September, 2014</a></li>
          <li><a href="2014/article20140824IN.html">2014-08-24: Flood in India on 24 August, 2014</a></li>
          <li><a href="2014/article20140820JP.html">2014-08-20: Landslide in Japan on 20 August, 2014</a></li>
          <li><a href="2014/article20140803CN.html">2014-08-03: Earthquake in China on 03 August, 2014</a></li>
          <li><a href="2014/article20140802NP.html">2014-08-02: Landslide in Nepal on 02 August, 2014</a></li>
          <li><a href="2014/article20140414TJ.html">2014-04-14: Landslide in Tajikistan on 14 April, 2014</a></li>
          <li><a href="2014/article20140403SB.html">2014-04-03: Flood in Solomon on 03 April, 2014</a></li>
          <li><a href="2014/article20140214ID.html">2014-02-14: Volcano eruption in Indonesia on 14 February, 2014</a></li>
          <li><a href="2014/article20140131ID.html">2014-01-31: Volcano eruption in Indonesia on 31 January, 2014</a></li>
          <li><a href="2014/article20140116ID.html">2014-01-16: Flood in Indonesia on 16 January, 2014</a></li>
          <li><a href="2014/article20140113BN.html">2014-01-13: Flood in Brunei on 13 January, 2014</a></li>
          <li><a href="2014/article20140110TO.html">2014-01-10: Tropical cyclone in Tonga on 10 January, 2014</a></li>
			
  </ul></span>	

<br>
<br>
			
			<a name="2013" id="2013"></a>
			  <input id="acd-check2013" class="acd-check" type="checkbox">
  <label class="acd-label" for="acd-check2013">2013</label>
  <span class="acd-content">
	  
	          <ul class="defaultlist note">
			
          <li><a href="2013/article20131203MY.html">2013-12-03: Flood in Malaysia on 03 December, 2013</a></li>
          <li><a href="2013/article20131108PH.html">2013-11-08: Typhoon in Philippines on 08 November, 2013</a></li>
          <li><a href="2013/article20131019VN.html">2013-10-19: Flood in Vietnam on 19 October, 2013</a></li>
          <li><a href="2013/article20131016JP.html">2013-10-16: Landslide in Japan on 16 October, 2013</a></li>
          <li><a href="2013/article20131015PH.html">2013-10-15: Earthquake in Philippines on 15 October, 2013</a></li>
          <li><a href="2013/article20131014VN.html">2013-10-14: Flood in Vietnam on 14 October, 2013</a></li>
          <li><a href="2013/article20131014IN.html">2013-10-14: Flood in India on 14 October, 2013</a></li>
          <li><a href="2013/article20130824JP.html">2013-08-24: Flood in Japan on 24 August, 2013</a></li>
          <li><a href="2013/article20130819PH.html">2013-08-19: Flood in Philippines on 19 August, 2013</a></li>
          <li><a href="2013/article20130728JP.html">2013-07-28: Flood in Japan on 28 July, 2013</a></li>
          <li><a href="2013/article20130723TH.html">2013-07-23: Flood in Thailand on 23 July, 2013</a></li>
          <li><a href="2013/article20130712MM.html">2013-07-12: Flood in Myanmar on 12 July, 2013</a></li>
          <li><a href="2013/article20130618NP.html">2013-06-18: Flood in Nepal on 18 June, 2013</a></li>
          <li><a href="2013/article20130617IN.html">2013-06-17: Flood in India on 17 June, 2013</a></li>
          <li><a href="2013/article20130420CN.html">2013-04-20: Earthquake in China on 20 April, 2013</a></li>
          <li><a href="2013/article20130417ID.html">2013-04-17: Forest fire in Indonesia on 17 April, 2013</a></li>
          <li><a href="2013/article20130217ID.html">2013-02-17: Flood in Indonesia on 17 February, 2013</a></li>
          <li><a href="2013/article20130205SB.html">2013-02-05: Tsunami in Solomon on 05 February, 2013</a></li>
          <li><a href="2013/article20130114ID.html">2013-01-14: Flood in Indonesia on 14 January, 2013</a></li>
			
  </ul></span>	
			
<br>
<br>
			
<a name="2012" id="2012"></a>
			  <input id="acd-check2012" class="acd-check" type="checkbox">
  <label class="acd-label" for="acd-check2012">2012</label>
  <span class="acd-content">
	  
	          <ul class="defaultlist note">
			
          <li><a href="2012/article20121227PH.html">2012-12-27: Typhoon in Philippines on 27 December, 2012</a></li>
          <li><a href="2012/article20121205_1PH.html">2012-12-05: Typhoon in Philippines on 05 December, 2012</a></li>
          <li><a href="2012/article20121205_2BN.html">2012-12-05: Flood in Brunei on 05 December, 2012</a></li>
          <li><a href="2012/article20121109ID.html">2012-11-09: Flash flood in Indonesia on 09 November, 2012</a></li>
          <li><a href="2012/article20120923IN.html">2012-09-23: Flood in India on 23 September, 2012</a></li>
          <li><a href="2012/article20120908VN.html">2012-09-08: Flood in Vietnam on 08 September, 2012</a></li>
          <li><a href="2012/article20120826ID.html">2012-08-26: Flash flood in Indonesia on 26 August, 2012</a></li>
          <li><a href="2012/article20120823KZ.html">2012-08-23: Forest fire in Kazakhstan on 23 August, 2012</a></li>
          <li><a href="2012/article20120808PH.html">2012-08-08: Flood in Philippines on 08 August, 2012</a></li>
          <li><a href="2012/article20120721CN.html">2012-07-21: Flood in China on 21 July, 2012</a></li>
          <li><a href="2012/article20120703JP.html">2012-07-03: Flood in Japan on 03 July, 2012</a></li>
          <li><a href="2012/article20120625CN.html">2012-06-25: Flood in China on 25 June, 2012</a></li>
          <li><a href="2012/article20120511TJ.html">2012-05-11: Flood in Tajikistan on 11 May, 2012</a></li>
          <li><a href="2012/article20120505NP.html">2012-05-05: Flash flood in Nepal on 05 May, 2012</a></li>
          <li><a href="2012/article20120327KG.html">2012-03-27: Flood in Kyrgyzstan on 27 March, 2012</a></li>
          <li><a href="2012/article20120302KG.html">2012-03-02: Flood in Kazakhstan on 02 March, 2012</a></li>
          <li><a href="2012/article20120207PH.html">2012-02-07: Earthquake in Philippines on 07 February, 2012</a></li>
          <li><a href="2012/article20120125PG.html">2012-01-25: Landslide in Papua New Guinea on 25 January, 2012</a></li>
          <li><a href="2012/article20120122FJ.html">2012-01-22: Flood in Fiji on 22 January, 2012</a></li>
			
  </ul></span>	

<br>
<br>
			
			<a name="2011" id="2011"></a>			
			  <input id="acd-check2011" class="acd-check" type="checkbox">
  <label class="acd-label" for="acd-check2011">2011</label>
  <span class="acd-content">
	  
	          <ul class="defaultlist note">
			
          <li><a href="2011/article20111217PH.html">2011-12-17: Flood in Philippines on 17 December, 2011</a></li>
          <li><a href="2011/article20111212ID.html">2011-12-12: Volcano eruption in Indonesia on 12 December, 2011</a></li>
          <li><a href="2011/article20111107VN.html">2011-11-07: Flood in Vietnam on 07 November, 2011</a></li>
          <li><a href="2011/article20111022MM.html">2011-10-22: Flash flood in Myanmar on 22 October, 2011</a></li>
          <li><a href="2011/article20111004VN.html">2011-10-04: Flood in Vietnam on 04 October, 2011</a></li>
          <li><a href="2011/article20111001KH.html">2011-10-01: Flood in Cambodia on 01 October, 2011</a></li>
          <li><a href="2011/article20110927PH.html">2011-09-27: Flood in Philippines on 27 September, 2011</a></li>
          <li><a href="2011/article20110921JP.html">2011-09-21: Flood in Japan on 21 September, 2011</a></li>
          <li><a href="2011/article20110919IN.html">2011-09-19: Earthquake in India on 19 September, 2011</a></li>
          <li><a href="2011/article20110915PK.html">2011-09-15: Flood in Pakistan on 15 September, 2011</a></li>
          <li><a href="2011/article20110904JP.html">2011-09-04: Flood in Japan on 04 September, 2011</a></li>
          <li><a href="2011/article20110829TW.html">2011-08-29: Typhoon in Taiwan on 29 August, 2011</a></li>
          <li><a href="2011/article20110804TH.html">2011-08-04: Flood in Thailand on 04 August, 2011</a></li>
          <li><a href="2011/article20110729JP.html">2011-07-29: Flood in Japan on 29 July, 2011</a></li>
          <li><a href="2011/article20110726PH.html">2011-07-26: Flash flood in Philippines on 26 July, 2011</a></li>
          <li><a href="2011/article20110720KZ.html">2011-07-20: Earthquake in Kyrgyzstan on 20 July, 2011</a></li>
          <li><a href="2011/article20110718IN.html">2011-07-18: Flood in India on 18 July, 2011</a></li>
          <li><a href="2011/article20110716NP.html">2011-07-16: Flood in Nepal on 16 July, 2011</a></li>
          <li><a href="2011/article20110701NP.html">2011-07-01: Flood in Nepal on 01 July, 2011</a></li>
          <li><a href="2011/article20110614TJ.html">2011-06-14: Flash flood in Tajikistan on 14 June, 2011</a></li>
          <li><a href="2011/article20110507ID.html">2011-05-07: Flash flood in Indonesia on 07 May, 2011</a></li>
          <li><a href="2011/article20110412KZ.html">2011-04-12: Flood in Kazakhstan on 12 April, 2011</a></li>
          <li><a href="2011/article20110326TH.html">2011-03-26: Flood in Thailand on 26 March, 2011</a></li>
          <li><a href="2011/article20110325MM.html">2011-03-25: Earthquake in Myanmar on 25 March, 2011</a></li>
          <li><a href="2011/article20110311JP.html">2011-03-11: Earthquake in Japan on 11 March, 2011</a></li>
          <li><a href="2011/article20110222NZ.html">2011-02-22: Earthquake in New Zealand on 22 February, 2011</a></li>
          <li><a href="2011/article20110203_1LK.html">2011-02-03: Flood in Sri Lanka on 03 February, 2011</a></li>
          <li><a href="2011/article20110203_2PH.html">2011-02-03: Flood in Philippines on 03 February, 2011</a></li>
          <li><a href="2011/article20110120BN.html">2011-01-20: Flood in Brunei on 20 January, 2011</a></li>
          <li><a href="2011/article20110110LK.html">2011-01-10: Flood in Sri Lanka on 10 January, 2011</a></li>
          <li><a href="2011/article20110103AU.html">2011-01-03: Flood in Australia on 03 January, 2011</a></li>
			
  </ul></span>	

<br>
<br>
			
			<a name="2010" id="2010"></a>
			  <input id="acd-check2010" class="acd-check" type="checkbox">
  <label class="acd-label" for="acd-check2010">2010</label>
  <span class="acd-content">
	  
	          <ul class="defaultlist note">
			
          <li><a href="2010/article20101210LK.html">2010-12-10: Flood in Sri Lanka on 10 December, 2010</a></li>
          <li><a href="2010/article20101130VN.html">2010-11-30: Flood in Vietnam on 30 November, 2010</a></li>
          <li><a href="2010/article20101118VN.html">2010-11-18: Flood in Vietnam on 18 November, 2010</a></li>
          <li><a href="2010/article20101101VN.html">2010-11-01: Flood in Vietnam on 01 November, 2010</a></li>
          <li><a href="2010/article20101027ID.html">2010-10-27: Volcano eruption in Indonesia on 27 October, 2010</a></li>
          <li><a href="2010/article20101026ID.html">2010-10-26: Tsunami in Indonesia on 26 October, 2010</a></li>
          <li><a href="2010/article20101022TW.html">2010-10-22: Flash flood in Taiwan on 22 October, 2010</a></li>
          <li><a href="2010/article20101020JP.html">2010-10-20: Flood in Japan on 20 October, 2010</a></li>
          <li><a href="2010/article20101018PH.html">2010-10-18: Storm surge in Isabela, Philippines on 18 October, 2010</a></li>
          <li><a href="2010/article20101017TH.html">2010-10-17: Flash flood in Thailand on 17 October, 2010</a></li>
          <li><a href="2010/article20101015_1KH.html">2010-10-15: Flood in Cambodia on 15 October, 2010</a></li>
          <li><a href="2010/article20101015_2KH.html">2010-10-15: Flash flood in Cambodia on 15 October, 2010</a></li>
          <li><a href="2010/article20101004_1ID.html">2010-10-04: Flood in Indonesia on 04 October, 2010</a></li>
          <li><a href="2010/article20101004_2VN.html">2010-10-04: Flood in Vietnam on 04 October, 2010</a></li>
          <li><a href="2010/article20100916IN.html">2010-09-16: Flash flood in India on 16 September, 2010</a></li>
          <li><a href="2010/article20100829ID.html">2010-08-29: Volcano eruption in Indonesia on 29 August, 2010</a></li>
          <li><a href="2010/article20100824VN.html">2010-08-24: Flood in Vietnam on 24 August, 2010</a></li>
          <li><a href="2010/article20100812ID.html">2010-08-12: Volcano eruption in Indonesia on 12 August, 2010</a></li>
          <li><a href="2010/article20100808CN.html">2010-08-08: Mudslide in China on 08 August, 2010</a></li>
          <li><a href="2010/article20100806IN.html">2010-08-06: Flood in India on 06 August, 2010</a></li>
          <li><a href="2010/article20100731PK.html">2010-07-31: Flood in Pakistan on 31 July, 2010</a></li>
          <li><a href="2010/article20100725IN.html">2010-07-25: Flood in India on 25 July, 2010</a></li>
          <li><a href="2010/article20100725ID.html">2010-07-25: Flood in Indonesia on 25 July, 2010</a></li>
          <li><a href="2010/article20100721BT.html">2010-07-21: Flood in Bhutan on 21 July, 2010</a></li>
          <li><a href="2010/article20100717VN.html">2010-07-17: Typhoon in Vietnam on 17 July, 2010</a></li>
          <li><a href="2010/article20100615BD.html">2010-06-15: Landslide in Bangladesh on 15 June, 2010</a></li>
          <li><a href="2010/article20100514LK.html">2010-05-14: Flood in Sri Lanka on 14 May, 2010</a></li>
          <li><a href="2010/article20100507TJ.html">2010-05-07: Flood in Tajikistan on 07 May, 2010</a></li>
          <li><a href="2010/article20100425TW.html">2010-04-25: Landslide in Taiwan on 25 April, 2010</a></li>
          <li><a href="2010/article20100411TJ.html">2010-04-11: Flood in Tajikistan on 11 April, 2010</a></li>
          <li><a href="2010/article20100404NP.html">2010-04-04: Forest fire in Nepal on 04 April, 2010</a></li>
          <li><a href="2010/article20100321ID.html">2010-03-21: Flood in Indonesia on 21 March, 2010</a></li>
          <li><a href="2010/article20100313KZ.html">2010-03-13: Flood in Kazakhstan on 13 March, 2010</a></li>
          <li><a href="2010/article20100310BT.html">2010-03-10: Forest fire in Bhutan on 10 March, 2010</a></li>
          <li><a href="2010/article20100223ID.html">2010-02-23: Landslide in Indonesia on 23 February, 2010</a></li>
			
  </ul></span>	

<br>
<br>

			
<a name="2009" id="2009"></a>
			  <input id="acd-check2009" class="acd-check" type="checkbox">
  <label class="acd-label" for="acd-check2009">2009</label>
  <span class="acd-content">
	  
	          <ul class="defaultlist note">
			
          <li><a href="2009/article20091225PH.html">2009-12-25: Volcano eruption in Philippines on 25 December, 2009</a></li>
          <li><a href="2009/article20091216LK.html">2009-12-16: Flood in Sri Lanka on 16 December, 2009</a></li>
          <li><a href="2009/article20091102VN.html">2009-11-02: Flood in Vietnam on 02 November, 2009</a></li>
          <li><a href="2009/article20091006NP.html">2009-10-06: Flood in Nepal on 06 October, 2009</a></li>
          <li><a href="2009/article20091006_1NP.html">2009-10-06: Flood in Nepal on 06 October, 2009</a></li>
          <li><a href="2009/article20091006_2NP.html">2009-10-06: Flood in Nepal on 06 October, 2009</a></li>
          <li><a href="2009/article20091004PH.html">2009-10-04: Flood in Philippines on 04 October, 2009</a></li>
          <li><a href="2009/article20091001VN.html">2009-10-01: Flood in Vietnam on 01 October, 2009</a></li>
          <li><a href="2009/article20090930ID.html">2009-09-30: Earthquake in Indonesia on 30 September, 2009</a></li>
          <li><a href="2009/article20090926_1PH.html">2009-09-26: Flood in Philippines on 26 September, 2009</a></li>
          <li><a href="2009/article20090926_2VN.html">2009-09-26: Flood in Vietnam on 26 September, 2009</a></li>
          <li><a href="2009/article20090902ID.html">2009-09-02: Earthquake in Indonesia on 02 September, 2009</a></li>
          <li><a href="2009/article20090818NP.html">2009-08-18: Flood in Nepal on 18 August, 2009</a></li>
          <li><a href="2009/article20090808PH.html">2009-08-08: Typhoon in Philippines on 08 August, 2009</a></li>
          <li><a href="2009/article20090705VN.html">2009-07-05: Flood in Vietnam on 05 July, 2009</a></li>
          <li><a href="2009/article20090327ID.html">2009-03-27: Flood in Indonesia on 27 March, 2009</a></li>
          <li><a href="2009/article20090311AU.html">2009-03-11: Typhoon in Australia on 11 March, 2009</a></li>
          <li><a href="2009/article20090219AU.html">2009-02-19: Flood in Australia on 19 February, 2009</a></li>
          <li><a href="2009/article20090207AU.html">2009-02-07: Forest fire in Australia on 07 February, 2009</a></li>
          <li><a href="2009/article20090122PH.html">2009-01-22: Flood in Philippines on 22 January, 2009</a></li>
          <li><a href="2009/article20090104ID.html">2009-01-04: Earthquake in Indonesia on 04 January, 2009</a></li>

			
  </ul></span>	

<br>
<br>

<a name="2008" id="2008"></a>
			  <input id="acd-check2008" class="acd-check" type="checkbox">
  <label class="acd-label" for="acd-check2008">2008</label>
  <span class="acd-content">
	  
	          <ul class="defaultlist note">
			
				  
          <li><a href="2008/article20081218TH.html">2008-12-18: Flood in Thailand on 18 December, 2008</a></li>
          <li><a href="2008/article20081124TH.html">2008-11-24: Flood in Thailand on 24 November, 2008</a></li>
          <li><a href="2008/article20081104VN.html">2008-11-04: Flood in Vietnam on 04 November, 2008</a></li>
          <li><a href="2008/article20081029PK.html">2008-10-29: Earthquake in Pakistan on 29 October, 2008</a></li>
          <li><a href="2008/article20080920NP.html">2008-09-20: Flood in Nepal on 20 September, 2008</a></li>
          <li><a href="2008/article20080908TH.html">2008-09-08: Flood in Thailand on 08 September, 2008</a></li>
          <li><a href="2008/article20080818NP.html">2008-08-18: Flood in Nepal on 18 August, 2008</a></li>
          <li><a href="2008/article20080812LA.html">2008-08-12: Flood in Laos on 12 August, 2008</a></li>
          <li><a href="2008/article20080724JP.html">2008-07-24: Earthquake in Japan on 24 July, 2008</a></li>
          <li><a href="2008/article20080621PH.html">2008-06-21: Typhoon in Philippines on 21 June, 2008</a></li>
          <li><a href="2008/article20080614JP.html">2008-06-14: Earthquake in Japan on 14 June, 2008</a></li>
          <li><a href="2008/article20080604ID.html">2008-06-04: Flood in Indonesia on 04 June, 2008</a></li>
          <li><a href="2008/article20080512CN.html">2008-05-12: Earthquake in China on 12 May, 2008</a></li>
          <li><a href="2008/article20080502MM.html">2008-05-02: Tropical cyclone in Myanmar on 02 May, 2008</a></li>
          <li><a href="2008/article20080224ID.html">2008-02-24: Flood in Indonesia on 24 February, 2008</a></li>
          <li><a href="2008/article20080124AU.html">2008-01-24: Flood in Australia on 24 January, 2008</a></li>			
  </ul></span>	

<br>
<br>		
				
<a name="2007" id="2007"></a>
			  <input id="acd-check2007" class="acd-check" type="checkbox">
  <label class="acd-label" for="acd-check2007">2007</label>
  <span class="acd-content">
	  
	          <ul class="defaultlist note">
			
	<li><a href="2007/article20071119BD.html">2007-11-19: Tropical cyclone in Bangladesh on 19 November, 2007</a></li>
<li><a href="2007/article20071115VN.html">2007-11-15: Flood in Vietnam on 15 November, 2007</a></li>
<li><a href="2007/article20071028VN.html">2007-10-28: Flood in Vietnam on 28 October, 2007</a></li>
<li><a href="2007/article20071024TH.html">2007-10-24: Flood in Thailand on 24 October, 2007</a></li>
<li><a href="2007/article20070912ID.html">2007-09-12: Earthquake in Indonesia on 12 September, 2007</a></li>
<li><a href="2007/article20070803BD.html">2007-08-03: Flood in Bangladesh on 03 August, 2007</a></li>
<li><a href="2007/article20070723ID.html">2007-07-23: Flood in Indonesia on 23 July, 2007</a></li>
<li><a href="2007/article20070722TJ.html">2007-07-22: Earthquake in Tajikistan on 22 July, 2007</a></li>
<li><a href="2007/article20070709ID.html">2007-07-09: Volcano eruption in Indonesia on 09 July, 2007</a></li>
<li><a href="2007/article20070626PK.html">2007-06-26: Flood in Pakistan on 26 June, 2007</a></li>
<li><a href="2007/article20070611BD.html">2007-06-11: Landslide in Bangladesh on 11 June, 2007</a></li>
<li><a href="2007/article20070527NP.html">2007-05-27: Cold wave in Nepal on 27 May, 2007</a></li>
<li><a href="2007/article20070402SB.html">2007-04-02: Tsunami in Solomon on 02 April, 2007</a></li>
<li><a href="2007/article20070306ID.html">2007-03-06: Earthquake in Indonesia on 06 March, 2007</a></li>
<li><a href="2007/article20070203ID.html">2007-02-03: Flood in Indonesia on 03 February, 2007</a></li>
			  
				  
				  
			
				          </ul></span>	
		
		
        <br><br>
      </div><!-- /.container -->
    </article>
  </main>

<footer></footer>
<div id="page_top"><a href="#"></a></div>


  <!-- JS -->
<script src="../js/slick/slick.min.js"></script>
<script src="../js/common.js"></script>
</body>
</html>