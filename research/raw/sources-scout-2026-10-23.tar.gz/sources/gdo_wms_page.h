HTTP/1.1 200 Connection Established

HTTP/2 200 
date: Fri, 23 Oct 2026 20:00:51 GMT
content-type: text/html; charset=utf-8
access-control-allow-origin: *
access-control-allow-headers: Authorization
access-control-allow-methods: GET
access-control-expose-headers: Content-Security-Policy, Location
access-control-max-age: 600
cache-control: no-cache, private
vary: Accept-Encoding
content-encoding: gzip
x-azure-ref: 20261023T200051Z-r19dbdbfcd58rkkmhC1DTTgwt8000000052000000000rgkp
x-fd-int-roxy-purgeid: 66551398

