HTTP/1.1 200 Connection Established

HTTP/2 200 
date: Fri, 23 Oct 2026 20:05:50 GMT
content-type: text/html
content-length: 89798
access-control-allow-origin: https://asmc.asean.org
last-modified: Fri, 23 Oct 2026 11:02:26 GMT
etag: "15ec6-65e7fea63456f"
cache-control: public, max-age=180
x-frame-options: SAMEORIGIN
strict-transport-security: max-age=31536000; includeSubDomains
x-content-type-options: nosniff
referrer-policy: no-referrer
content-security-policy: frame-src 'self' *.youtube.com *.asmc.asean.org *.google.com; 			frame-ancestors 'self' https://asmc.asean.org *.google.comv; 			script-src 'self' *.google.com *.adobedtm.com *.youtube.com https://*.gstatic.com *.wogaa.sg *.google-analytics.com *.googleapis.com *.googletagmanager.com cdnjs.cloudflare.com 'unsafe-inline' 'unsafe-eval'; 			object-src https://asmc.asean.org; 			font-src 'self' 'unsafe-inline' 'unsafe-eval' data: https://assets.wogaa.sg/fonts/ https://fonts.gstatic.com https://*.googleapis.com https://maxcdn.bootstrapcdn.com; 			style-src 'self' 'unsafe-inline' 'unsafe-eval' https://*.wogaa.sg https://asmc.asean.org/ https://*.googleapis.com https://maxcdn.bootstrapcdn.com fonts.bunny.net; 			connect-src 'self' *.google.com *.adobedtm.com *.youtube.com *.wogaa.sg *.google-analytics.com *.googleapis.com *.googletagmanager.com https://asmc.asean.org; 			default-src 'self' https://*.wogaa.sg https://asmc.asean.org https://www.google-analytics.com https://www.googletagmanager.com s.w.org; 			img-src	'self' data: https://maps.gstatic.com https://*.googleapis.com https://cdn.amcharts.com https://*.googleusercontent.com https://www.weather.gov.sg
age: 23
x-cache-detail: "cache hit" from asmc.asean.org
vary: User-Agent,Origin
x-azure-ref: 20261023T200549Z-17449f5b48dmwgwphC1IADq70s000000077g00000000074w
x-fd-int-roxy-purgeid: 0
accept-ranges: bytes

