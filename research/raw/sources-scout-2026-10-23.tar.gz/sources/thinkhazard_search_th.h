HTTP/1.1 200 Connection Established

HTTP/2 200 
cache-control: public
content-security-policy: default-src 'self'; script-src 'self' 'unsafe-inline' https://www.google-analytics.com https://cdnjs.cloudflare.com; style-src 'self' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; img-src 'self' data: https://www.gfdrr.org http://www.geonode-gfdrrlab.org https://api.mapbox.com; connect-src 'self' https://www.google-analytics.com
content-type: application/json
date: Fri, 23 Oct 2026 20:10:44 GMT
last-modified: Tue, 30 Jun 2020 15:57:03 GMT
referrer-policy: no-referrer, strict-origin-when-cross-origin
server: gunicorn
strict-transport-security: max-age=31536000; includeSubDomains
x-content-type-options: nosniff
x-frame-options: SAMEORIGIN
x-xss-protection: 0
content-length: 104

