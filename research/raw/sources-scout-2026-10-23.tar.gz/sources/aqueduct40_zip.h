HTTP/1.1 200 Connection Established

HTTP/2 206 
content-type: application/zip
content-length: 1
server: AmazonS3
last-modified: Mon, 07 Aug 2023 16:11:26 GMT
x-amz-version-id: HfL9xpiDJMeTwfl2PEHYy1j.rW3QTqXA
x-amz-server-side-encryption: AES256
x-amz-replication-status: COMPLETED
date: Fri, 23 Oct 2026 20:07:24 GMT
etag: "612e5aeca7f46f8a60888a39b5ed5ca6-16"
via: 1.1 c5445f293f8aab8bb6b7a6fda978e0d2.cloudfront.net (CloudFront)
x-amz-cf-pop: ORD56-P6
x-amz-cf-id: khs2ricFT83AGHo2V_l3RDDWXc0Uf2MMUfPixFkymaIHMYJs68N0Ow==
age: 14557
content-range: bytes 0-0/261527511

