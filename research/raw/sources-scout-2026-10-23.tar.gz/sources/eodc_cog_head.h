HTTP/1.1 200 Connection Established

HTTP/2 206 
content-type: text/plain; charset=utf-8
content-length: 1024
date: Fri, 23 Oct 2026 19:59:15 GMT
last-modified: Fri, 23 Oct 2026 16:39:48 GMT
etag: "6adb8dd4-3138"
content-range: bytes 0-1023/12600
server: APISIX/3.18.0
access-control-allow-origin: *
access-control-allow-methods: GET,HEAD,OPTIONS
access-control-max-age: 86400
access-control-expose-headers: *
access-control-allow-headers: *

