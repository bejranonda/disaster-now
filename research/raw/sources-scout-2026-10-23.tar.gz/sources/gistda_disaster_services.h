HTTP/1.1 200 Connection Established

HTTP/2 200 
server: nginx
date: Fri, 23 Oct 2026 19:58:20 GMT
content-type: text/html; charset=utf-8
vary: rsc, next-router-state-tree, next-router-prefetch, next-router-segment-prefetch, Accept-Encoding
x-nextjs-cache: HIT
x-nextjs-prerender: 1
x-nextjs-prerender: 1
x-nextjs-stale-time: 300
x-powered-by: Next.js
cache-control: s-maxage=31536000
etag: "11qxksc9s6zv94"
content-encoding: gzip
x-kong-upstream-latency: 7
x-kong-proxy-latency: 0
via: 1.1 kong/3.9.0
x-kong-request-id: e82d0557a9dd6148615c22171b70d164

