HTTP/1.1 200 Connection Established

HTTP/2 200 
content-type: image/png
date: Fri, 23 Oct 2026 20:00:06 GMT
x-xss-protection: 1; mode=block
x-frame-options: SAMEORIGIN
server: ServerTokens ProductOnly
pragma: no-cache
expires: Thu, 1 Jan 1970 00:00:00 GMT
cache-control: max-age=0, no-store, no-cache, must-revalidate
access-control-allow-origin: *
strict-transport-security: max-age=31536000; includeSubDomains; preload
x-content-type-options: nosniff
via: 1.1 8988ac4ba052e2403132359fee301d5e.cloudfront.net (CloudFront)
x-amz-cf-pop: ORD56-P7
x-amz-cf-id: hB4tgY13KZfbSgJngj6iXH1mf24vc2DXIATb5VjJDpYMajXGs2hVLQ==

