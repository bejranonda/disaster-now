HTTP/1.1 200 Connection Established

HTTP/2 200 
cache-control: public, max-age=60
etag: 28f72978f960f156
content-type: image/png
access-control-allow-origin: https://disaster-now.example
access-control-allow-credentials: true
vary: Origin
x-cloud-trace-context: e5adf6b0bbe080d91b059a2189936b31;o=1
date: Fri, 23 Oct 2026 20:09:59 GMT
server: Google Frontend
content-length: 11940

