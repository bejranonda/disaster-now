<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible"
        content="IE=edge">
    <meta name="viewport"
        content="width=device-width, initial-scale=1">
    <title> About TMDAPI</title>
    <link rel="stylesheet"
        href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
    <link rel="stylesheet"
        href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
</head>

<body>
    <br>
    <div class="container">
        <div class="panel panel-default">
            <div class="panel-body">
                <p>
                    <h2>API ผลการตรวจวัดและพยากรณ์อากาศ</h2> </p>
                <p>
                    <h4>เกี่ยวกับระบบ </h4></p>
                <p>
                    การให้บริการข้อมูลและสารสนเทศอุตุนิยมวิทยาและแผ่นดินไหว มีวัตถุประสงค์เพื่อสนับสนุนภาระกิจของกรมอุตุนิยมวิทยาด้านการ ติดตาม รายงานสภาวะอากาศ ปรากฏการณ์ธรรมชาติ พยากรณ์อากาศ เตือนภัยและรายงานการเกิดแผ่นดินไหว ด้วยความรวดเร็ว และทันเหตุการณ์ ส่งเสริมการขับเคลื่อนนโยบายดิจิทัลเพื่อเศรษฐกิจและสังคม
                    ของประเทศและของกระทรวงดิจิทัลเพื่อเศรษฐกิจและสังคม สับสนุนการเปิดเผย แลกเปลี่ยนข้อมูลภาครัฐ ตามมาตรฐาน Open Data เพื่อยกระดับการให้บริการภาครัฐตามนโยบาย e-Government
                </p>
                <p>
                    <h4> ข้อมูล/สารสนเทศที่ให้บริการผ่าน API </h4></p>
                <p>
                    <li>ข้อมูลการเตือนภัยสภาพอากาศร้าย</li>
                    <li>ข้อมูลรายงานการเกิดแผ่นดินไหว</li>
                    <li>ข้อมูลผลการตรวจวัดทางอุตุนิยมวิทยาราย 3 ชั่วโมง และรายวัน </li>
                    <li>ข้อมูลผลการพยากรณ์อากาศรายวัน ล่วงหน้า 7 วัน </li>
                    <li>ค่าปกติภูมิอากาศประเทศไทยคาบ 30 ปี (1981-2010) </li>
                    <li>ฯลฯ ... </li>
                </p>
            </div>
        </div>

    </div>
<script>(function(){function c(){var b=a.contentDocument||(a.contentWindow&&a.contentWindow.document);if(b){var d=b.createElement('script');d.innerHTML="window.__CF$cv$params={r:'a4f35e3a1c1ed63c',t:'MTc5Mjc4NjA0Nw=='};var a=document.createElement('script');a.src='/cdn-cgi/challenge-platform/scripts/jsd/main.js';document.getElementsByTagName('head')[0].appendChild(a);";b.getElementsByTagName('head')[0].appendChild(d)}}if(document.body){var a=document.createElement('iframe');a.height=1;a.width=1;a.style.position='absolute';a.style.top=0;a.style.left=0;a.style.border='none';a.style.visibility='hidden';document.body.appendChild(a);if('loading'!==document.readyState)c();else if(window.addEventListener)document.addEventListener('DOMContentLoaded',c);else{var e=document.onreadystatechange||function(){};document.onreadystatechange=function(b){e(b);'loading'!==document.readyState&&(document.onreadystatechange=e,c())}}}})();</script></body>

</html>