<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0">
    <channel>
        <title>JTWC TROPICAL CYCLONE INFORMATION FEED</title>
        <link>https://s3.amazonaws.com/www.metoc.navy.mil/jtwc/jtwc.html</link>
        <description>JTWC Tropical Cyclone Information</description>
        <pubDate>Fri, 23 Oct 2026 19:54:02 +0000</pubDate>
        <lastBuildDate>Fri, 23 Oct 2026 19:54:02 +0000</lastBuildDate>
        <generator>ContentFeeder 2.0</generator>
        <image>
            <url>https://s3.amazonaws.com/www.metoc.navy.mil/jtwc/jtwc.html</url>
            <title>JTWC TROPICAL CYCLONE INFORMATION FEED</title>
            <link>https://s3.amazonaws.com/www.metoc.navy.mil/jtwc/jtwc.html</link>
        </image>
        <item>
            <title>Current Northwest Pacific/North Indian Ocean* Tropical Systems</title>
            <link>https://s3.amazonaws.com/www.metoc.navy.mil/jtwc/jtwc.html</link>
            <description><![CDATA[<p><b>Tropical Depression  30W (Thirty) Warning #01 </b><br>
<b>Issued at 23/1500Z<b>

<ul>
<li><a href='https://www.metoc.navy.mil/jtwc/products/wp3026web.txt' target='newwin'>TC Warning Text </a></li>
 <li><a href='https://www.metoc.navy.mil/jtwc/products/wp3026.gif' target='newwin'>TC Warning Graphic</a></li>
 <li><a href='https://www.metoc.navy.mil/jtwc/products/wp3026prog.txt' target='newwin'>Prognostic Reasoning</a></li>
 <li><a href='https://www.metoc.navy.mil/jtwc/products/wp3026.tcw' target='newwin'>JMV 3.0 Data</a></li>
 <li><a href='https://www.metoc.navy.mil/jtwc/products/wp3026.kmz' target='newwin'>Google Earth Overlay</a> <img src='https://www.metoc.navy.mil/jtwc/img/kml.jpg'></li>
 <li><a href='https://www.metoc.navy.mil/jtwc/products/30W_231200sair.jpg' target='newwin'>IR Satellite Imagery</a></li>
 <li><a href='https://www.metoc.navy.mil/jtwc/products/wp3026fix.txt' target='newwin'>Satellite Fix Bulletin</a></li>
 </ul>
<br>
<p><b>Typhoon  29W (Champi) Warning #37 </b><br>
<b>Issued at 23/1500Z<b>

<ul>
<li><a href='https://www.metoc.navy.mil/jtwc/products/wp2926web.txt' target='newwin'>TC Warning Text </a></li>
 <li><a href='https://www.metoc.navy.mil/jtwc/products/wp2926.gif' target='newwin'>TC Warning Graphic</a></li>
 <li><a href='https://www.metoc.navy.mil/jtwc/products/wp2926prog.txt' target='newwin'>Prognostic Reasoning</a></li>
 <li><a href='https://www.metoc.navy.mil/jtwc/products/wp2926.tcw' target='newwin'>JMV 3.0 Data</a></li>
 <li><a href='https://www.metoc.navy.mil/jtwc/products/wp2926.kmz' target='newwin'>Google Earth Overlay</a> <img src='https://www.metoc.navy.mil/jtwc/img/kml.jpg'></li>
 <li><a href='https://www.metoc.navy.mil/jtwc/products/29W_231200sair.jpg' target='newwin'>IR Satellite Imagery</a></li>
 <li><a href='https://www.metoc.navy.mil/jtwc/products/wp2926fix.txt' target='newwin'>Satellite Fix Bulletin</a></li>
 </ul>
<br>
 <p><i>* Includes Bay of Bengal and Arabian Sea</i>
]]></description>
            <author>CDO.JTWC.fct@navy.mil (JTWC CDO)</author>
            <category>Northwest Pacific/North Indian Ocean* Tropical Systems</category>
            <guid>NWPAC-NIO-WARNINGS</guid>
            <pubDate>Fri, 23 Oct 26 19:54:02 +0000</pubDate>
        </item>
        <item>
            <title>Current Central/Eastern Pacific Tropical Systems</title>
            <link>https://s3.amazonaws.com/www.metoc.navy.mil/jtwc/jtwc.html</link>
            <description><![CDATA[<p><b>Hurricane  22E (Vance) Warning #09 </b><br>
<b>Issued at 23/1600Z<b>

<ul>
<li><a href='https://www.metoc.navy.mil/jtwc/products/ep2226web.txt' target='newwin'>TC Warning Text </a></li>
 <li><a href='https://www.metoc.navy.mil/jtwc/products/ep2226.gif' target='newwin'>TC Warning Graphic</a></li>
 <li><a href='https://www.metoc.navy.mil/jtwc/products/ep2226.tcw' target='newwin'>JMV 3.0 Data</a></li>
 <li><a href='https://www.metoc.navy.mil/jtwc/products/ep2226.kmz' target='newwin'>Google Earth Overlay</a> <img src='https://www.metoc.navy.mil/jtwc/img/kml.jpg'></li>
 <li><a href='https://www.metoc.navy.mil/jtwc/products/22E_231200sair.jpg' target='newwin'>IR Satellite Imagery</a></li>
 </ul>
]]></description>
            <author>CDO.JTWC.fct@navy.mil (JTWC CDO)</author>
            <category>Central/Eastern Pacific Tropical Systems</category>
            <guid>EPAC-CPAC-WARNINGS</guid>
            <pubDate>Fri, 23 Oct 26 19:54:02 +0000</pubDate>
        </item>
        <item>
            <title>Current Southern Hemisphere Tropical Systems</title>
            <link>https://s3.amazonaws.com/www.metoc.navy.mil/jtwc/jtwc.html</link>
            <description><![CDATA[<b>Tropical Cyclone  02S (Agueda) Warning #07 <b><br>
<b>Issued at 23/0900Z<b>

<ul>
<li><a href='https://www.metoc.navy.mil/jtwc/products/sh0227web.txt' target='newwin'>TC Warning Text </a></li>
 <li><a href='https://www.metoc.navy.mil/jtwc/products/sh0227.gif' target='newwin'>TC Warning Graphic</a></li>
 <li><a href='https://www.metoc.navy.mil/jtwc/products/sh0227prog.txt' target='newwin'>Prognostic Reasoning</a></li>
 <li><a href='https://www.metoc.navy.mil/jtwc/products/sh0227.tcw' target='newwin'>JMV 3.0 Data</a></li>
 <li><a href='https://www.metoc.navy.mil/jtwc/products/sh0227.kmz' target='newwin'>Google Earth Overlay</a> <img src='https://www.metoc.navy.mil/jtwc/img/kml.jpg'></li>
 <li><a href='https://www.metoc.navy.mil/jtwc/products/02S_230600sair.jpg' target='newwin'>IR Satellite Imagery</a></li>
 <li><a href='https://www.metoc.navy.mil/jtwc/products/sh0227fix.txt' target='newwin'>Satellite Fix Bulletin</a></li>
 </ul>
]]></description>
            <author>CDO.JTWC.fct@navy.mil (JTWC CDO)</author>
            <category>Southern Hemisphere Tropical Systems</category>
            <guid>SH-WARNINGS</guid>
            <pubDate>Fri, 23 Oct 26 19:54:02 +0000</pubDate>
        </item>
        <item>
            <title>Current Significant Tropical Weather Advisories</title>
            <link>https://s3.amazonaws.com/www.metoc.navy.mil/jtwc/jtwc.html</link>
            <description><![CDATA[<ul>
      <li><b><a href="https://www.metoc.navy.mil/jtwc/products/abpwweb.txt" target='newwin'>ABPW10 (Western/South Pacific Ocean)</a><br>

      <font color=red>Reissued at 23/1500Z</font></li>
      <li><b><a href="https://www.metoc.navy.mil/jtwc/products/abioweb.txt" target='newwin'>ABIO10 (Indian Ocean)</a><br>

      Issued at 23/1800Z</b></li>
<li><a href='https://www.metoc.navy.mil/jtwc/products/abpwsair.jpg' target='newwin'>Satellite Image</a></li>
</ul>]]></description>
            <author>CDO.JTWC.fct@navy.mil (JTWC CDO)</author>
            <category>Significant Tropical Weather Advisories</category>
            <guid>TROPICAL-ADVISORIES</guid>
            <pubDate>Fri, 23 Oct 26 19:54:02 +0000</pubDate>
        </item>
    </channel>
</rss>
