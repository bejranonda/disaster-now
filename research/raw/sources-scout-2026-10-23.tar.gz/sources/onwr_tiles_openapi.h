HTTP/1.1 200 Connection Established

HTTP/2 200 
content-type: application/json
access-control-allow-origin: https://disaster-now.example
access-control-allow-credentials: true
vary: Origin
x-cloud-trace-context: 837f5bab4ee6343a91755e93106bed3a
date: Fri, 23 Oct 2026 20:09:46 GMT
server: Google Frontend
content-length: 10712

