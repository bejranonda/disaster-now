HTTP/1.1 200 Connection Established

HTTP/2 200 
date: Fri, 23 Oct 2026 19:59:07 GMT
server: uvicorn
content-length: 262
content-type: application/json
access-control-allow-origin: *
access-control-allow-credentials: true
content-encoding: gzip
vary: Accept-Encoding
cache-control: public, max-age=3600

