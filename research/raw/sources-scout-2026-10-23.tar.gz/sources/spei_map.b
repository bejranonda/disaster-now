<!DOCTYPE html>
<html lang="en">
    <head>
        <title>SPEI Global Drought Monitor</title>
        <meta name="viewport"
              content="width=device-width, initial-scale=1.0, user-scalable=no">
        <meta charset="UTF-8">
        <meta name="description" content="The SPEI is a multiscalar drought index based on climatic data. It can be used for determining the onset, duration and magnitude of drought conditions with respect to normal conditions in a variety of natural and managed systems such as crops, ecosystems, rivers, water resources, etc."/>
        <!-- jquery y jquery-ui -->
        <link type="text/css" href="css/jquery-ui/jquery-ui.min.css" rel="Stylesheet" />
        <!-- Bootstrap http://twitter.github.com/bootstrap/ v.2.2.1 -->
        <link type="text/css" href="css/bootstrap.min.css" rel="stylesheet">
        <!-- Propios de la página -->
        <link type="text/css" href="css/googlemaps.css" rel="Stylesheet" />

        <!-- Cabecera y pie de página -->
        <link href="../css/spei.css" rel="stylesheet">

        <!-- Icono pestaña del navegador-->
        <link href='../img/spei-drop.png' rel='shortcut icon'>

        <link rel="stylesheet" href="css/leaflet.css" />
    </head>
    <body onload="initialize()">
    <canvas  id="hidden-canvas" width="50" height="50" style="display:none;"></canvas>
        <div class="navbar navbar-inverse navbar-fixed-top">
                <div class="container">
                    <div class="navbar-header">
                        <button aria-controls="nav-collapse" aria-expanded="false" class="collapsed navbar-toggle" data-target="#nav-collapse" data-toggle="collapse" type="button">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                    </div>
                    <nav id="nav-collapse" class="navbar-collapse collapse">
                        <ul class="nav navbar-nav">
                            <li><a href="../index.html">Home</a></li>
                            <li><a href="../home.html">About the SPEI</a></li>
                            <li class="active"><a href="../map/">Global drought monitor</a></li>
                            <li><a href="../database.html">Global SPEI database</a></li>
                            <li><a href="../tools.html">Tools</a></li>
                            <li><a href="../contact.html">Contact</a></li>
                        </ul>
                    </nav>
                </div>
        </div>

        <div id="contenedorPrincipal" class="container">
            <!-- Main hero unit for a primary marketing message or call to action -->
            <div id="map_canvas_hero" class="jumbotron hero-unit">
                <div class="contentTitle"><h1><img alt="SPEI web logo" src="../img/spei-drop.png">SPEI Global Drought Monitor</h1></div>
                <div id="test"></div>
                <br/>
                <div id="map_canvas"></div>
                <br/>

                <table id="scale">
                    <tbody>
                        <tr>
                            <td id="color9" class="span1 colores">&lt;-2.33</td>
                            <td id="color8" class="span1 colores">-1.65</td>
                            <td id="color7" class="span1 colores">-1.28</td>
                            <td id="color6" class="span1 colores">-0.84</td>
                            <td id="color5" class="span1 colores">0</td>
                            <td id="color4" class="span1 colores">0.84</td>
                            <td id="color3" class="span1 colores">1.28</td>
                            <td id="color2" class="span1 colores">1.65</td>
                            <td id="color1" class="span1 colores">>2.33</td>
                        </tr>
                    </tbody>
                </table>

                <div id="nav" class="navbar navbar-default">
                    <div class="container">
                        <div class="navbar-header">
                            <button aria-controls="nav-collapse2" aria-expanded="false" class="collapsed navbar-toggle" data-target="#nav-collapse2" data-toggle="collapse" type="button" onclick="ChangeTop ();">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                        </div>
                        <nav id="nav-collapse2" class="navbar-collapse collapse">
                            <ul class="nav navbar-nav">
                                <li>
                                    <form class="navbar-form form-inline">
                                        <div class="form-group">
                                            <label class="navbar-text" style="margin-right: 4px;">SPEI Time-Scale</label>
                                            <select name="months" id="months" class="input-mini form-control" onchange="setMonthReference(document.getElementById('months').value)">
                                                <option value="0" onmouseover="setMonthReference(0)">1
                                                <option value="1" onmouseover="setMonthReference(1)">3
                                                <option value="2" onmouseover="setMonthReference(2)">6
                                                <option value="3" onmouseover="setMonthReference(3)">9
                                                <option value="4" onmouseover="setMonthReference(4)">12
                                                <option value="5" onmouseover="setMonthReference(5)">24
                                                <option value="6" onmouseover="setMonthReference(6)">36
                                                <option value="7" onmouseover="setMonthReference(7)">48
                                            </select>
                                        </div>
                                    </form>
                                </li>
                                <li>
                                    <form class="navbar-form form-inline" onsubmit="setDate(document.getElementById('month').value, document.getElementById('year').value); return false">
                                        <div class="form-group">
                                            <label id="dateMaxMin" class="navbar-text"  style="margin-right: 4px;"> Date </label>
                                            <div id="dateProblem" class="navbar-form">
                                                <select id="month" name="month" class="input-medium form-control"  onchange="setDate(document.getElementById('month').value, document.getElementById('year').value)">
                                                    <option value="0" onmouseover="setDate(0, document.getElementById('year').value)">January
                                                    <option value="1" onmouseover="setDate(1, document.getElementById('year').value)">February
                                                    <option value="2" onmouseover="setDate(2, document.getElementById('year').value)">March
                                                    <option value="3" onmouseover="setDate(3, document.getElementById('year').value)">April
                                                    <option value="4" onmouseover="setDate(4, document.getElementById('year').value)">May
                                                    <option value="5" onmouseover="setDate(5, document.getElementById('year').value)">June
                                                    <option value="6" onmouseover="setDate(6, document.getElementById('year').value)">July
                                                    <option value="7" onmouseover="setDate(7, document.getElementById('year').value)">August
                                                    <option value="8" onmouseover="setDate(8, document.getElementById('year').value)">September
                                                    <option value="9" onmouseover="setDate(9, document.getElementById('year').value)">October
                                                    <option value="10" onmouseover="setDate(10, document.getElementById('year').value)">November
                                                    <option value="11" onmouseover="setDate(11, document.getElementById('year').value)">December
                                                </select>
                                                <input type="text" id="year" name="year" class="input-micro form-control"  value="0" placeholder="year" onchange="setDate(document.getElementById('month').value, document.getElementById('year').value)">
                                            </div>
                                        </div>
                                    </form>
                                </li>
                                <li>
                                    <div>
                                        <a class="flechaSlider" href='javascript:setDatePrevious1();' style="float:left; margin-left: 6px"><span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span></a>
                                        <div id="dateContenedorSlider" style="float:left; margin-left: 6px; margin-right: 6px">
                                            <div id="dateSlider"></div>
                                        </div>
                                        <a class="flechaSlider" href='javascript:setDateAfter1();' style="float:left"><span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span></a>
                                    </div>
                                </li>
                                <li>
                                    <p id="mapValue" class="navbar-text"></p>
                                </li>
                            </ul>
                            <form class="navbar-form pull-right">
                               <button type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#help">
                                    Help
                               </button>
                            </form>
                        </nav>
                    </div>
                </div>
                <div id="accordion2">
                    <div id="pegarGraficaOne">
                        <div id="graphic_canvas">
                            <form id="graphic0" class="well form-inline">
                                <div id="graphdiv0" style="width: inherit; height: 320px;"></div>
                            </form>
                        </div>
                    </div>
                    <div class="well">
                        <form class="form-inline">
                            <input id="radio_pixel" type="radio" name="choice" value="pixel" checked onchange="modificarGrafica('pixel');" style="margin: auto;">
                            <label><b>SPEI time series at a single grid cell </b></label>
                            <fieldset id="latlng2Problem">
                                <label id="graphic_point">Coordinate: </label>
                                <input type="text" id="lat2" name="lat" class="input-micro form-control" placeholder="lat" onchange="graphicDrawing(document.getElementById('lat2').value, document.getElementById('lng2').value, 0, 'latlng2Problem'); scheduleTask('point', 0)">
                                <label id="graphic_point_coma">, </label>
                                <input type="text" id="lng2" name="lng" class="input-micro form-control" placeholder="lon" onchange="graphicDrawing(document.getElementById('lat2').value, document.getElementById('lng2').value, 0, 'latlng2Problem'); scheduleTask('point', 0)">
                                <button id="pointDownloadButton" type="button" class="btn btn-default" onclick="downloadPoint(document.getElementById('lat2').value, document.getElementById('lng2').value)"><span class="glyphicon glyphicon-download" aria-hidden="true"></span> Download</button>
                            </fieldset>
                        </form>

                        <form id="form_radio_frame" class="form-inline" style="border:0px; box-shadow:0px 0px 0px; margin:0px 0px 0px;">
                            <input id="radio_frame" type="radio" name="choice" value="frame" onchange="modificarGrafica('frame');" style="margin: auto;">
                            <label><b style="color:red" >SPEI time series over a region </b></label>
                        </form>
                        <form id="form_segunda" class="form-inline" style="border:0px; box-shadow:0px 0px 0px; margin:0px 0px 30px;">
                            <fieldset id="latlng3Problem">
                                <label class="graphic_point">Upper left: </label>
                                <input type="text" id="lat3" name="lat" class="input-micro form-control"  value="41.75" placeholder="lat" onchange="iniRectangle(); graphicDrawing(document.getElementById('lat3').value, document.getElementById('lng3').value, 0, 'latlng3Problem'); graphicDrawing(document.getElementById('lat4').value, document.getElementById('lng4').value, 1, 'latlng4Problem');scheduleTask('rectangle_average', 0)">
                                <label class="graphic_point_coma">, </label>
                                <input type="text" id="lng3" name="lng" class="input-micro form-control"  value="-0.75" placeholder="lon" onchange="iniRectangle(); graphicDrawing(document.getElementById('lat3').value, document.getElementById('lng3').value, 0, 'latlng3Problem'); graphicDrawing(document.getElementById('lat4').value, document.getElementById('lng4').value, 1, 'latlng4Problem');scheduleTask('rectangle_average', 0)">
                                <label class="graphic_point">Lower right: </label>
                                <input type="text" id="lat4" name="lat" class="input-micro form-control"  value="46.75" placeholder="lat" onchange="iniRectangle(); graphicDrawing(document.getElementById('lat3').value, document.getElementById('lng3').value, 0, 'latlng3Problem'); graphicDrawing(document.getElementById('lat4').value, document.getElementById('lng4').value, 1, 'latlng4Problem');scheduleTask('rectangle_average', 0)">
                                <label class="graphic_point_coma">, </label>
                                <input type="text" id="lng4" name="lng" class="input-micro form-control"  value="4.25" placeholder="lon" onchange="iniRectangle(); graphicDrawing(document.getElementById('lat3').value, document.getElementById('lng3').value, 0, 'latlng3Problem'); graphicDrawing(document.getElementById('lat4').value, document.getElementById('lng4').value, 1, 'latlng4Problem');scheduleTask('rectangle_average', 0)">
                                <button id="rectangleDownloadButton" type="button" class="btn btn-default" onclick="rectangleWindow()"><span class="glyphicon glyphicon-download" aria-hidden="true"></span> Download pixels</button>
                                <button id="rectangleDownloadButtonAverage" type="button" class="btn btn-default" onclick="rectangleWindowAverage()"><span class="glyphicon glyphicon-download" aria-hidden="true"></span> Download average</button>
                                <button id="rectangleUpdateButtonAverage" type="button" class="btn btn-default" onclick="scheduleTask('rectangle_average', 0)"><span class="glyphicon glyphicon-download" aria-hidden="true"></span> Update graph</button>
                            </fieldset>
                        </form>
                    </div>

                <br/>
                <h2 class="smalltitle"> Download complete time series in NetCDF format </h2>
                <form id="monthsAllForm" class="well form-inline" name="button" onsubmit="downloadAll(document.getElementById('monthsAll').value);return false">
                    <label class="graphic_point">SPEI Time-Scale: </label>
                    <select class="input-mini form-control" id="monthsAll">
                        <option value="1">1
                        <option value="2">2
                        <option value="3">3
                        <option value="4">4
                        <option value="5">5
                        <option value="6">6
                        <option value="7">7
                        <option value="8">8
                        <option value="9">9
                        <option value="10">10
                        <option value="11">11
                        <option value="12">12
                        <option value="13">13
                        <option value="14">14
                        <option value="15">15
                        <option value="16">16
                        <option value="17">17
                        <option value="18">18
                        <option value="19">19
                        <option value="20">20
                        <option value="21">21
                        <option value="22">22
                        <option value="23">23
                        <option value="24">24
                        <option value="25">25
                        <option value="26">26
                        <option value="27">27
                        <option value="28">28
                        <option value="29">29
                        <option value="30">30
                        <option value="31">31
                        <option value="32">32
                        <option value="33">33
                        <option value="34">34
                        <option value="35">35
                        <option value="36">36
                        <option value="37">37
                        <option value="38">38
                        <option value="39">39
                        <option value="40">40
                        <option value="41">41
                        <option value="42">42
                        <option value="43">43
                        <option value="44">44
                        <option value="45">45
                        <option value="46">46
                        <option value="47">47
                        <option value="48">48
                    </select>
                    <button type="submit" class="btn btn-default"><span class="glyphicon glyphicon-download" aria-hidden="true"></span> Download</button>
                </form>

                <!-- <h2 class="smalltitle"> Download the most recent map </h2> -->
                <form id="mostRecentForm" class="well form-inline" name="button" onsubmit="downloadMostRecent(); return false">
                    <label class="graphic_point"> Download the most recent map: </label>
                    <button type="submit" class="btn btn-default"> <span class="glyphicon glyphicon-download"  style="color:red" aria-hidden="true"></span> Download</button>
                </form>

                <div id="LoginForm" class="well form-inline">
                    <label class="graphic_point"> Please login to download most recent map </label>
                    <button class="btn btn-default" onclick="keycloak.login()"> <span class="glyphicon glyphicon-log-in" aria-hidden="true"></span> Login</button>
                </div>
                <div id="LogoutForm" class="well form-inline" style="display: none;">
                    <label class="graphic_point"> You are Currently logged as:</label>
                    <button type="submit" class="btn btn-default" onclick="keycloak.logout()"> <span class="glyphicon glyphicon-log-out" aria-hidden="true"></span> Logout</button>
                    <button class="btn btn-default" onclick="goToAccount()"> <span class="glyphicon glyphicon-user" aria-hidden="true"></span> Profile</button>
                </div>

                <br/>
                <h2 class="smalltitle"> Information
                </h2>
                <p>
                    The SPEI Global Drought Monitor offers near real-time information about drought conditions at the global scale, with a 1 degree spatial resolution and a monthly time resolution. SPEI time-scales between 1 and 48 months are provided. The calibration period for the SPEI is January 1950 to December 2010. The starting date of the dataset is 1955 in order to provide common information across the different SPEI time-scales.
                </p><p>
                    The dataset is updated during the first days of the following month based on the most reliable and updated sources of climatic data. Mean temperature data are obtained from the <a href=ftp://ftp.cpc.ncep.noaa.gov/wd51yf/GHCN_CAMS/>
                    NOAA NCEP CPC GHCN_CAMS gridded dataset</a>. Monthly precipitation sums data are obtained from the  'first guess' <a href=ftp://ftp-anon.dwd.de/pub/data/gpcc/first_guess/>
                    Global Precipitation Climatology Centre (GPCC)</a>. The CPC data with an original resolution of 0.5º, is interpolated to the resolution of 1º.
                </p><p>
                    Currently, the SPEI Global Drought Monitor is based on the
                    Thortnthwaite equation for estimating potential evapotranspiration,
                    PET. This is due to the lack of real-time data sources for computing
                    more robust PET estimations which have larger data requirements. The
                    main advantage of the SPEI Global Drought Monitor is thus its near
                    real-time character, a characteristic best suited for drought monitoring
                    and early warning purposes. For long-term analysis, however, other
                    datasets are to be preferred that rely on more robust methods of PET
                    estimation. Use of the <a href="../database.html">
                    SPEIbase dataset</a>, which is based on the FAO-56 Penman-Monteith
                    model, is thus recommended for climatological studies of drought.
                </p>

                <br/>
                <h2 class="smalltitle"> Licensing </h2>
                <p>The data from SPEI Global Drought Monitor
                    is made available under the <a href="http://opendatacommons.org/licenses/odbl/1.0/">
                        Open Database License</a>. Any rights in individual contents of the database are
                    licensed under the <a href="http://opendatacommons.org/licenses/dbcl/1.0/">
                        Database Contents License</a>.
                </p>
                <p>What follows is a  human-readable summary of the ODbL 1.0 license.
                    Please, read the full ODbL 1.0 license text for the exact terms that apply.
                </p>
                    Users of the dataset are free to:
                <ul>
                    <li><strong>Share</strong>: copy, distribute and use the database, either commercially or non-commercially.</li>
                    <li><strong>Create</strong>: produce derivative works from the database.</li>
                    <li><strong>Adapt</strong>: modify, transform and build upon the database.</li>
                </ul>
                Under the following conditions:
                <ul>
                    <li><strong>Attribution</strong>: You must attribute any public use of the database, or works produced from the database, by citing one or more of the papers referenced in the References section below. For any use or redistribution of the database, or works produced from it, you must make clear to others the license of the original database.</li>
                    <li><strong>Share-Alike</strong>: If you publicly use any adapted version of this database, or works produced from an adapted database, you must also offer that adapted database under the ODbL.</li>
                </ul>

                </div>
            </div> <!-- /hero-unit -->
        </div>  <!-- /container -->

            <!-- Footer
        ================================================== -->
        <div id="footer" class="container">
            <!-- Main hero unit for a primary marketing message or call to action -->
            <div class="jumbotron hero-unit">
                <p class="pull-right"><a href="#">Back to top</a></p>
                <a href="https://lcsc.csic.es"><img alt="LCSC Logo" src="../img/logo_lcsc.png" style="height: 70px;"></a>
                <a href="http://www.csic.es"><img alt="CSIC logo" src="../img/layout_set_logo.jpeg"></a>
                <a href="http://www.ipe.csic.es"><img alt="IPE logo" src="../img/ipe_logo.jpeg"  style="height: 67px;"></a>
                <a href="http://www.eead.csic.es"><img alt="EEAD logo" src="../img/logo_eead.png" style="height: 67px;"></a>
                <br/><br/>
                <p>
                    All texts and images licensed under a
                    <a href="http://creativecommons.org/licenses/by/3.0/" target="_blank">Creative Commons Attribution 3.0
                    Unported License</a>.
                    <br/>Data licensed under the
                    <a href="http://opendatacommons.org/licenses/odbl/1.0/" target="_blank">Open Database License (ODbL)</a>: the data is free to use, but any works produced from it must be attributed, keep open, and shared under the same license.
                    <br/>Code licensed under the <a href="http://www.gnu.org/licenses/agpl-3.0.html" target="_blank">
                    GNU Affero General Public License</a>.
                </p>
                <ul class="footer-links">
                    <li>Authors: </li>
                    <li><a href="http://santiago.begueria.es">Santiago Beguería</a></li>
                    <li><a href="http://eead.csic.es/home/staffinfo?Id=215">Borja Latorre</a></li>
                    <li><a href="http://www.fergusreig.es">Fergus Reig</a></li>
                    <li><a href="http://www.ipe.csic.es/vicente-serrano-s.m.">Sergio M. Vicente-Serrano</a></li>
                </ul>
                <ul class="footer-links">
                    <li><a href="../index.html">Home</a></li>
                    <li><a href="../home.html">About the SPEI</a></li>
                    <li><a href="../map/">Global drought monitor</a></li>
                    <li><a href="../database.html">Global SPEI database</a></li>
                    <li><a href="../tools.html">Tools</a></li>
                    <li><a href="../contact.html">Contact</a></li>
                </ul>
            </div>  <!-- /hero-unit -->
        </div> <!-- /container -->


<!-- Texto de "info" -->
<div id="help" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabelHelp" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h3 id="myModalLabelHelp">Help</h3>
            </div>
            <div class="modal-body">
                <p>
                    Change the SPEI time scale and the date of interest to modify the information shown in the map.
                    Use the arrows or the hand tool for panning the map. Use the and the + and - buttons
                    for changing the scale of the map.
                </p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal" aria-hidden="true">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- Texto de "info graph" -->
<div id="help_graph" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h3 id="myModalLabel">Help</h3>
            </div>
            <div class="modal-body">
                <p>
                    Select one analysis mode between the three modes available
                    (entire World, single grid cell or region).
                    Select the grid cell or the region on the map or by
                    entering the coordinates, and update the graph.
                    Download the time series in CSV format if desired,
                    or download all grid cells in a region (this last option
                    might take a while).
                </p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal" aria-hidden="true">Close</button>
            </div>
        </div>
    </div>
</div>

<div id="errorAjax" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabelError" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h3 id="myModalLabelError">Problem connecting to remote server</h3>
            </div>
            <div class="modal-body">
                <p>
                    Problem connecting to remote server.
                </p>
                <p>
                    We are suffering some problems we hope to solve as soon as possible. Sorry for the inconvenience.
                </p>
                <p>
                    If you use IE8 or IE9, you may have configured your browser
                    to not allow connection to remote servers.
                </p><p>
                    Follow the instructions below:
                </p><p>
                    <img alt="Error IE image" src="./img/EnableCrossDomainRequestsIE.png">
                </p>
            </div>
            <div class="modal-footer">
                <button class="btn btn-default" data-dismiss="modal" aria-hidden="true">Close</button>
            </div>
        </div>
    </div>
</div>

<div id="login_to_download" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h3 id="myModalLabel">Download last NC</h3>
            </div>
            <div class="modal-body">
                <p>
                    The last four weeks are restricted to Licensed Users.
                </p><p>
                    If you are a Licensed User please login to be able to download full database
                </p><p>             
                    To request access you can register on the login page or request to the administrators of LCSC
                </p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" onclick="keycloak.login()" data-dismiss="modal" aria-hidden="true">Login</button>
                <button type="button" class="btn btn-default" data-dismiss="modal" aria-hidden="true">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- Le javascript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="js/dygraph-combined.js"> </script>
<script src="js/jquery.min.js"></script>
<script src="js/jquery-ui.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/leaflet.js"></script>
<script src="js/keycloak.js"></script>
<!-- Cabecera y pie de página -->
<script src="https://lcsc.csic.es/web_share_files/js/createlayers.js"></script>
<script src="js/task.js"></script>
<script src="js/spei.js"></script>
<!-- Estadísticas de Google Analytics -->
<script src="../js/analytics.js"></script>

</body>
</html>
