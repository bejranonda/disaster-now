HTTP/1.1 200 Connection Established

HTTP/1.1 200 OK
Server: nginx
Date: Fri, 23 Oct 2026 20:08:07 GMT
Content-Type: text/html; charset=UTF-8
Connection: keep-alive
Vary: Accept-Encoding
Last-Modified: Thu, 22 Oct 2026 12:20:14 GMT
Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline' 'unsafe-eval' https://www.googletagmanager.com https://www.google-analytics.com https://cdnjs.cloudflare.com https://connect.facebook.net https://www.google.com https://www.gstatic.com; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; img-src 'self' data: https:; font-src 'self' data: https://fonts.gstatic.com; connect-src 'self' https://www.google-analytics.com https://connect.facebook.net https://www.facebook.com https://www.google.com; frame-src 'self' https: blob:;
Content-Encoding: gzip
Content-Length: 76483

