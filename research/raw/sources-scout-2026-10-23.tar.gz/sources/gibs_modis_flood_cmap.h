HTTP/1.1 200 Connection Established

HTTP/2 200 
content-type: text/xml
date: Fri, 23 Oct 2026 20:00:05 GMT
content-encoding: gzip
etag: W/"490-65e706c44395f"
server: ServerTokens ProductOnly
cache-control: public, max-age=3600
last-modified: Thu, 22 Oct 2026 16:33:26 GMT
strict-transport-security: max-age=31536000; includeSubDomains; preload
vary: Accept-Encoding
access-control-allow-origin: *
x-xss-protection: 1; mode=block
x-content-type-options: nosniff
x-frame-options: SAMEORIGIN
via: 1.1 60c88db543a29cd102f9de910cd9043c.cloudfront.net (CloudFront)
x-amz-cf-pop: ORD56-P7
x-amz-cf-id: -Ftenj_3PwjaQ-vY0sWl_bdAHOVckJ4586gJp39s9IaGeI3KWocVnA==

