HTTP/1.1 200 Connection Established

HTTP/2 200 
content-type: text/html
server: AmazonS3
last-modified: Fri, 23 Oct 2026 00:10:11 GMT
x-amz-version-id: 68AYyeHGzb7Rw6ysTIHX.QDorjJHW0xw
content-encoding: gzip
x-content-type-options: nosniff
referrer-policy: same-origin
content-security-policy: default-src 'self' studiolab.sagemaker.aws assets.opendata.aws a0.awsstatic.com; object-src 'none'
strict-transport-security: max-age= 63072000; includeSubdomains; preload
x-xss-protection: 1; mode=block
x-frame-options: DENY
date: Fri, 23 Oct 2026 20:01:47 GMT
etag: W/"e4e2c04e9d63470029ae857d7b9cac0e"
vary: Accept-Encoding
via: 1.1 2886efe8cce919124ca781f7c3ab22a2.cloudfront.net (CloudFront)
x-amz-cf-pop: IAD12-P5
x-amz-cf-id: R8UUWxOPpmqju0cx0e95ITA5wwfKGLP4pSsrQH59Yb7TyhUNXxvDNw==

