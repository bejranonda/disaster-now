HTTP/1.1 200 Connection Established

HTTP/2 200 
date: Fri, 23 Oct 2026 20:00:28 GMT
content-type: text/html; charset=utf-8
access-control-allow-origin: *
access-control-allow-headers: Authorization
access-control-allow-methods: GET
access-control-expose-headers: Content-Security-Policy, Location
access-control-max-age: 600
cache-control: no-cache, private
vary: Accept-Encoding
content-encoding: gzip
x-azure-ref: 20261023T200028Z-r19f94f7f95srv7ghC1DTT1szs00000004w000000000rtef
x-fd-int-roxy-purgeid: 66551398

