#!/usr/bin/env python3
"""Consistency with บ้านรอดไหม (Hazard-huntz): the advice lines and bands the page copies from kit.json (air, hot), the
sources they cite, the words of each band, the action each point's page actually showed, and every guide link (live GET).
  python3 -I hh_compare.py"""
import json, re, subprocess, sys
sys.path.insert(0, "/tmp/claude-0/-home-user/d0c0b487-5c79-5ab8-a62d-123ead309e6f/scratchpad/xcheck/scripts")
from recompute import X, load_json  # noqa: E402

HH = "/home/user/Hazard-huntz/public/content"
CODE = f"{X}/code-at-capture/js"
kit = load_json(f"{HH}/kit.json")
srcs = load_json(f"{HH}/sources.json")["sources"]
act = open(f"{CODE}/actions.js", encoding="utf-8").read()
lev = open(f"{CODE}/levels.js", encoding="utf-8").read()
rows = []

def row(item, page, hh, ok, note=""):
    rows.append({"item": item, "page": page, "hh": hh, "match": "✅" if ok is True else "❌" if ok is False else ok, "note": note})

# ---- the advice tables in actions.js ----
pm_rows = re.findall(r'\{ upto: ([\d.]+|Infinity), th: "([^"]+)", en: "([^"]+)" \}', act.split("const HEAT")[0])
heat_rows = re.findall(r'\{ upto: ([\d.]+|Infinity), th: "([^"]+)", en: "([^"]+)", src: \[([^\]]*)\] \}', act.split("const HEAT")[1])
air = kit["air"]["levels"]
for (upto, t, e), lvl in zip(pm_rows, air):
    hh_all = lvl["all"][0]
    edge = "Infinity" if lvl["pm"] is None else str(lvl["pm"]).rstrip("0").rstrip(".") if "." in str(lvl["pm"]) else str(lvl["pm"])
    row(f"PM2.5 line ≤ {upto}", f"{t} / {e}", f"{lvl['id']} (≤ {lvl['pm']}): {hh_all['th']} / {hh_all['en']}",
        t == hh_all["th"] and e == hh_all["en"] and (upto == "Infinity" if lvl["pm"] is None else float(upto) == float(lvl["pm"])))
    if hh_all.get("mask"):
        row(f"PM2.5 ≤ {upto}: under-2 line that บ้านรอดไหม always adds after a mask line", "not shown", kit["air"]["baby"]["th"], False,
            "kit.json air._readme: a line with mask:true is always followed by the baby line (v1.11.1); the page shows the mask line alone (actions.js PM, assess.js c.action)")
hot = kit["hot"]["levels"]
for (upto, t, e, src) in heat_rows:
    lvl = next(l for l in hot if float(l["hi"] or 1e9) == (1e9 if upto == "Infinity" else float(upto)))
    hh_all = lvl["all"][0]
    ids = [s.strip().strip('"') for s in src.split(",") if s.strip()]
    row(f"Heat line ≤ {upto}", f"{t} / {e} [{', '.join(ids)}]", f"{lvl['id']} {lvl['lo']}–{lvl['hi']}: {hh_all['th']} / {hh_all['en']} [{', '.join(hh_all['sources'])}]",
        t == hh_all["th"] and e == hh_all["en"] and ids == hh_all["sources"])
# cited sources
for cid, url in re.findall(r'"([a-z0-9-]+)": \{ title: "[^"]+",\s*url: "([^"]+)"', act):
    s = srcs.get(cid)
    row(f"Source {cid}", url, s["url"] if s else "missing", bool(s) and s["url"] == url)

# ---- bands ----
def mins(name):
    blk = lev.split(f"  {name}: {{")[1].split("bands: [")[1].split("]")[0]
    return [(m[0], m[1]) for m in re.findall(r'\{ min: (-Infinity|[\d.]+), level: \d, th: "([^"]+)"', blk)]
pm_b = mins("pm25")
hh_pm = [l["pm"] for l in air]
row("PM2.5 band edges", " · ".join(f"{a}" for a, _ in pm_b[1:]), " · ".join(f"> {x}" for x in hh_pm if x is not None),
    [float(a) for a, _ in pm_b[1:]] == [round(x + 0.1, 1) for x in hh_pm if x is not None])
aq_b = mins("aqi")
hh_aq = [l["aqi"] for l in air]
row("AQI band edges", " · ".join(a for a, _ in aq_b[1:]), " · ".join(f"> {x}" for x in hh_aq if x is not None),
    [float(a) for a, _ in aq_b[1:]] == [x + 1 for x in hh_aq if x is not None])
hb = mins("heat")
row("Heat band edges", " · ".join(a for a, _ in hb[1:]), " · ".join(l["lo"] for l in hot), [float(a) for a, _ in hb[1:]] == [float(l["lo"]) for l in hot])
row("Heat band words (TH)", " · ".join(w for _, w in hb[1:]), " · ".join(l["label"]["th"] for l in hot), [w for _, w in hb[1:]] == [l["label"]["th"] for l in hot])
heat_en = re.findall(r'th: "[^"]+", en: "([^"]+)"', lev.split("  heat: {")[1].split("bands: [")[1].split("]")[0])
row("Heat band words (EN)", " · ".join(heat_en[1:]), " · ".join(l["label"]["en"] for l in hot), heat_en[1:] == [l["label"]["en"] for l in hot],
    "English names differ (NWS words vs บ้านรอดไหม's)")
pm_words = [w for _, w in pm_b]
hh_words = [l["label"]["th"].split(" · ")[1] for l in air]
row("PM2.5 band words (TH)", " · ".join(pm_words), " · ".join(hh_words), pm_words == hh_words,
    "the page uses the PCD notice's own 'ผลกระทบ' wording; บ้านรอดไหม shortens it (and the page's own pre-warning says 'ฝุ่นเริ่มมีผลต่อสุขภาพ')")

# ---- what each point's page actually advised ----
for pid in ["bkk", "cnx", "hdy", "hkt", "ubn", "msi"]:
    r = load_json(f"{X}/results/{pid}.json")
    cap = load_json(f"{X}/raw/{pid}/capture.json")
    cards = {c["id"]: c["text"] for c in cap["th"]["cards"]}
    pm_txt = re.search(r"👉 (.+)", cards["card-pm25"]).group(1)
    v = float(re.search(r"([\d.]+) µg", cards["card-pm25"]).group(1))
    lvl = next(l for l in air if l["pm"] is None or v <= l["pm"])
    row(f"{pid}: PM2.5 action at {v}", pm_txt, f"{lvl['id']}: {lvl['all'][0]['th']}", pm_txt == lvl["all"][0]["th"])
    st = r["extra"]["a4t"]["station"]
    if st:
        lvl2 = next(l for l in air if l["pm"] is None or st["pm25"] <= l["pm"])
        if lvl2["id"] != lvl["id"]:
            row(f"{pid}: PM2.5 action had the PCD station been read ({st['id']} {st['pm25']})", pm_txt, f"{lvl2['id']}: {lvl2['all'][0]['th']}", False,
                "GISTDA's estimate put the point in another PCD colour than the measurement 0.6–0.9 km away")
    h_txt = re.search(r"👉 (.+)", cards["card-heat"]).group(1)
    hv = float(re.search(r"(\d+) °C", cards["card-heat"]).group(1))
    p50 = float(re.search(r"p50 = ([\d.]+)", next(x for x in r["rows"] if x["item"].startswith("Heat: value"))["mine"]).group(1))
    hl = next(l for l in hot if l["hi"] is None or round(p50, 1) <= float(l["hi"])) if p50 >= 27 else None
    row(f"{pid}: heat action at {p50:.1f} °C", h_txt, f"{hl['id']}: {hl['all'][0]['th']}" if hl else "(below 27: none)", bool(hl) and h_txt == hl["all"][0]["th"])

# ---- links, live ----
UA = "disaster-now-research/0.1 (+https://github.com/bejranonda/disaster-now)"
links = {}
for pid in ["bkk", "cnx"]:
    cap = load_json(f"{X}/raw/{pid}/capture.json")
    for c in cap["th"]["cards"]:
        for a in c["links"]:
            if "baanrodmai" in a["href"]:
                links.setdefault(a["href"], (c["id"], a["text"]))
for href, (cid, txt) in sorted(links.items()):
    out = subprocess.run(["curl", "-sS", "--compressed", "-A", UA, "-m", "40", "-L", "-o", "-", "-w", "\n%{http_code} %{url_effective}", href],
                         capture_output=True, text=True)
    body, tail = out.stdout.rsplit("\n", 1) if "\n" in out.stdout else ("", out.stdout)
    title = re.search(r"<title>([^<]+)</title>", body)
    h1 = re.search(r"<h1[^>]*>(.*?)</h1>", body, re.S)
    row(f"Link {href.split('.bot')[1]} ({cid})", txt, f"{tail.strip()} · <title> {title.group(1).strip() if title else '–'} · h1 {re.sub('<[^>]+>', '', h1.group(1)).strip()[:80] if h1 else '–'}",
        tail.startswith("200"))
json.dump(rows, open(f"{X}/results/hazardhuntz.json", "w"), ensure_ascii=False, indent=1)
for x in rows:
    print(f"{x['match']} {x['item']}\n    page: {x['page']}\n    HH  : {x['hh']}  {x['note']}")
