#!/usr/bin/env node
// Output cross-check, step 1: open the page for each point in headless Chromium (live sources, no mocks), record every
// tile/card text (TH and EN) and every external response the page received; then, within seconds, fetch the same
// sources independently with curl (honest UA) plus Air4Thai's official endpoint and FloodWatch's /api/point + /api/stations.
//   node capture.mjs [pointIndex...]
import { chromium } from "/home/user/disaster-now/node_modules/playwright-core/index.mjs";
import { mkdirSync, writeFileSync } from "node:fs";
import { execFile } from "node:child_process";
import { promisify } from "node:util";

const run = promisify(execFile);
const OUT = "/tmp/claude-0/-home-user/d0c0b487-5c79-5ab8-a62d-123ead309e6f/scratchpad/xcheck";
const BASE = "http://127.0.0.1:8787/";
const UA = "disaster-now-research/0.1 (+https://github.com/bejranonda/disaster-now)";
const A4T_CA = `${OUT}/a4t-ca.pem`;
export const POINTS = [
  { id: "bkk", lat: 13.7563, lon: 100.5018, name: "Bangkok old town" },
  { id: "cnx", lat: 18.7883, lon: 98.9853, name: "Chiang Mai" },
  { id: "hdy", lat: 7.0086, lon: 100.4747, name: "Hat Yai" },
  { id: "hkt", lat: 7.8804, lon: 98.3923, name: "Phuket" },
  { id: "ubn", lat: 15.2287, lon: 104.8564, name: "Ubon" },
  { id: "msi", lat: 20.4285, lon: 99.8765, name: "Mae Sai" },
];
const want = process.argv.slice(2).map(Number);
const points = want.length ? want.map((i) => POINTS[i]) : POINTS;

const hostOf = (u) => new URL(u).host;
const safe = (s) => s.replace(/[^a-z0-9]+/gi, "_").slice(0, 60);

async function curl(url, file, { ca } = {}) {
  const args = ["-sS", "--compressed", "-A", UA, "-m", "60", "-o", file, "-w", "%{http_code} %{time_total} %{size_download}"];
  if (ca) args.push("--cacert", ca);
  args.push(url);
  const t0 = new Date().toISOString();
  try {
    const { stdout } = await run("curl", args, { maxBuffer: 1e6 });
    const [code, secs, size] = stdout.trim().split(" ");
    return { url, file, t0, code: +code, secs: +secs, size: +size };
  } catch (e) {
    return { url, file, t0, error: String(e.stderr || e.message).trim().slice(0, 300) };
  }
}

async function main() {
  // Playwright's own proxy option sends 127.0.0.1 through the proxy too (<-loopback>); Chromium's flags don't
  const browser = await chromium.launch({ executablePath: "/opt/pw-browsers/chromium",
    args: ["--no-sandbox", `--proxy-server=${process.env.HTTPS_PROXY || "http://127.0.0.1:35641"}`, "--proxy-bypass-list=127.0.0.1;localhost"] });
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, locale: "th-TH", timezoneId: "Asia/Bangkok",
    ignoreHTTPSErrors: false });
  const page = await ctx.newPage();
  const inflight = new Set();
  let current = null;
  let seq = 0;
  const seen = []; // every external response, all points
  page.on("request", (r) => { if (!r.url().startsWith(BASE)) inflight.add(r); });
  page.on("requestfailed", (r) => {
    inflight.delete(r);
    if (current && !r.url().startsWith(BASE)) current.net.push({ url: r.url(), failed: r.failure()?.errorText, t: new Date().toISOString() });
  });
  page.on("requestfinished", (r) => inflight.delete(r));
  page.on("response", async (resp) => {
    const url = resp.url();
    if (url.startsWith(BASE) && !url.includes("/data/live/")) return;
    if (!current) return;
    const rec = { url, status: resp.status(), t: new Date().toISOString() };
    current.net.push(rec);
    try {
      const body = await resp.body();
      const f = `${current.dir}/page_${String(++seq).padStart(3, "0")}_${safe(hostOf(url) + new URL(url).pathname)}.body`;
      writeFileSync(f, body);
      rec.file = f;
      seen.push(rec);
    } catch (e) { rec.bodyError = String(e.message).slice(0, 200); }
  });
  page.on("console", (m) => { if (current && m.type() === "error") current.console.push(m.text()); });
  page.on("pageerror", (e) => { if (current) current.console.push(`pageerror: ${e}`); });

  await page.goto(BASE);
  for (const p of points) {
    const dir = `${OUT}/raw/${p.id}`;
    mkdirSync(dir, { recursive: true });
    current = { point: p, dir, net: [], console: [] };
    mkdirSync(`${dir}/code`, { recursive: true });
    await run("bash", ["-c", `cp -r /home/user/disaster-now/public/js ${dir}/code/ && cd /home/user/disaster-now/public/js && sha256sum *.js > ${dir}/code/sha256.txt`]);
    const nowMs = await page.evaluate(() => Date.now());
    current.pageNowMs = nowMs;
    current.pageNow = new Date(nowMs).toISOString();
    await page.evaluate((h) => { location.hash = h; }, `#p=${p.lat},${p.lon},${encodeURIComponent(p.name)}`);
    // settle: 10 cards and no external request in flight for 5 s (max 75 s)
    const t0 = Date.now();
    let quietSince = Date.now();
    await page.waitForTimeout(1500);
    while (Date.now() - t0 < 75000) {
      const n = await page.locator(".card").count();
      if (inflight.size) quietSince = Date.now();
      if (n >= 10 && Date.now() - quietSince > 5000) break;
      await page.waitForTimeout(500);
    }
    current.settledAfterS = (Date.now() - t0) / 1000;
    current.pendingAtCapture = [...inflight].map((r) => r.url());
    const grab = async () => page.evaluate(() => {
      const tx = (s) => document.querySelector(s)?.innerText ?? null;
      return {
        placeName: tx("#place-name"), placeSub: tx("#place-sub"), verdict: tx("#verdict"), warnings: tx("#warnings"),
        tiles: [...document.querySelectorAll("#tiles .tile")].map((e) => ({ href: e.getAttribute("href"), cls: e.className, text: e.innerText })),
        pre: tx("#pre"),
        cards: [...document.querySelectorAll("#cards .card")].map((e) => ({ id: e.id, cls: e.className, text: e.innerText,
          links: [...e.querySelectorAll("a")].map((a) => ({ href: a.href, text: a.innerText })) })),
        outlook: tx("#outlook"), profile: tx("#profile"), updated: tx("#updated"),
      };
    });
    current.th = await grab();
    await page.click("#lang");
    await page.waitForTimeout(400);
    current.en = await grab();
    await page.click("#lang");
    await page.waitForTimeout(300);
    await page.screenshot({ path: `${dir}/page.png`, fullPage: true });

    // ---- independent fetches, right away ----
    current.cachedFromEarlier = seen.filter((x) => !x.url.startsWith(BASE) && x.t < current.pageNow).map((x) => ({ url: x.url, file: x.file, t: x.t }));
    const shared = /flashflood_report|usgs\.gov|gdacs\.org|jma\.go\.jp|air4thai\.com/;
    const pageUrls = [...new Set([...current.net.filter((x) => !x.url.startsWith(BASE)).map((x) => x.url),
      ...current.cachedFromEarlier.map((x) => x.url).filter((u) => shared.test(u))])];
    const jobs = pageUrls.filter((u) => !/api\.open-meteo\.com\/v1\/elevation/.test(u)); // forecast host is over its daily limit
    current.curlStart = new Date().toISOString();
    const res = await Promise.all([
      ...jobs.map((u, i) => curl(u, `${dir}/curl_${String(i).padStart(2, "0")}_${safe(hostOf(u) + new URL(u).pathname)}.body`)),
      curl("https://air4thai.pcd.go.th/services/getNewAQI_JSON.php", `${dir}/curl_a4t_official.body`, { ca: A4T_CA }),
      curl(`https://flood.autobahn.bot/api/point?lat=${p.lat}&lon=${p.lon}`, `${dir}/curl_fw_point.body`),
      curl("https://flood.autobahn.bot/api/stations", `${dir}/curl_fw_stations.body`),
    ]);
    current.curl = res;
    current.curlEnd = new Date().toISOString();
    writeFileSync(`${dir}/capture.json`, JSON.stringify(current, null, 1));
    console.log(`${p.id}: page ${current.pageNow} settled ${current.settledAfterS}s, ${current.net.length} responses, curl ${res.map((r) => r.code || "ERR").join(",")}`);
  }
  await browser.close();
}
main().catch((e) => { console.error(e); process.exit(1); });
