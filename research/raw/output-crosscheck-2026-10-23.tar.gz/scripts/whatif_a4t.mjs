// What the page's own code (snapshot taken at capture) would have shown had Air4Thai loaded: the same bodies the page
// received, plus the official Air4Thai response fetched with curl seconds later. Only the PM2.5 and other-pollution cards.
import { readFileSync } from "node:fs";
const X = "/tmp/claude-0/-home-user/d0c0b487-5c79-5ab8-a62d-123ead309e6f/scratchpad/xcheck";
const { assess } = await import(`${X}/code-at-capture/js/assess.js`);
const { nearestTambon } = await import(`${X}/code-at-capture/js/geo.js`);
const { IPE } = await import(`${X}/code-at-capture/js/ipe.js`);
const tambon = JSON.parse(readFileSync("/home/user/disaster-now/public/data/tambon.json", "utf8"));
const J = (f) => JSON.parse(readFileSync(f, "utf8").replace(/^﻿/, ""));
for (const pid of ["bkk", "cnx", "hdy", "hkt", "ubn", "msi"]) {
  const cap = J(`${X}/raw/${pid}/capture.json`);
  const all = [...cap.net, ...(cap.cachedFromEarlier || [])].filter((x) => x.file);
  const body = (re) => { const x = all.find((n) => re.test(n.url)); return x ? readFileSync(x.file, "utf8") : null; };
  const js = (re) => { const t = body(re); return t ? JSON.parse(t) : null; };
  const p = { lat: cap.point.lat, lon: cap.point.lon };
  p.place = nearestTambon(tambon, p.lat, p.lon);
  const b = { now: cap.pageNowMs, point: p, errors: {}, ens: js(/ensemble-api/), aq: js(/air-quality-api/), gistda: js(/getPm25byLocation/),
    twRain: js(/rain_24h/), twLevel: js(/waterlevel_load/), hiiFf: body(/flashflood_report/), emsc: js(/seismicportal/), usgs: js(/usgs/),
    gdacs: js(/gdacs/), dmrSlide: js(/VILLLAGE_RISK/), dmrFault: js(/T_ACTIVEFAULT/),
    jma: all.filter((n) => /forecast\.json/.test(n.url)).map((n) => J(n.file)),
    warnings: J("/home/user/disaster-now/public/data/live/warnings.json"), hotspots: J("/home/user/disaster-now/public/data/live/hotspots.json"),
    tmdQuakes: J("/home/user/disaster-now/public/data/live/tmd_quakes.json"), storms: J("/home/user/disaster-now/public/data/live/storms.json"),
    a4t: J(`${X}/raw/${pid}/curl_a4t_official.body`) };
  const r = assess(b, "th", IPE);
  const c = (id) => r.cards.find((x) => x.id === id);
  // and without Air4Thai, as the page had it: must equal the captured page text
  const r0 = assess({ ...b, a4t: null }, "th", IPE);
  const same = ["pm25", "heat", "rain", "flood", "wind", "uv", "quake", "fire", "landslide", "air"].every((id) => {
    const cc = r0.cards.find((x) => x.id === id);
    const pageTxt = cap.th.cards.find((x) => x.id === `card-${id}`).text;
    return (cc.value ? pageTxt.includes(cc.value) : true) && (cc.lines || []).filter(Boolean).every((l) => pageTxt.includes(l));
  });
  console.log(JSON.stringify({ pid, replay_without_a4t_equals_page: same,
    pm25: { word: c("pm25").word, value: c("pm25").value, lines: c("pm25").lines, days: c("pm25").days?.map((d) => d.text), action: c("pm25").action?.text, level: c("pm25").level },
    air: { word: c("air").word, value: c("air").value, lines: c("air").lines, level: c("air").level },
    verdict: { name: r.verdict.name, worst: r.verdict.worst?.id, action: r.verdict.action?.text } }));
}
