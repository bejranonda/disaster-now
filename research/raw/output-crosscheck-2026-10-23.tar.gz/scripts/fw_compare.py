#!/usr/bin/env python3
"""Consistency with FloodWatch: FloodWatch's own /api/point and /api/stations (fetched within seconds of the page) vs the
page's flood and rain tiles, and every ThaiWater gauge's status (FloodWatch's rule, restated in recompute.py) vs the status
FloodWatch itself serves for the same code.  python3 -I fw_compare.py"""
import json, sys, math, collections
sys.path.insert(0, "/tmp/claude-0/-home-user/d0c0b487-5c79-5ab8-a62d-123ead309e6f/scratchpad/xcheck/scripts")
from recompute import X, hav, load_json, find, files_for, num, classify, local_ms, RANK, RIVER_TH, f  # noqa: E402

out = {}
tot = collections.Counter()
diffs = []
for pid in ["bkk", "cnx", "hdy", "hkt", "ubn", "msi"]:
    cap = load_json(f"{X}/raw/{pid}/capture.json")
    res = load_json(f"{X}/results/{pid}.json")
    lat, lon, now = cap["point"]["lat"], cap["point"]["lon"], cap["pageNowMs"]
    fwp = load_json(f"{X}/raw/{pid}/curl_fw_point.body")
    fws = {s["code"]: s for s in load_json(f"{X}/raw/{pid}/curl_fw_stations.body")["stations"]}
    th = cap["th"]
    flood_tile = next(t for t in th["tiles"] if t["href"] == "#card-flood")
    rain_card = next(c for c in th["cards"] if c["id"] == "card-rain")["text"]
    a = fwp["area"]
    mine = res["extra"]["area_mine"]
    page_word = flood_tile["text"].split("\n")[1]
    fw_word = RIVER_TH[RANK[a["category"]]] if a.get("category") else "(none)"
    row = {"fw_area": a, "fw_mode": fwp.get("mode"), "page_word": page_word, "page_area": mine,
           "fw_nearest_canal": (fwp.get("nearest_canal") or {}).get("code"),
           "fw_within8": [(s["code"], s.get("agency"), s["distance_km"], s.get("status"), s.get("stale"), s.get("local"))
                          for s in fwp.get("stations", []) if s["distance_km"] <= 8]}
    row["area_same_category"] = (a.get("category") or None) == (mine.get("category") or None) or (a.get("category") is None and page_word == "ยังรับน้ำได้" and False)
    row["area_same_word"] = fw_word == page_word
    row["area_same_conf"] = a.get("confidence") == mine.get("confidence")
    # measured rain
    rm = fwp.get("rain_measured")
    g = res["extra"]["rain_gauge"]
    row["rain"] = {"fw": rm, "page_gauge": g}
    if rm and g:
        fw_t = datetime_bkk = None
        from datetime import datetime, timezone, timedelta
        fw_local = datetime.fromisoformat(rm["obs_time"]).astimezone(timezone(timedelta(hours=7))).strftime("%Y-%m-%dT%H:%M")
        row["rain_same_gauge"] = rm["name_th"] == g["name"] or rm["code"] == g["code"]
        row["rain_same_value"] = abs(rm["rain_24h"] - g["v"]) < 0.05
        row["rain_same_time"] = fw_local == g["t"]
        row["rain_fw_local_time"] = fw_local
    # every gauge within 20 km: our status vs FloodWatch's for the same code
    gl = []
    for gg in res["extra"]["gauges"]:
        s = fws.get(gg["code"])
        rec = {"code": gg["code"], "name": gg["name"], "km": round(gg["km"], 1), "ours": gg["status"], "stale": gg["stale"],
               "fw": s.get("status") if s else None, "fw_basis": s.get("status_basis") if s else None,
               "level": gg["level"], "fw_level": s.get("level_msl") if s else None, "bank": gg["bank"], "fw_bank": s.get("bank_msl") if s else None,
               "ground": gg["ground"], "fw_ground": s.get("ground_msl") if s else None, "t": gg["t"], "fw_t": s.get("obs_time") if s else None,
               "fw_stale": s.get("stale") if s else None, "fw_pct": s.get("pct_bank") if s else None, "pct": gg["pct"]}
        gl.append(rec)
        if s is None:
            tot["no FloodWatch twin"] += 1
        elif gg["stale"] or s.get("stale") or s.get("status") in (None, "unknown"):
            tot["one side stale/unknown"] += 1
        else:
            tot["compared"] += 1
            if s["status"] == gg["status"]:
                tot["same status"] += 1
            else:
                tot["different status"] += 1
                diffs.append({"point": pid, **rec})
    row["gauges"] = gl
    out[pid] = row

# the whole of the six provinces: every fresh ThaiWater gauge with a FloodWatch twin
prov = collections.Counter()
pdiff = []
seen = set()
for pid in ["bkk", "cnx", "hdy", "hkt", "ubn", "msi"]:
    cap = load_json(f"{X}/raw/{pid}/capture.json")
    now = cap["pageNowMs"]
    fws = {s["code"]: s for s in load_json(f"{X}/raw/{pid}/curl_fw_stations.body")["stations"]}
    wl = load_json(find(files_for(cap, "curl"), r"waterlevel_load"))
    for r in (wl.get("waterlevel_data") or {}).get("data", []):
        st = r.get("station") or {}
        code = st.get("tele_station_oldcode")
        if code in seen:
            continue
        seen.add(code)
        lvl = num(r.get("waterlevel_msl"))
        t = (r.get("waterlevel_datetime") or "").replace(" ", "T")[:16]
        if lvl is None or not t:
            continue
        age = (now - local_ms(t)) / 3.6e6
        if age > 6:
            prov["stale here"] += 1
            continue
        ours, p = classify(lvl, num(st.get("min_bank")), num(st.get("ground_level")) or None)
        s = fws.get(code)
        if not s:
            prov["no twin"] += 1
            continue
        if s.get("stale") or s.get("status") in (None, "unknown") or ours == "unknown":
            prov["unknown on one side"] += 1
            continue
        prov["compared"] += 1
        if s["status"] == ours:
            prov["same"] += 1
        else:
            prov["different"] += 1
            pdiff.append({"code": code, "name": (st.get("tele_station_name") or {}).get("th"), "ours": ours, "fw": s["status"],
                          "basis": s.get("status_basis"), "level": lvl, "fw_level": s.get("level_msl"), "bank": num(st.get("min_bank")),
                          "fw_bank": s.get("bank_msl"), "ground": num(st.get("ground_level")), "fw_ground": s.get("ground_msl"),
                          "t": t, "fw_t": s.get("obs_time"), "pct": p, "fw_pct": s.get("pct_bank")})
res = {"points": out, "near_totals": dict(tot), "near_diffs": diffs, "province_totals": dict(prov), "province_diffs": pdiff}
json.dump(res, open(f"{X}/results/floodwatch.json", "w"), ensure_ascii=False, indent=1, default=str)
for pid, r in out.items():
    a = r["fw_area"]
    print(f"{pid}: FW area {a.get('category')} conf {a.get('confidence')} n={a.get('n')} nearest {a.get('nearest_km')} mode {r['fw_mode']} | "
          f"page {r['page_word']} (mine {r['page_area'].get('category')} conf {r['page_area'].get('confidence')} n={r['page_area'].get('n')}) "
          f"| same word {r['area_same_word']} conf {r['area_same_conf']}")
    print("   FW within 8 km:", r["fw_within8"][:12])
    if r.get("rain"):
        print("   rain:", {k: r.get(k) for k in ("rain_same_gauge", "rain_same_value", "rain_same_time", "rain_fw_local_time")},
              (r["rain"]["fw"] or {}).get("code"), (r["rain"]["page_gauge"] or {}).get("code"), (r["rain"]["page_gauge"] or {}).get("t"))
    for g in r["gauges"]:
        print("   ", g["code"], g["km"], "ours", g["ours"], "fw", g["fw"], g["fw_basis"], "lvl", g["level"], g["fw_level"], "bank", g["bank"], g["fw_bank"],
              "gnd", g["ground"], g["fw_ground"], "t", g["t"], g["fw_t"], "stale", g["stale"], g["fw_stale"])
print("near totals", dict(tot))
for d in diffs:
    print("  DIFF", d)
print("province totals", dict(prov))
for d in pdiff:
    print("  PDIFF", d)
