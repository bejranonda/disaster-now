#!/usr/bin/env python3
"""Output cross-check, step 2: recompute every number the page shows from the sources fetched independently (curl),
with this auditor's own code (not the app's), and compare with the page's text. Run with python3 -I.
  python3 -I recompute.py            → results/<point>.json and results/summary.json
Sources: raw/<pt>/curl_* (independent), raw/<pt>/page_* (what the page itself received, used only to explain a
difference), raw/collector_src/* (TMD CAP, TMD storms/quakes, FIRMS, fetched independently), the collector's files
(public/data/live, what the page read)."""
import csv, io, json, glob, math, re, os, sys
from datetime import datetime, timezone, timedelta
from decimal import Decimal, ROUND_HALF_UP
import numpy as np

X = "/tmp/claude-0/-home-user/d0c0b487-5c79-5ab8-a62d-123ead309e6f/scratchpad/xcheck"
LIVE = "/home/user/disaster-now/public/data/live"
TAMBON = "/home/user/disaster-now/public/data/tambon.json"
BKK = timezone(timedelta(hours=7))
R = 6371.0088

def hav(a, b, c, d):
    p = math.pi / 180
    h = math.sin((c - a) * p / 2) ** 2 + math.cos(a * p) * math.cos(c * p) * math.sin((d - b) * p / 2) ** 2
    return 2 * R * math.asin(min(1, math.sqrt(h)))

def brg(a, b, c, d):
    p = math.pi / 180
    y = math.sin((d - b) * p) * math.cos(c * p)
    x = math.cos(a * p) * math.sin(c * p) - math.sin(a * p) * math.cos(c * p) * math.cos((d - b) * p)
    return (math.degrees(math.atan2(y, x)) + 360) % 360

COMPASS = ["เหนือ", "ตะวันออกเฉียงเหนือ", "ตะวันออก", "ตะวันออกเฉียงใต้", "ใต้", "ตะวันตกเฉียงใต้", "ตะวันตก", "ตะวันตกเฉียงเหนือ"]

def f(v, d=0):
    """The number as a person reads it, rounded half up (JS toFixed), thousands with a comma."""
    if v is None or (isinstance(v, float) and math.isnan(v)):
        return "–"
    q = Decimal(repr(float(v))).quantize(Decimal(1).scaleb(-d), rounding=ROUND_HALF_UP)
    s = f"{q:,.{d}f}" if abs(q) >= 1000 else f"{q:.{d}f}"
    return s

def local_ms(s):  # "YYYY-MM-DDTHH:MM" Bangkok
    return datetime.strptime(s[:16], "%Y-%m-%dT%H:%M").replace(tzinfo=BKK).timestamp() * 1000

def loc_of(ms):
    return datetime.fromtimestamp(ms / 1000, BKK).strftime("%Y-%m-%dT%H:%M")

MONTH_TH = ["ม.ค.", "ก.พ.", "มี.ค.", "เม.ย.", "พ.ค.", "มิ.ย.", "ก.ค.", "ส.ค.", "ก.ย.", "ต.ค.", "พ.ย.", "ธ.ค."]
def time_th(local, now_ms):
    today = loc_of(now_ms)[:10]
    hm = local[11:16]
    y, m, d = map(int, local[:10].split("-"))
    return f"{hm} น. วันนี้" if local[:10] == today else f"{hm} น. {d} {MONTH_TH[m - 1]}"

# ---------- official bands, written from the sources (thresholds doc), not from levels.js ----------
HEAT = [(-1e9, 0, "ปกติ"), (27.0, 1, "เฝ้าระวัง"), (33.0, 2, "เตือนภัย"), (42.0, 3, "อันตราย"), (52.0, 3, "อันตรายมาก")]  # DOH/TMD 2024
PM25 = [(-1e9, 0, "ดีมาก"), (15.1, 0, "ดี"), (25.1, 1, "ปานกลาง"), (37.6, 2, "เริ่มมีผลกระทบต่อสุขภาพ"), (75.1, 3, "มีผลกระทบต่อสุขภาพ")]  # PCD 2566
AQI = [(-1e9, 0, "ดีมาก"), (26, 0, "ดี"), (51, 1, "ปานกลาง"), (101, 2, "เริ่มมีผลกระทบต่อสุขภาพ"), (201, 3, "มีผลกระทบต่อสุขภาพ")]
UV = [(-1e9, 0, "ต่ำ"), (3, 1, "ปานกลาง"), (6, 1, "สูง"), (8, 2, "สูงมาก"), (11, 3, "สูงที่สุด")]  # WHO; grouping per thresholds doc
RAIN = [(-1e9, 0, "ไม่มีฝน"), (0.1, 0, "ฝนเล็กน้อย"), (10.1, 1, "ฝนปานกลาง"), (35.1, 2, "ฝนหนัก"), (90.1, 3, "ฝนหนักมาก")]  # TMD
# TMD's Beaufort words (เกณฑ์อากาศ p.2), km/h; grouping into levels per thresholds doc (watch 39–61, warning 62–88, danger ≥ 89)
GUST = [(-1e9, 0, "ลมสงบถึงลมโชย"), (20, 0, "ลมปานกลาง"), (29, 0, "ลมแรง"), (39, 1, "ลมจัด"), (50, 1, "พายุเกลอ่อน"),
        (62, 2, "พายุเกล"), (75, 2, "พายุเกลแรง"), (89, 3, "พายุ"), (103, 3, "พายุใหญ่"), (118, 3, "ระดับไต้ฝุ่น")]
MMI = [(-1e9, 0, "ไม่น่ารู้สึก"), (3.0, 1, "อาจรู้สึกได้เบา ๆ"), (5.0, 2, "สั่นปานกลาง ของอาจตก"), (6.0, 3, "สั่นแรง อาจเสียหาย")]
STEP = {"heat": 0.1, "pm25": 0.1, "aqi": 1, "uv": 1, "rain": 0.1, "gust": 1, "mmi": 0.1}
TABLE = {"heat": HEAT, "pm25": PM25, "aqi": AQI, "uv": UV, "rain": RAIN, "gust": GUST, "mmi": MMI}

def band(kind, v):
    if v is None:
        return (-1, "ไม่มีข้อมูล")
    st = STEP[kind]
    vr = float(Decimal(repr(float(v))).quantize(Decimal(str(st)), rounding=ROUND_HALF_UP))
    hit = TABLE[kind][0]
    for b in TABLE[kind]:
        if vr >= b[0]:
            hit = b
    return (hit[1], hit[2])

def chance(vals, thr):
    vals = [v for v in vals if v is not None]
    return sum(1 for v in vals if v >= thr) / len(vals) if vals else None

def chance_text(p):
    if p is None:
        return ""
    if p < 0.1:
        return "ไม่ถึง 10%"
    if p > 0.9:
        return "เกิน 90%"
    return f"{int(Decimal(repr(p * 10)).quantize(Decimal(1), rounding=ROUND_HALF_UP)) * 10}%"

def level_from(vals, kind):
    """The documented ensemble rule: the highest level ≥ 50 % of members reach; warning-or-worse at ≥ 20 % lifts to watch."""
    mins = {}
    for lo, lv, _ in TABLE[kind]:
        if lv >= 1 and lv not in mins:
            mins[lv] = lo
    likely = max([lv for lv, lo in mins.items() if chance(vals, lo) >= 0.5] or [0])
    possible = max([lv for lv, lo in mins.items() if chance(vals, lo) >= 0.2] or [0])
    return 1 if possible >= 2 and likely < 1 else likely

# ---------- NWS heat index (wpc.ncep.noaa.gov/html/heatindex_equation.shtml) ----------
def hi_f(T, RH):
    simple = 0.5 * (T + 61.0 + (T - 68.0) * 1.2 + RH * 0.094)
    rot = (-42.379 + 2.04901523 * T + 10.14333127 * RH - .22475541 * T * RH - .00683783 * T * T - .05481717 * RH * RH
           + .00122874 * T * T * RH + .00085282 * T * RH * RH - .00000199 * T * T * RH * RH)
    adj_dry = ((13 - RH) / 4) * np.sqrt(np.clip((17 - np.abs(T - 95.)) / 17, 0, None))
    adj_wet = ((RH - 85) / 10) * ((87 - T) / 5)
    rot = np.where((RH < 13) & (T >= 80) & (T <= 112), rot - adj_dry, rot)
    rot = np.where((RH > 85) & (T >= 80) & (T <= 87), rot + adj_wet, rot)
    return np.where((simple + T) / 2 < 80, simple, rot)

def heat_index_c(tc, rh):
    tf = tc * 9 / 5 + 32
    return (hi_f(tf, np.clip(rh, 0, 100)) - 32) * 5 / 9

def members(h, var):
    keys = [var] + [f"{var}_member{i:02d}" for i in range(1, 100) if f"{var}_member{i:02d}" in h]
    return np.array([[np.nan if v is None else v for v in h[k]] for k in keys], dtype=float)

def pct(vals):
    v = np.array([x for x in vals if x is not None and not np.isnan(x)])
    return [float(np.percentile(v, q)) for q in (10, 50, 90)] if len(v) else [None] * 3

def permember(arr, i0, i1, how):
    out = []
    for row in arr:
        seg = row[i0:i1]
        seg = seg[~np.isnan(seg)]
        if len(seg):
            out.append(float(seg.sum() if how == "sum" else seg.max()))
    return out

def day_windows(times, i0, n=3):
    out, i = [], max(0, i0)
    while i < len(times) and len(out) < n:
        d = times[i][:10]
        j = i
        while j < len(times) and times[j][:10] == d:
            j += 1
        out.append((d, i, j))
        i = j
    return out

def now_index(times, now_ms):
    idx = -1
    for i, t in enumerate(times):
        if local_ms(t) <= now_ms:
            idx = i
    return idx

# ---------- AWW 2012 hypocentral (thresholds doc §8.4) ----------
def mmi_aww12(M, rhypo):
    rm = -0.209 + 2.042 * math.exp(M - 5)
    v = 2.085 + 1.428 * M - 1.402 * math.log(math.sqrt(rhypo ** 2 + rm ** 2))
    if rhypo > 50:
        v += 0.078 * math.log(rhypo / 50)
    return v

def num(v):
    try:
        return None if v is None or v == "" else float(v)
    except ValueError:
        return None

def load_json(p):
    with open(p, encoding="utf-8-sig") as fh:
        return json.load(fh)

def classify(level, bank, ground):
    """FloodWatch classify_status (forecast/__init__.py), restated."""
    if level is None or bank is None:
        return "unknown", None
    p = (level - ground) / (bank - ground) * 100 if ground is not None and bank > ground else None
    if level >= bank:
        return "critical", p
    if p is None:
        return ("warning" if bank - level < 0.3 else "normal"), p
    if p >= 90:
        return "warning", p
    if p >= 70:
        return "watch", p
    return "normal", p

RANK = {"normal": 0, "watch": 1, "warning": 2, "critical": 3}
LEVELS = ["normal", "watch", "warning", "critical"]
RIVER_TH = ["ยังรับน้ำได้", "เฝ้าระวัง", "ใกล้ล้นตลิ่ง", "ล้นตลิ่ง"]  # FloodWatch web/app.js STATUS words
POLDER = [10, 11, 12, 13, 73, 74]
WORDS = [("แม่น้ำ", "แม่น้ำ"), ("แคว", "แม่น้ำ"), ("น้ำ", "แม่น้ำ"), ("คลอง", "คลอง"), ("คู", "คลอง"), ("ลำ", "ลำน้ำ"),
         ("ห้วย", "ลำน้ำ"), ("เหมือง", "ลำน้ำ"), ("ร่อง", "ลำน้ำ"), ("บึง", "บึง")]

def water_word(river, polder):
    r = (river or "").strip()
    for p, w in WORDS:
        if r.startswith(p):
            return w
    return "คลอง" if polder else "ลำน้ำ"

def area_index(gauges, polder):
    """FloodWatch point.area_index (RADIUS 8, NEAR 3, CHECK 5), restated, on (km, status) pairs."""
    near = sorted([g for g in gauges if not g["stale"] and g["status"] in RANK and g["km"] <= 8.0
                   and (not polder or water_word(g["river"], polder) in ("คลอง", "บึง"))], key=lambda g: g["km"])
    if not near:
        return {"category": None, "confidence": "none", "n": 0}
    close = [g for g in near if g["km"] <= 3.0][:3]
    basis = close or near
    w = [1 / max(g["km"], 0.3) ** 2 for g in basis]
    score = sum(wi * RANK[g["status"]] for wi, g in zip(w, basis)) / sum(w)
    ranks = [RANK[g["status"]] for g in basis]
    spread = max(ranks) - min(ranks)
    outvoted = bool(close) and any(3.0 < g["km"] <= 5.0 and abs(RANK[g["status"]] - RANK[close[0]["status"]]) >= 2 for g in near)
    if len(close) >= 2 and spread <= 1:
        conf = "medium"
    elif close and spread <= 1 and not outvoted:
        conf = "low"
    elif not close and near[0]["km"] <= 5.0 and len(near) >= 2 and spread <= 1:
        conf = "low"
    else:
        conf = "very_low"
    cat = min(3, int(Decimal(repr(score)).quantize(Decimal(1), rounding=ROUND_HALF_UP)))
    return {"category": LEVELS[cat], "score": score, "confidence": conf, "n": len(near), "n_close": len(close),
            "nearest_km": near[0]["km"], "basis": [g["code"] for g in basis]}

# ------------------------------------------------------------------------------------------------------------------
RETRIED = {l.split()[1]: l.split()[2] for l in open(f"{X}/retry.txt") if l.startswith(("hdy ", "msi "))}  # file → url, re-fetched 20:37–20:47

def files_for(cap, prefix):
    by = {}
    for r in cap.get(prefix, []):
        ok = r.get("code") == 200 or (r.get("file") in RETRIED and os.path.getsize(r["file"]) > 1000)
        if r.get("file") and ok:
            by[r["url"]] = r["file"]
    return by

def same_or_tie(page_txt, x, d=0):
    """True when the page's rounded number equals ours, or differs only because x sits on a .5 tie (float sums)."""
    if page_txt == f(x, d):
        return True
    frac = abs(x * 10 ** d - math.floor(x * 10 ** d) - 0.5)
    return frac < 1e-6 and page_txt in (f(x - 1e-6, d), f(x + 1e-6, d))

def find(by, pat):
    for u, fp in by.items():
        if re.search(pat, u):
            return fp
    return None

def run(pid):
    cap = load_json(f"{X}/raw/{pid}/capture.json")
    P = cap["point"]
    lat, lon = P["lat"], P["lon"]
    now = cap["pageNowMs"]
    th = cap["th"]
    cards = {c["id"].replace("card-", ""): c["text"] for c in th["cards"]}
    tiles = {t["href"].replace("#card-", ""): t for t in th["tiles"]}
    curl = files_for(cap, "curl")
    page = {x["url"]: x["file"] for x in cap["net"] if x.get("file")}
    page.update({x["url"]: x["file"] for x in cap.get("cachedFromEarlier", []) if x.get("file")})
    rows = []
    out = {"point": P, "pageNow": cap["pageNow"], "curlStart": cap["curlStart"], "rows": rows, "extra": {}}

    def row(item, page_shows, source_says, mine, ok, note=""):
        rows.append({"item": item, "page": page_shows, "source": source_says, "mine": mine,
                     "match": ok if isinstance(ok, str) else ("✅" if ok else "❌"), "note": note})

    def has(text, s):
        return s in text

    # ---------------- place ----------------
    tb = load_json(TAMBON)
    best = min(tb["t"], key=lambda r: hav(lat, lon, r[3], r[4]))
    code = best[0]
    pv = code // 10000
    ap = tb["a"].get(str(code // 100), ["", ""])
    pvn = tb["p"].get(str(pv), ["", ""])
    g_src = load_json(find(curl, r"getPm25byLocation"))
    gl = g_src["data"].get("loc") or {}
    label = (f"แขวง{best[1]} เขต{ap[0]} {pvn[0]}" if pv == 10 else f"ต.{best[1]} อ.{ap[0]} จ.{pvn[0]}")
    row("Subdistrict (nearest centroid, HDX table)", th["placeSub"].split(" · ")[0], f"GISTDA reverse lookup of the rounded point: {gl.get('tb_tn')} ({gl.get('tb_idn')})",
        f"{label} ({code}, {hav(lat, lon, best[3], best[4]):.1f} km to centroid)",
        ("✅" if gl.get("tb_idn") == code else "⚠️") if has(th["placeSub"], label) else "❌",
        "" if gl.get("tb_idn") == code else "page = nearest centroid (worded 'ใกล้'); GISTDA's polygon lookup (of 18.79, 98.99) names the neighbour")
    out["extra"]["tambon"] = {"code": code, "pv": pv, "label": label, "gistda_tb": gl.get("tb_idn")}

    # ---------------- ensemble: heat, rain, gust ----------------
    ens_f = find(curl, r"ensemble-api")
    ens_src = "curl"
    if not ens_f:
        ens_f = find(page, r"ensemble-api")
        ens_src = "page-only (curl failed 3×)"
    e = load_json(ens_f)
    h = e["hourly"]
    times = h["time"]
    i0 = now_index(times, now)
    i1 = min(i0 + 24, len(times))
    T = members(h, "temperature_2m")
    RH = members(h, "relative_humidity_2m")
    HI = heat_index_c(T, RH)
    PR = members(h, "precipitation")
    GU = members(h, "wind_gusts_10m")
    n = T.shape[0]
    hmax = permember(HI, i0, i1, "max")
    p10, p50, p90 = pct(hmax)
    tmax = pct(permember(T, i0, i1, "max"))[1]
    hnow = float(np.nanmedian(HI[:, i0]))
    lv_heat = max(band("heat", p50)[0], level_from(hmax, "heat"))
    days = day_windows(times, i0)
    heat_days = [pct(permember(HI, a, b, "max"))[1] for _, a, b in days]
    c = cards.get("heat", "")
    t_ = tiles["heat"]["text"]
    out["extra"]["ens"] = {"file": ens_f, "source": ens_src, "members": n, "i0": times[i0], "elevation": e.get("elevation")}
    row("Heat: value (median member's 24-h peak heat index)", re.search(r"(\d+) °C", t_).group(0), f"{n} members, T & RH hourly",
        f"{f(p50)} °C (p50 = {p50:.2f})", f"{f(p50)} °C" in t_)
    row("Heat: band word", t_.split("\n")[1], "DOH/TMD 2024 bands", band("heat", p50)[1], band("heat", p50)[1] in t_)
    row("Heat: range p10–p90", re.search(r"ราว (\S+) °C", c).group(1), "", f"{f(p10)}–{f(p90)}", f"ราว {f(p10)}–{f(p90)} °C" in c)
    row("Heat: air temp peak p50", re.search(r"อุณหภูมิอากาศสูงสุดราว (\d+)", c).group(1), "", f(tmax), f"สูงสุดราว {f(tmax)} °C" in c)
    row("Heat: feels like now (median at this hour)", re.search(r"ตอนนี้รู้สึกราว (\d+)", c).group(1), f"hour {times[i0]}", f(hnow),
        f"ตอนนี้รู้สึกราว {f(hnow)} °C" in c)
    row("Heat: 3 days (p50 of daily peaks)", " ".join(re.findall(r"\n(\d+)°", c)), "", " ".join(f(x) for x in heat_days),
        all(f"{f(x)}°" in c for x in heat_days))
    ch42 = chance(hmax, 42.0)
    row("Heat: chance ≥ 42 °C line", "shown" if "โอกาสถึงระดับอันตราย" in c else "not shown", "", f"{ch42:.2f} → {'shown' if ch42 >= 0.1 else 'not shown'}",
        ("โอกาสถึงระดับอันตราย" in c) == (ch42 >= 0.1))
    row("Heat: tile level", tiles["heat"]["cls"].split("lv-")[1], "", ["ok", "watch", "warn", "danger"][lv_heat],
        tiles["heat"]["cls"].endswith(["ok", "watch", "warn", "danger"][lv_heat]))
    row("Heat: model time", re.search(r"ECMWF 51 ชุด · ([^|]+?) แบบจำลอง", c).group(1).strip(), f"hourly.time[{i0}] = {times[i0]}", time_th(times[i0], now),
        time_th(times[i0], now) in c)

    rsum = permember(PR, i0, i1, "sum")
    r10, r50, r90 = pct(rsum)
    ch35 = chance(rsum, 35.1)
    rc = cards.get("rain", "")
    rt = tiles["rain"]["text"]
    pr50 = re.search(r"น่าจะ (\d+) มม", rc).group(1)
    row("Rain fcst: 24-h median", pr50, "51 members, hourly precipitation summed", f"{f(r50)} (p50 = {r50:.4f})",
        "✅" if f(r50) == pr50 and f"{f(r50)} มม." in rt else "✅ (.5 tie)" if same_or_tie(pr50, r50) else "❌",
        "" if f(r50) == pr50 else "an exact .5: the float sum lands either side (rounding only)")
    prr = re.search(r"ช่วง (\S+) มม", rc).group(1).split("–")
    row("Rain fcst: range p10–p90", "–".join(prr), "", f"{f(r10)}–{f(r90)} ({r10:.4f}–{r90:.4f})",
        "✅" if prr == [f(r10), f(r90)] else "✅ (.5 tie)" if same_or_tie(prr[0], r10) and same_or_tie(prr[1], r90) else "❌",
        "" if prr == [f(r10), f(r90)] else "an exact .5: rounding only")
    row("Rain fcst: chance > 35 mm", re.search(r"\(> 35 มม\.\) (\S+(?: \S+)?)\n", rc).group(1), "", f"{ch35:.3f} → {chance_text(ch35)}",
        f"(> 35 มม.) {chance_text(ch35)}" in rc)
    row("Rain fcst: TMD word (of the median)", rt.split("\n")[1], "TMD เกณฑ์ปริมาณฝน", band("rain", r50)[1], band("rain", r50)[1] in rt)
    rain_days = []
    for d, a, b in days:
        s = permember(PR, a, b, "sum")
        rain_days.append((f(pct(s)[1]), chance(s, 35.1)))
    ol = th["outlook"]
    row("Rain fcst: 3 days (p50) in the table", " ".join(re.findall(r"(\d+) มม\.", ol)), "", " ".join(x for x, _ in rain_days),
        re.findall(r"(\d+) มม\.", ol) == [x for x, _ in rain_days])

    gmax = permember(GU, i0, i1, "max")
    g10, g50, g90 = pct(gmax)
    wc = cards.get("wind", "")
    wt = tiles["wind"]["text"]
    row("Gust: 24-h median of member peaks", re.search(r"(\d+) กม\./ชม\.", wt).group(1), "51 members wind_gusts_10m", f"{f(g50)} (p50 = {g50:.2f})",
        f"{f(g50)} กม./ชม." in wt)
    row("Gust: word (TMD Beaufort)", wt.split("\n")[1], "TMD เกณฑ์อากาศ p.2", band("gust", g50)[1], band("gust", g50)[1] in wt)
    row("Gust: range p10–p90", re.search(r"ราว (\S+) กม\./ชม\.", wc).group(1), "", f"{f(g10)}–{f(g90)}", f"ราว {f(g10)}–{f(g90)} กม./ชม." in wc)
    gdays = [f(pct(permember(GU, a, b, "max"))[1]) for _, a, b in days]
    row("Gust: 3 days", " ".join(re.findall(r"ลมกระโชก\t(\d+)\t(\d+)\t(\d+)", ol)[0]), "", " ".join(gdays),
        list(re.findall(r"ลมกระโชก\t(\d+)\t(\d+)\t(\d+)", ol)[0]) == gdays)
    out["extra"]["levels"] = {"heat": lv_heat}

    # ---------------- CAMS: pollutants, UV, PM outlook ----------------
    aq = load_json(find(curl, r"air-quality-api"))
    ah = aq["hourly"]
    ai = now_index(ah["time"], now)
    pol = {k: ah[k][ai] for k in ["pm10", "ozone", "nitrogen_dioxide", "sulphur_dioxide", "carbon_monoxide"]}
    ac = cards.get("air", "")
    want = f"PM10 {f(pol['pm10'])} · O₃ {f(pol['ozone'])} · NO₂ {f(pol['nitrogen_dioxide'])} · SO₂ {f(pol['sulphur_dioxide'])} · CO {f(pol['carbon_monoxide'])}"
    got = re.search(r"PM10 .*", ac)
    row("Other pollution (CAMS at this hour, µg/m³)", got.group(0) if got else "–", f"CAMS hour {ah['time'][ai]}", want, bool(got) and got.group(0) == want)
    hour = int(loc_of(now)[11:13])
    uvnow = ah["uv_index"][ai]
    start = next(i for i, t in enumerate(ah["time"]) if t[:10] == ah["time"][ai][:10])
    uvd = [(d, max(v for v in ah["uv_index"][a:b] if v is not None)) for d, a, b in day_windows(ah["time"], start)]
    uc = cards.get("uv", "")
    ut = tiles["uv"]["text"]
    is_day = 6 <= hour < 18
    row("UV now", ut.split("\n")[1], f"CAMS uv_index at {ah['time'][ai]} = {uvnow}", "กลางคืน" if not is_day else band("uv", uvnow)[1],
        ("กลางคืน" in ut) == (not is_day))
    row("UV tile value", ut.split("\n")[2], f"daily max: " + ", ".join(f"{d} {v}" for d, v in uvd),
        f"next daylight is today ({uvd[0][0]}): peak {f(uvd[0][1])}" if hour < 6 else f"tomorrow {f(uvd[1][1])}",
        f"พรุ่งนี้สูงสุด {f(uvd[1][1])}" in ut and hour >= 6 or (hour < 6 and f"วันนี้สูงสุด {f(uvd[0][1])}" in ut),
        "at 03:3x the next sun is today's, but the tile says 'tomorrow' (assess.js: c.value = day ? … : `พรุ่งนี้สูงสุด ${air.uv[1]?.max}`)" if hour < 6 else "")
    row("UV: today's peak line + word", re.search(r"สูงสุดวันนี้ราว (\d+) \(([^)]+)\)", uc).group(0) if re.search(r"สูงสุดวันนี้ราว", uc) else "–", "",
        f"สูงสุดวันนี้ราว {f(uvd[0][1])} ({band('uv', uvd[0][1])[1]})", f"สูงสุดวันนี้ราว {f(uvd[0][1])} ({band('uv', uvd[0][1])[1]})" in uc)
    row("UV: 3 days", " ".join(re.findall(r"UV\t(\d+)\t(\d+)\t(\d+)", ol)[0]), "", " ".join(f(v) for _, v in uvd),
        list(re.findall(r"UV\t(\d+)\t(\d+)\t(\d+)", ol)[0]) == [f(v) for _, v in uvd])

    # GISTDA
    gd = g_src["data"]
    hist = [(v, str(t)[:16]) for v, t in gd["graphHistory24hrs"] if v is not None and v >= 0]
    m24 = gd.get("pm25Avg24hrs")
    pc = cards.get("pm25", "")
    pt = tiles["pm25"]["text"]
    row("PM2.5 (GISTDA 24-h estimate)", re.search(r"([\d.]+) µg", pt).group(1), f"pm25Avg24hrs = {m24:.3f}; pm25 now = {gd['pm25']:.2f}",
        f"{f(m24, 1)} ({band('pm25', m24)[1]})", f"{f(m24, 1)} µg/m³" in pt and band("pm25", m24)[1] in pt)
    row("PM2.5 GISTDA time", re.search(r"GISTDA · (.+?) แบบจำลอง", pc).group(1), f"last graph hour {hist[-1][1]} (Thai time per datetimeThai '{gd['datetimeThai']['timeThai']}')",
        time_th(hist[-1][1], now), time_th(hist[-1][1], now) in pc)
    idx = {t[:13]: i for i, t in enumerate(ah["time"])}
    obs = mod = 0.0
    k = 0
    for v, t in hist:
        i = idx.get(t[:13])
        if i is None or ah["pm2_5"][i] is None:
            continue
        obs += v; mod += ah["pm2_5"][i]; k += 1
    ratio = min(3, max(0.5, obs / mod)) if k >= 12 and mod > 0 else 1
    pmd = []
    for d, a, b in day_windows(ah["time"], ai):
        vals = [x for x in ah["pm2_5"][a:b] if x is not None]
        pmd.append(sum(vals) / len(vals) * ratio)
    row("PM2.5 3 days (CAMS daily mean × GISTDA/CAMS ratio)", " ".join(re.findall(r"PM2\.5\t(\d+)\t(\d+)\t(\d+)", ol)[0]),
        f"ratio over {k} h = {obs / mod:.3f} → {ratio:.3f}", " ".join(f(x) for x in pmd),
        list(re.findall(r"PM2\.5\t(\d+)\t(\d+)\t(\d+)", ol)[0]) == [f(x) for x in pmd])
    out["extra"]["pm_outlook"] = [(f(x), band("pm25", x)) for x in pmd]

    # Air4Thai official (the page could not read its mirror)
    a4 = load_json(f"{X}/raw/{pid}/curl_a4t_official.body")
    sts = []
    for s in a4["stations"]:
        a = s.get("AQILast") or {}
        if not a.get("date") or not a.get("time"):
            continue
        age = (now - local_ms(f"{a['date']}T{a['time']}")) / 3.6e6
        val = lambda kk: (None if num((a.get(kk) or {}).get("value")) is None or num(a[kk]["value"]) < 0 else num(a[kk]["value"]))
        sub = {kk: num((a.get(kk) or {}).get("aqi")) for kk in ["PM10", "O3", "CO", "NO2", "SO2"]}
        sub = {kk: v for kk, v in sub.items() if v is not None and v >= 0}
        sts.append({"id": s["stationID"], "name": s["nameTH"], "km": hav(lat, lon, float(s["lat"]), float(s["long"])), "age": age,
                    "pm25": val("PM25"), "time": f"{a['date']} {a['time']}", "sub": sub})
    fresh = [s for s in sts if -1 <= s["age"] <= 3]
    st = min([s for s in fresh if s["pm25"] is not None and s["km"] <= 15], key=lambda s: s["km"], default=None)
    near_any = min(sts, key=lambda s: s["km"])
    row("PM2.5 'no PCD station within 15 km' (claim)", "ไม่มีสถานีวัดของ คพ. ในรัศมี 15 กม." if "ไม่มีสถานีวัดของ คพ." in pc else "–",
        f"Air4Thai official: {len(a4['stations'])} stations; nearest {near_any['id']} {near_any['name']} {near_any['km']:.1f} km, {near_any['time']}",
        (f"station {st['id']} {st['name']} {st['km']:.1f} km, 24-h mean {st['pm25']} ({band('pm25', st['pm25'])[1]}) at {st['time']}" if st else "no fresh station ≤ 15 km"),
        ("ไม่มีสถานีวัดของ คพ." in pc) == (st is None),
        "the page never got Air4Thai (air4thai.com: ERR_CERT_AUTHORITY_INVALID) and words the failure as 'no station'" if st else "")
    st2 = min([s for s in fresh if s["sub"] and s["km"] <= 15], key=lambda s: s["km"], default=None)
    if st2:
        kk, vv = max(st2["sub"].items(), key=lambda x: x[1])
        row("Other pollution: PCD station (should lead)", "CAMS values, 'ไม่มีสถานีวัดใกล้ ๆ'", f"{st2['id']} {st2['name']} {st2['km']:.1f} km {st2['time']}: {st2['sub']}",
            f"AQI {f(vv)} ({kk}) → {band('aqi', vv)[1]}", False, "Air4Thai unreadable in the page; the card says there is no station nearby")
    else:
        row("Other pollution: PCD station", "CAMS values", "no fresh non-PM2.5 station ≤ 15 km", "CAMS is the right fallback", "✅")
    out["extra"]["a4t"] = {"station": st, "station_other": st2, "nearest_any": near_any}
    pm_level_should = band("pm25", st["pm25"])[0] if st else band("pm25", m24)[0]
    out["extra"]["levels"]["pm25_shown"] = band("pm25", m24)[0]
    out["extra"]["levels"]["pm25_if_station"] = pm_level_should

    # ---------------- ThaiWater rain gauges ----------------
    rw = load_json(find(curl, r"rain_24h"))
    rg = []
    for r in rw.get("data", []):
        s = r.get("station") or {}
        la, lo, v = num(s.get("tele_station_lat")), num(s.get("tele_station_long")), num(r.get("rain_24h"))
        if la is None or lo is None or v is None or v >= 999990 or v < 0 or not r.get("rainfall_datetime"):
            continue
        t = r["rainfall_datetime"].replace(" ", "T")[:16]
        age = (now - local_ms(t)) / 3.6e6
        d = hav(lat, lon, la, lo)
        if -1 <= age <= 3 and d <= 10:
            rg.append({"code": s.get("tele_station_oldcode"), "name": (s.get("tele_station_name") or {}).get("th"), "km": d, "v": v, "t": t, "age": age})
    rg.sort(key=lambda x: x["km"])
    m = re.search(r"วัดได้ ([\d.]+) มม\. ใน 24 ชม\. ที่ผ่านมา ที่(.+?) \(ห่าง ([\d.]+) กม\.\)", rc)
    if rg:
        g = rg[0]
        want = f"วัดได้ {f(g['v'], 1)} มม. ใน 24 ชม. ที่ผ่านมา ที่{g['name']} (ห่าง {f(g['km'], 1)} กม.)"
        row("Rain measured (nearest gauge ≤ 10 km, ≤ 3 h)", m.group(0) if m else "–", f"ThaiWater rain_24h {g['code']} {g['t']}", want, bool(m) and m.group(0) == want)
        row("Rain gauge time", re.search(r"สถานีวัดฝน \(คลังข้อมูลน้ำแห่งชาติ\) · (.+?น\. [^|⏱]+)", rc).group(1).strip(), g["t"], time_th(g["t"], now), time_th(g["t"], now) in rc)
    else:
        row("Rain measured", m.group(0) if m else "none", "ThaiWater", "no gauge ≤ 10 km/≤ 3 h", not m)
    out["extra"]["rain_gauge"] = rg[0] if rg else None
    lv_obs = band("rain", rg[0]["v"])[0] if rg else -1
    lv_rain = max(lv_obs, level_from(rsum, "rain"))
    row("Rain tile level", tiles["rain"]["cls"].split("lv-")[1], "", ["ok", "watch", "warn", "danger"][lv_rain],
        tiles["rain"]["cls"].endswith(["ok", "watch", "warn", "danger"][lv_rain]))
    out["extra"]["levels"]["rain"] = lv_rain

    # ---------------- ThaiWater water levels ----------------
    wl = load_json(find(curl, r"waterlevel_load"))
    gauges = []
    for r in (wl.get("waterlevel_data") or {}).get("data", []):
        s = r.get("station") or {}
        la, lo, lvl = num(s.get("tele_station_lat")), num(s.get("tele_station_long")), num(r.get("waterlevel_msl"))
        if la is None or lo is None or lvl is None or lvl >= 999990 or lvl < -999:
            continue
        d = hav(lat, lon, la, lo)
        if d > 20:
            continue
        t = (r.get("waterlevel_datetime") or "").replace(" ", "T")[:16]
        age = (now - local_ms(t)) / 3.6e6 if t else None
        bank = num(s.get("min_bank"))
        ground = num(s.get("ground_level")) or None
        stt, p = classify(lvl, bank, ground) if age is not None and age <= 6 else ("unknown", None)
        gauges.append({"code": s.get("tele_station_oldcode"), "name": (s.get("tele_station_name") or {}).get("th"), "km": d, "level": lvl, "bank": bank,
                       "ground": ground, "status": stt, "pct": p, "t": t, "age": age, "stale": age is None or age > 6,
                       "river": r.get("river_name") or ((r.get("basin") or {}).get("basin_name") or {}).get("th"),
                       "fb": None if bank is None else bank - lvl, "situation": r.get("situation_level")})
    gauges.sort(key=lambda g: g["km"])
    fresh_g = [g for g in gauges if not g["stale"]]
    polder = pv in POLDER
    ai_ = area_index(fresh_g, polder)
    fc = cards.get("flood", "")
    ft = tiles["flood"]["text"]
    out["extra"]["gauges"] = gauges
    out["extra"]["area_mine"] = ai_
    for g in fresh_g[:3]:
        fbtxt = "ไม่มีระดับตลิ่ง" if g["fb"] is None else (f"ต่ำกว่าตลิ่ง {f(g['fb'] * 100)} ซม." if g["fb"] >= 0 else f"สูงกว่าตลิ่ง {f(-g['fb'] * 100)} ซม.")
        riv = f" ({g['river']})" if g["river"] else ""
        want = f"{g['name']}{riv} ห่าง {f(g['km'], 1)} กม.: {fbtxt}"
        stw = RIVER_TH[RANK[g["status"]]] if g["status"] in RANK else ""
        line = next((l for l in fc.split("\n") if l.startswith(g["name"])), "–")
        row(f"Gauge {g['code']}", line, f"ThaiWater {g['t']}: level {g['level']} m MSL, min_bank {g['bank']}, ground {g['ground']}"
            + (f", situation_level {g['situation']}" if g['situation'] else ""),
            f"{want} · {stw}" + (f" (pct {g['pct']:.0f} %)" if g["pct"] is not None else ""), line.startswith(f"{want} · {stw}"))
    if ai_["category"] is None:
        want_line = "ไม่มีสถานีวัดระดับน้ำที่ส่งข้อมูลในรัศมี 8 กม." if not polder else "ไม่มีสถานีวัดน้ำในคลองที่ส่งข้อมูลในรัศมี 8 กม."
        row("Flood area line", next((l for l in fc.split("\n") if "8 กม." in l), "–"), "", want_line, want_line in fc)
        row("Flood tile word/level with NO gauge ≤ 8 km", f"{ft.split(chr(10))[1]} · lv-{tiles['flood']['cls'].split('lv-')[1]}", "",
            "no area category: should read as unknown / no gauge, not calm", False,
            "assess.js: c.level = ai.category ?? 0 and c.word = RIVER_WORDS[c.level] → 'ยังรับน้ำได้' from no data (rule: missing data is never calm)")
    else:
        conf = {"medium": "ปานกลาง", "low": "ต่ำ", "very_low": "ต่ำมาก"}[ai_["confidence"]]
        nb = len(ai_["basis"])
        want_line = f"ภาพรวมทางน้ำรอบจุดนี้: {RIVER_TH[RANK[ai_['category']]]} (จาก {nb} สถานี ใกล้สุด {f(ai_['nearest_km'], 1)} กม. · ความมั่นใจ{conf})"
        row("Flood area category (FloodWatch rule on ThaiWater gauges)", next((l for l in fc.split("\n") if l.startswith("ภาพรวม")), "–"), "", want_line, want_line in fc)
    if fresh_g:
        g0 = next((g for g in fresh_g if ai_.get("basis") and g["code"] == ai_["basis"][0]), fresh_g[0])
        want_v = "" if g0["fb"] is None else (f"ต่ำกว่าตลิ่ง {f(g0['fb'] * 100)} ซม." if g0["fb"] >= 0 else f"ล้นตลิ่ง {f(-g0['fb'] * 100)} ซม.")
        row("Flood tile value (basis gauge's freeboard)", ft.split("\n")[2], g0["code"], want_v, want_v in ft)
        row("Flood source time (nearest fresh gauge)", re.search(r"สถานีวัดระดับน้ำ \(คลังข้อมูลน้ำแห่งชาติ\) · (.+?น\. [^|⏱]+)", fc).group(1).strip(),
            fresh_g[0]["t"], time_th(fresh_g[0]["t"], now), time_th(fresh_g[0]["t"], now) in fc)
    # HII flash flood
    ff_txt = open(find(curl, r"flashflood_report"), encoding="utf-8-sig").read()
    ff_rows = list(csv.reader(io.StringIO(ff_txt)))
    ff_n = len([r for r in ff_rows[1:] if r and r[0].strip()])
    listed = any(r and r[0].strip() == str(code) for r in ff_rows[1:])
    row("HII flash-flood list", re.search(r"น้ำป่า: .*", fc).group(0) if "น้ำป่า:" in fc else "–", f"{ff_n} rows (header only)" if ff_n == 0 else f"{ff_n} rows",
        f"{'listed' if listed else 'not listed'} ({ff_n} ตำบลทั่วประเทศ)", f"({ff_n} ตำบลทั่วประเทศ)" in fc and (("ไม่อยู่ในรายชื่อ" in fc) != listed))

    # ---------------- quakes ----------------
    em = load_json(find(curl, r"seismicportal"))
    us = load_json(find(curl, r"usgs"))
    qs = []
    for ft_ in em["features"]:
        p = ft_["properties"]
        qs.append({"t": datetime.fromisoformat(p["time"].replace("Z", "+00:00")).timestamp() * 1000, "lat": p["lat"], "lon": p["lon"],
                   "depth": abs(p.get("depth") or 10), "mag": p["mag"], "place": p.get("flynn_region"), "src": "EMSC"})
    for ft_ in us["features"]:
        lo_, la_, dp = ft_["geometry"]["coordinates"]
        p = ft_["properties"]
        qs.append({"t": p["time"], "lat": la_, "lon": lo_, "depth": abs(dp if dp is not None else 10), "mag": p["mag"], "place": p.get("place"), "src": "USGS"})
    tq = load_json(f"{LIVE}/tmd_quakes.json")["items"]
    for q in tq:
        qs.append({"t": datetime.fromisoformat(q["time"]).timestamp() * 1000, "lat": q["lat"], "lon": q["lon"], "depth": q.get("depth", 10),
                   "mag": q["mag"], "place": q["place"], "src": "TMD", "placeTh": q["placeTh"]})
    merged = []
    for q in sorted(qs, key=lambda q: -q["mag"]):
        tw = next((o for o in merged if abs(o["t"] - q["t"]) < 90e3 and hav(o["lat"], o["lon"], q["lat"], q["lon"]) < 100), None)
        if not tw:
            merged.append({**q, "srcs": [q["src"]]})
            continue
        tw["srcs"].append(q["src"])
        if q["src"] == "TMD":
            tw["placeTh"] = q.get("placeTh")
        if q["src"] == "USGS" and q["mag"] >= 5:
            tw["mag"] = q["mag"]
    near_q = []
    for q in merged:
        if not (now - q["t"] <= 7 * 864e5 and q["t"] <= now + 6e5):
            continue
        d = hav(lat, lon, q["lat"], q["lon"])
        mm = mmi_aww12(q["mag"], math.hypot(d, q["depth"] or 10))
        if mm >= 3.0 or d <= 300:
            near_q.append({**q, "km": d, "mmi": mm, "dir": COMPASS[round(brg(lat, lon, q["lat"], q["lon"]) / 45) % 8]})
    near_q.sort(key=lambda q: (-(q["mmi"] or 0), -q["t"]))
    qc = cards.get("quake", "")
    qlines = [l for l in qc.split("\n") if l.startswith("ขนาด")]
    if not near_q:
        row("Quakes ≤ 300 km or MMI ≥ 3 in 7 days", "none" if not qlines else " | ".join(qlines), f"EMSC {len(em['features'])}, USGS {len(us['features'])}, TMD {len(tq)}",
            "none", not qlines)
    for i, q in enumerate(near_q[:3]):
        when = time_th(loc_of(q["t"]), now)
        want = f"ขนาด {f(q['mag'], 1)} {q.get('placeTh') or q.get('place') or ''} ห่าง {f(q['km'])} กม. ทาง{q['dir']} · {when} · {band('mmi', q['mmi'])[1]}"
        got = qlines[i] if i < len(qlines) else "–"
        row(f"Quake line {i + 1}", got, f"{'/'.join(q['srcs'])} {datetime.fromtimestamp(q['t'] / 1000, timezone.utc).isoformat()[:19]}Z {q['lat']},{q['lon']} d{q['depth']}",
            want + f" (MMI {q['mmi']:.1f})", got == want)
    lvq = max([band("mmi", q["mmi"])[0] for q in near_q if now - q["t"] <= 864e5] or [0])
    out["extra"]["levels"]["quake"] = lvq
    out["extra"]["quakes"] = [{k: q[k] for k in ("mag", "km", "mmi", "place", "srcs")} for q in near_q[:5]]

    # ---------------- storms ----------------
    tmd_mine = load_json(f"{X}/raw/collector_src/tmd_storm.json")
    for s in tmd_mine["stormTrackingData"]:
        path = [p for p in s["path"] if p.get("latitude") is not None]
        obs_ = [p for p in path if not p["isPredictData"]]
        last = obs_[-1]
        fcs = [p for p in path if p["isPredictData"]]
        closest = min([last] + fcs, key=lambda p: hav(lat, lon, p["latitude"], p["longitude"]))
        dn = hav(lat, lon, last["latitude"], last["longitude"])
        dc = hav(lat, lon, closest["latitude"], closest["longitude"])
        r10 = lambda x: f(round(x / 10) * 10)
        want = f'กรมอุตุฯ: {last["type"]} "{s["name"]}" ห่างราว {r10(dn)} กม. เส้นทางคาดการณ์เข้าใกล้สุดราว {r10(dc)} กม.'
        got = next((l for l in wc.split("\n") if l.startswith("กรมอุตุฯ")), "–")
        row(f"TMD storm {s['nameEN']}", got, f"TMD StormTrack (fetched {open(X + '/raw/collector_src/fetched_at.txt').read().strip()}): last obs {last['time']} {last['latitude']},{last['longitude']} {last['type']}",
            want, got == want)
    jma_list = load_json(find(curl, r"targetTc"))
    tmd_names = {s["nameEN"].lower() for s in tmd_mine["stormTrackingData"]}
    for t in jma_list:
        fc_ = load_json(find(curl, t["tropicalCyclone"] + "/forecast"))
        title = next(p for p in fc_ if p.get("part") == "title")
        name = title["name"]["en"]
        pos = [p for p in fc_ if isinstance(p.get("center"), list)]
        dnow = hav(lat, lon, pos[0]["center"][0], pos[0]["center"][1])
        edge = min(hav(lat, lon, p["center"][0], p["center"][1]) - ((p.get("probabilityCircle") or {}).get("radius", 0)) / 1000 for p in pos)
        r10 = lambda x: f(round(x / 10) * 10)
        if name.lower() in tmd_names:
            shown = any(l.startswith(f"พายุ {name} ") for l in wc.split("\n"))
            row(f"JMA storm {name}", "line shown" if shown else "not shown (TMD's track used)", f"JMA {t['tropicalCyclone']} {t['category']}",
                "dropped (TMD carries it)", not shown)
            continue
        want = f"พายุ {name} อยู่ห่างราว {r10(dnow)} กม. วงคาดการณ์เข้าใกล้สุดราว {r10(edge)} กม. ใน {pos[-1]['advancedHours']} ชม."
        got = next((l for l in wc.split("\n") if l.startswith(f"พายุ {name}")), "–")
        row(f"JMA storm {name}", got, f"JMA {t['tropicalCyclone']} analysis {pos[0]['center']}", want, got == want)
    gdx = load_json(find(curl, r"gdacs"))
    tcs = []
    for ft_ in gdx["features"]:
        p = ft_["properties"]
        if str(p.get("iscurrent")).lower() == "true" and p.get("eventtype") == "TC":
            lo_, la_ = ft_["geometry"]["coordinates"][:2]
            tcs.append((p.get("name"), hav(lat, lon, la_, lo_)))
    within = [x for x in tcs if x[1] <= 1000]
    row("GDACS TC ≤ 1,000 km", "ไม่มีพายุหมุนเขตร้อนในรัศมี 1,000 กม." if "ไม่มีพายุหมุนเขตร้อน" in wc else "–",
        "; ".join(f"{a} {b:,.0f} km" for a, b in tcs) or "no current TC", "none within 1,000 km" if not within else str(within),
        ("ไม่มีพายุหมุนเขตร้อน" in wc) == (not within))

    # ---------------- hotspots ----------------
    def hs_from_firms():
        out_ = []
        for fn in ("firms_snpp.csv", "firms_j1.csv"):
            with open(f"{X}/raw/collector_src/{fn}", encoding="utf-8") as fh:
                for r in csv.DictReader(fh):
                    la_, lo_ = float(r["latitude"]), float(r["longitude"])
                    if not (5.4 <= la_ <= 20.6 and 97.2 <= lo_ <= 105.8) or r["confidence"] in ("l", "low"):
                        continue
                    out_.append((la_, lo_, r["acq_date"], r["acq_time"]))
        return out_
    hs_mine = hs_from_firms()
    live_hs = load_json(f"{LIVE}/hotspots.json")["items"]
    near_m = sorted(hav(lat, lon, a, b) for a, b, *_ in hs_mine if hav(lat, lon, a, b) <= 25)
    near_l = sorted(hav(lat, lon, h_["lat"], h_["lon"]) for h_ in live_hs if hav(lat, lon, h_["lat"], h_["lon"]) <= 25)
    fc2 = cards.get("fire", "")
    fire_t = tiles["fire"]["text"]
    row("Hotspots ≤ 25 km (VIIRS, not low)", fire_t.split("\n")[2] + (f", nearest {re.search(r'ใกล้สุดห่าง ([\d.]+)', fc2).group(1)} km" if "ใกล้สุดห่าง" in fc2 else ""),
        f"collector file (20:25 UTC): {len(near_l)}{', nearest ' + f(near_l[0], 1) + ' km' if near_l else ''}",
        f"my FIRMS fetch (20:43 UTC): {len(near_m)}{', nearest ' + f(near_m[0], 1) + ' km' if near_m else ''}",
        f"{len(near_l)} จุด" in fire_t and (not near_l or f"ใกล้สุดห่าง {f(near_l[0], 1)} กม." in fc2),
        "" if len(near_l) == len(near_m) else "FIRMS 24-h file moved on between 20:25 and 20:43")
    lv_fire = 0 if not near_l else 2 if near_l[0] <= 2 else 1 if near_l[0] <= 10 else 0
    row("Fire tile level (app rule: nearest ≤ 10 km → watch, ≤ 2 km → warning)", tiles["fire"]["cls"].split("lv-")[1], "",
        ["ok", "watch", "warn", "danger"][lv_fire], tiles["fire"]["cls"].endswith(["ok", "watch", "warn", "danger"][lv_fire]))

    # ---------------- DMR ----------------
    slide = load_json(find(curl, r"VILLLAGE_RISK"))
    fault = load_json(find(curl, r"T_ACTIVEFAULT"))
    lc = cards.get("landslide", "")
    nsl = slide.get("count")
    row("DMR landslide-risk villages ≤ 3 km", (re.search(r"หมู่บ้านเสี่ยงดินถล่ม (\d+) แห่ง", lc).group(1) if "แห่งในรัศมี" in lc else "0 (ไม่มีหมู่บ้านเสี่ยง…)"),
        f"count = {nsl}", str(nsl), (f"หมู่บ้านเสี่ยงดินถล่ม {nsl} แห่ง" in lc) if nsl else ("ไม่มีหมู่บ้านเสี่ยงดินถล่ม" in lc))
    feats = fault.get("features")
    prof = th["profile"]
    if feats is None:
        row("DMR active-fault subdistrict", prof, f"error: {json.dumps(fault)[:120]}", "–", "⚠️")
    else:
        zone = feats[0]["attributes"].get("F_ZONE_T") if feats else None
        want = f"ตำบลนี้อยู่ในรัศมี 20 กม. จากรอยเลื่อนมีพลัง {zone}" if feats else "ตำบลนี้ไม่อยู่ในรายชื่อตำบลใกล้รอยเลื่อนมีพลัง"
        row("DMR active-fault subdistrict", next((l for l in prof.split("\n") if "รอยเลื่อน" in l), "–"), f"TB_CODE={code}: {len(feats)} feature(s) {zone or ''}", want, want in prof)
    # elevation: the page's value vs the ensemble response's own DEM elevation for the same point
    m_el = re.search(r"ความสูงของพื้นที่ราว (\d+) ม\.", prof)
    pel = find(page, r"v1/elevation")
    pel_v = None
    if pel:
        try:
            pel_v = load_json(pel).get("elevation", [None])[0]
        except Exception:
            pel_v = None
    row("Elevation", m_el.group(1) if m_el else "not shown", f"elevation API (page): {pel_v if pel_v is not None else 'HTTP 429/aborted'}",
        f"ensemble response's DEM elevation {e.get('elevation')}", (m_el is None and pel_v is None) or (m_el is not None and f(e.get('elevation')) == m_el.group(1)))

    # ---------------- warnings ----------------
    caps = []
    for fp in glob.glob(f"{X}/raw/collector_src/CAPTMD*.xml"):
        xml = open(fp, encoding="utf-8").read()
        exp = re.search(r"<expires>([^<]+)</expires>", xml).group(1)
        provs = {int(x) for x in re.findall(r"TH-(\d+)", xml)}
        if datetime.fromisoformat(exp).timestamp() * 1000 > now and pv in provs:
            caps.append((re.search(r"<headline>([^<]+)", xml).group(1), exp, re.search(r"<severity>([^<]+)", xml).group(1)))
    wt_ = th["warnings"]
    if caps:
        hl, exp, sev = caps[0]
        want = f"{hl} · ถึง {exp[:16].replace('T', ' ')}"
        row("TMD CAP warning for the province", wt_.split("\n")[1] if wt_ else "–", f"{len(caps)} live item(s) for TH-{pv}: severity {sev}", want, want in wt_)
    else:
        row("TMD CAP warning for the province", wt_ or "none", f"no live item for TH-{pv}", "none", not wt_)
    cap_lv = {"Minor": 1, "Moderate": 1, "Severe": 2, "Extreme": 3}.get(caps[0][2], 1) if caps else -1
    if caps and "ฝน" in caps[0][0]:
        rl = ["ok", "watch", "warn", "danger"].index(tiles["rain"]["cls"].split("lv-")[1]) if "lv-none" not in tiles["rain"]["cls"] else -1
        row("Rain tile vs TMD's heavy-rain warning for the province", f"{tiles['rain']['text'].split(chr(10))[1]} · lv-{tiles['rain']['cls'].split('lv-')[1]}",
            f"TMD CAP '{caps[0][0]}' severity {caps[0][2]}", f"at least {['ok', 'watch', 'warn', 'danger'][cap_lv]} (Severe → เตือนภัย, thresholds doc rule 2)",
            rl >= cap_lv, "assess.js applies CAP warnings to the verdict only (top = max(tiles, warnings)); the rain tile stays at the model's level")

    # ---------------- verdict ----------------
    LVK = ["ok", "watch", "warn", "danger"]
    lv_tiles = {k: (-1 if "lv-none" in t["cls"] else LVK.index(t["cls"].split("lv-")[1])) for k, t in tiles.items()}
    top = max(list(lv_tiles.values()) + [cap_lv])
    vname = {0: "ยังไม่น่าห่วง", 1: "ติดตามไว้", 2: "เตรียมตัว", 3: "ทำทันที"}[top]
    row("Verdict (highest tile or warning)", th["verdict"].split("\n")[1], f"tiles {lv_tiles}, CAP {cap_lv}", vname, vname in th["verdict"])
    out["extra"]["tile_levels"] = lv_tiles
    return out

def main():
    os.makedirs(f"{X}/results", exist_ok=True)
    allr = {}
    for pid in ["bkk", "cnx", "hdy", "hkt", "ubn", "msi"]:
        r = run(pid)
        allr[pid] = r
        with open(f"{X}/results/{pid}.json", "w", encoding="utf-8") as fh:
            json.dump(r, fh, ensure_ascii=False, indent=1, default=str)
        ok = sum(1 for x in r["rows"] if x["match"].startswith("✅"))
        bad = [x for x in r["rows"] if x["match"].startswith("❌")]
        print(f"== {pid}: {ok}/{len(r['rows'])} ✅, {len(bad)} ❌")
        for x in bad:
            print(f"   ❌ {x['item']}\n      page: {x['page']}\n      src : {x['source']}\n      mine: {x['mine']}\n      note: {x['note']}")
        for x in r["rows"]:
            if not x["match"].startswith(("✅", "❌")):
                print(f"   {x['match']} {x['item']}: {x['page']} | {x['source']} | {x['mine']}")

if __name__ == "__main__":
    main()
