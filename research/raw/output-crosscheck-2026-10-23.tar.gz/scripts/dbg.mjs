import { chromium } from "/home/user/disaster-now/node_modules/playwright-core/index.mjs";
const browser = await chromium.launch({ executablePath: "/opt/pw-browsers/chromium", args: ["--no-sandbox", `--proxy-server=${process.env.HTTPS_PROXY}`, "--proxy-bypass-list=127.0.0.1;localhost"],
});
const page = await browser.newPage();
page.on("response", (r) => console.log("resp", r.status(), r.url().slice(0, 120)));
page.on("requestfailed", (r) => console.log("FAIL", r.failure()?.errorText, r.url().slice(0, 120)));
const r = await page.goto("http://127.0.0.1:8787/");
console.log("goto", r?.status(), await page.title());
await page.evaluate(() => { location.hash = "#p=13.7563,100.5018,BKK"; });
await page.waitForTimeout(20000);
console.log((await page.locator("#tiles").innerText()).slice(0, 800));
await browser.close();
