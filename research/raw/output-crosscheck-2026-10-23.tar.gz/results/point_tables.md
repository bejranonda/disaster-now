
### Bangkok old town (13.7563, 100.5018)

Page loaded 20:35:03 UTC (nearest subdistrict แขวงบวรนิเวศ เขตพระนคร กรุงเทพมหานคร, 100107); independent fetches 20:35:12–20:35:20 UTC. **48 ✅ · 3 ❌ · 0 ⚠️** of 51 items.

| Item | Page shows | Source says | My recomputation | Match | Note |
|---|---|---|---|---|---|
| Subdistrict (nearest centroid, HDX table) | ใกล้ แขวงบวรนิเวศ เขตพระนคร กรุงเทพมหานคร | GISTDA reverse lookup of the rounded point: บวรนิเวศ (100107) | แขวงบวรนิเวศ เขตพระนคร กรุงเทพมหานคร (100107, 0.2 km to centroid) | ✅ |  |
| Heat: value (median member's 24-h peak heat index) | 38 °C | 51 members, T & RH hourly | 38 °C (p50 = 37.83) | ✅ |  |
| Heat: band word | เตือนภัย | DOH/TMD 2024 bands | เตือนภัย | ✅ |  |
| Heat: range p10–p90 | 37–39 |  | 37–39 | ✅ |  |
| Heat: air temp peak p50 | 32 |  | 32 | ✅ |  |
| Heat: feels like now (median at this hour) | 27 | hour 2026-10-24T03:00 | 27 | ✅ |  |
| Heat: 3 days (p50 of daily peaks) | 38 39 38 |  | 38 39 38 | ✅ |  |
| Heat: chance ≥ 42 °C line | not shown |  | 0.00 → not shown | ✅ |  |
| Heat: tile level | warn |  | warn | ✅ |  |
| Heat: model time | 03:00 น. วันนี้ | hourly.time[3] = 2026-10-24T03:00 | 03:00 น. วันนี้ | ✅ |  |
| Rain fcst: 24-h median | 2 | 51 members, hourly precipitation summed | 2 (p50 = 2.4000) | ✅ |  |
| Rain fcst: range p10–p90 | 1–5 |  | 1–5 (1.2000–5.3000) | ✅ |  |
| Rain fcst: chance > 35 mm | ไม่ถึง 10% |  | 0.000 → ไม่ถึง 10% | ✅ |  |
| Rain fcst: TMD word (of the median) | ฝนเล็กน้อย | TMD เกณฑ์ปริมาณฝน | ฝนเล็กน้อย | ✅ |  |
| Rain fcst: 3 days (p50) in the table | 2 2 4 |  | 2 2 4 | ✅ |  |
| Gust: 24-h median of member peaks | 27 | 51 members wind_gusts_10m | 27 (p50 = 27.00) | ✅ |  |
| Gust: word (TMD Beaufort) | ลมปานกลาง | TMD เกณฑ์อากาศ p.2 | ลมปานกลาง | ✅ |  |
| Gust: range p10–p90 | 23–32 |  | 23–32 | ✅ |  |
| Gust: 3 days | 27 26 25 |  | 27 26 25 | ✅ |  |
| Other pollution (CAMS at this hour, µg/m³) | PM10 17 · O₃ 91 · NO₂ 18 · SO₂ 11 · CO 763 | CAMS hour 2026-10-24T03:00 | PM10 17 · O₃ 91 · NO₂ 18 · SO₂ 11 · CO 763 | ✅ |  |
| UV now | กลางคืน | CAMS uv_index at 2026-10-24T03:00 = 0.0 | กลางคืน | ✅ |  |
| UV tile value | พรุ่งนี้สูงสุด 7 | daily max: 2026-10-24 7.95, 2026-10-25 7.1, 2026-10-26 6.75 | next daylight is today (2026-10-24): peak 8 | ❌ | at 03:3x the next sun is today's, but the tile says 'tomorrow' (assess.js: c.value = day ? … : `พรุ่งนี้สูงสุด ${air.uv[1]?.max}`) |
| UV: today's peak line + word | สูงสุดวันนี้ราว 8 (สูงมาก) |  | สูงสุดวันนี้ราว 8 (สูงมาก) | ✅ |  |
| UV: 3 days | 8 7 7 |  | 8 7 7 | ✅ |  |
| PM2.5 (GISTDA 24-h estimate) | 45.9 | pm25Avg24hrs = 45.852; pm25 now = 31.49 | 45.9 (เริ่มมีผลกระทบต่อสุขภาพ) | ✅ |  |
| PM2.5 GISTDA time | 03:00 น. วันนี้ | last graph hour 2026-10-24T03:00 (Thai time per datetimeThai 'เวลา 3:00 น.') | 03:00 น. วันนี้ | ✅ |  |
| PM2.5 3 days (CAMS daily mean × GISTDA/CAMS ratio) | 26 12 21 | ratio over 24 h = 1.499 → 1.499 | 26 12 21 | ✅ |  |
| PM2.5 'no PCD station within 15 km' (claim) | ไม่มีสถานีวัดของ คพ. ในรัศมี 15 กม. | Air4Thai official: 173 stations; nearest bkp92t สำนักงานเขตพระนคร 0.9 km, 2026-10-24 03:00 | station bkp92t สำนักงานเขตพระนคร 0.9 km, 24-h mean 31.9 (ปานกลาง) at 2026-10-24 03:00 | ❌ | the page never got Air4Thai (air4thai.com: ERR_CERT_AUTHORITY_INVALID) and words the failure as 'no station' |
| Other pollution: PCD station (should lead) | CAMS values, 'ไม่มีสถานีวัดใกล้ ๆ' | bkp61t สำนักงานคณะกรรมการพัฒนาเศรษฐกิจและสังคมแห่งชาติ 1.3 km 2026-10-24 03:00: {'PM10': 34.0} | AQI 34 (PM10) → ดี | ❌ | Air4Thai unreadable in the page; the card says there is no station nearby |
| Rain measured (nearest gauge ≤ 10 km, ≤ 3 h) | วัดได้ 0.0 มม. ใน 24 ชม. ที่ผ่านมา ที่สนข.พระนคร (ห่าง 1.0 กม.) | ThaiWater rain_24h RF.PNK.01 2026-10-24T03:00 | วัดได้ 0.0 มม. ใน 24 ชม. ที่ผ่านมา ที่สนข.พระนคร (ห่าง 1.0 กม.) | ✅ |  |
| Rain gauge time | 03:00 น. วันนี้ | 2026-10-24T03:00 | 03:00 น. วันนี้ | ✅ |  |
| Rain tile level | ok |  | ok | ✅ |  |
| Gauge C.12 | กรมชลประทานสามเสน (แม่น้ำเจ้าพระยา) ห่าง 3.6 กม.: ต่ำกว่าตลิ่ง 131 ซม. · ใกล้ล้นตลิ่ง (แม่น้ำนอกแนวคัน ไม่ใช้ตัดสินจุดนี้) | ThaiWater 2026-10-24T01:00: level 0.95 m MSL, min_bank 2.26, ground -14.52, situation_level 4 | กรมชลประทานสามเสน (แม่น้ำเจ้าพระยา) ห่าง 3.6 กม.: ต่ำกว่าตลิ่ง 131 ซม. · ใกล้ล้นตลิ่ง (pct 92 %) | ✅ |  |
| Gauge CPY015 | สะพานกรุงเทพ (แม่น้ำเจ้าพระยา) ห่าง 6.3 กม.: ต่ำกว่าตลิ่ง 122 ซม. · ใกล้ล้นตลิ่ง (แม่น้ำนอกแนวคัน ไม่ใช้ตัดสินจุดนี้) | ThaiWater 2026-10-24T03:20: level 0.94 m MSL, min_bank 2.16, ground -15.697, situation_level 4 | สะพานกรุงเทพ (แม่น้ำเจ้าพระยา) ห่าง 6.3 กม.: ต่ำกว่าตลิ่ง 122 ซม. · ใกล้ล้นตลิ่ง (pct 93 %) | ✅ |  |
| Gauge AIT001 | อโศก (คลองแสนแสบ) ห่าง 6.7 กม.: ต่ำกว่าตลิ่ง 112 ซม. · ยังรับน้ำได้ | ThaiWater 2026-10-24T03:20: level 1.27 m MSL, min_bank 2.39, ground 0.5, situation_level 3 | อโศก (คลองแสนแสบ) ห่าง 6.7 กม.: ต่ำกว่าตลิ่ง 112 ซม. · ยังรับน้ำได้ (pct 41 %) | ✅ |  |
| Flood area category (FloodWatch rule on ThaiWater gauges) | ภาพรวมทางน้ำรอบจุดนี้: ยังรับน้ำได้ (จาก 1 สถานี ใกล้สุด 6.7 กม. · ความมั่นใจต่ำมาก) |  | ภาพรวมทางน้ำรอบจุดนี้: ยังรับน้ำได้ (จาก 1 สถานี ใกล้สุด 6.7 กม. · ความมั่นใจต่ำมาก) | ✅ |  |
| Flood tile value (basis gauge's freeboard) | ต่ำกว่าตลิ่ง 112 ซม. | AIT001 | ต่ำกว่าตลิ่ง 112 ซม. | ✅ |  |
| Flood source time (nearest fresh gauge) | 01:00 น. วันนี้ | 2026-10-24T01:00 | 01:00 น. วันนี้ | ✅ |  |
| HII flash-flood list | น้ำป่า: ตำบลนี้ไม่อยู่ในรายชื่อเสี่ยงของ สสน. คืนนี้ (0 ตำบลทั่วประเทศ) | 0 rows (header only) | not listed (0 ตำบลทั่วประเทศ) | ✅ |  |
| Quakes ≤ 300 km or MMI ≥ 3 in 7 days | none | EMSC 69, USGS 136, TMD 10 | none | ✅ |  |
| TMD storm CHAMPI | กรมอุตุฯ: ไต้ฝุ่น "จำปี" ห่างราว 2,590 กม. เส้นทางคาดการณ์เข้าใกล้สุดราว 2,590 กม. | TMD StormTrack (fetched 2026-10-23T20:43:17Z): last obs 2026-10-23T18:00:00 24.8,122.3 ไต้ฝุ่น | กรมอุตุฯ: ไต้ฝุ่น "จำปี" ห่างราว 2,590 กม. เส้นทางคาดการณ์เข้าใกล้สุดราว 2,590 กม. | ✅ |  |
| JMA storm Champi | not shown (TMD's track used) | JMA TC2636 TY | dropped (TMD carries it) | ✅ |  |
| JMA storm In-fa | พายุ In-fa อยู่ห่างราว 7,190 กม. วงคาดการณ์เข้าใกล้สุดราว 6,360 กม. ใน 120 ชม. | JMA TC2637 analysis [10.4, 166.7] | พายุ In-fa อยู่ห่างราว 7,190 กม. วงคาดการณ์เข้าใกล้สุดราว 6,360 กม. ใน 120 ชม. | ✅ |  |
| GDACS TC ≤ 1,000 km | ไม่มีพายุหมุนเขตร้อนในรัศมี 1,000 กม. | Tropical Cyclone VANCE-26 16,357 km | none within 1,000 km | ✅ |  |
| Hotspots ≤ 25 km (VIIRS, not low) | 0 จุด | collector file (20:25 UTC): 0 | my FIRMS fetch (20:43 UTC): 0 | ✅ |  |
| Fire tile level (app rule: nearest ≤ 10 km → watch, ≤ 2 km → warning) | ok |  | ok | ✅ |  |
| DMR landslide-risk villages ≤ 3 km | 0 (ไม่มีหมู่บ้านเสี่ยง…) | count = 0 | 0 | ✅ |  |
| DMR active-fault subdistrict | 〰️ ตำบลนี้ไม่อยู่ในรายชื่อตำบลใกล้รอยเลื่อนมีพลัง (รัศมี 20 กม.) ของกรมทรัพยากรธรณี | TB_CODE=100107: 0 feature(s)  | ตำบลนี้ไม่อยู่ในรายชื่อตำบลใกล้รอยเลื่อนมีพลัง | ✅ |  |
| Elevation | not shown | elevation API (page): HTTP 429/aborted | ensemble response's DEM elevation 7.0 | ✅ |  |
| TMD CAP warning for the province | none | no live item for TH-10 | none | ✅ |  |
| Verdict (highest tile or warning) | เตรียมตัว | tiles {'rain': 0, 'flood': 0, 'pm25': 2, 'heat': 2, 'quake': 0, 'fire': 0, 'wind': 0, 'uv': 0, 'landslide': 0, 'air': -1}, CAP -1 | เตรียมตัว | ✅ |  |

### Chiang Mai (18.7883, 98.9853)

Page loaded 20:35:20 UTC (nearest subdistrict ต.พระสิงห์ อ.เมืองเชียงใหม่ จ.เชียงใหม่, 500102); independent fetches 20:35:26–20:35:29 UTC. **50 ✅ · 3 ❌ · 1 ⚠️** of 54 items.

| Item | Page shows | Source says | My recomputation | Match | Note |
|---|---|---|---|---|---|
| Subdistrict (nearest centroid, HDX table) | ใกล้ ต.พระสิงห์ อ.เมืองเชียงใหม่ จ.เชียงใหม่ | GISTDA reverse lookup of the rounded point: ศรีภูมิ (500101) | ต.พระสิงห์ อ.เมืองเชียงใหม่ จ.เชียงใหม่ (500102, 0.3 km to centroid) | ⚠️ | page = nearest centroid (worded 'ใกล้'); GISTDA's polygon lookup (of 18.79, 98.99) names the neighbour |
| Heat: value (median member's 24-h peak heat index) | 36 °C | 51 members, T & RH hourly | 36 °C (p50 = 36.20) | ✅ |  |
| Heat: band word | เตือนภัย | DOH/TMD 2024 bands | เตือนภัย | ✅ |  |
| Heat: range p10–p90 | 36–37 |  | 36–37 | ✅ |  |
| Heat: air temp peak p50 | 33 |  | 33 | ✅ |  |
| Heat: feels like now (median at this hour) | 25 | hour 2026-10-24T03:00 | 25 | ✅ |  |
| Heat: 3 days (p50 of daily peaks) | 36 37 36 |  | 36 37 36 | ✅ |  |
| Heat: chance ≥ 42 °C line | not shown |  | 0.00 → not shown | ✅ |  |
| Heat: tile level | warn |  | warn | ✅ |  |
| Heat: model time | 03:00 น. วันนี้ | hourly.time[3] = 2026-10-24T03:00 | 03:00 น. วันนี้ | ✅ |  |
| Rain fcst: 24-h median | 0 | 51 members, hourly precipitation summed | 0 (p50 = 0.0000) | ✅ |  |
| Rain fcst: range p10–p90 | 0–0 |  | 0–0 (0.0000–0.0000) | ✅ |  |
| Rain fcst: chance > 35 mm | ไม่ถึง 10% |  | 0.000 → ไม่ถึง 10% | ✅ |  |
| Rain fcst: TMD word (of the median) | ไม่มีฝน | TMD เกณฑ์ปริมาณฝน | ไม่มีฝน | ✅ |  |
| Rain fcst: 3 days (p50) in the table | 0 0 4 |  | 0 0 4 | ✅ |  |
| Gust: 24-h median of member peaks | 18 | 51 members wind_gusts_10m | 18 (p50 = 18.40) | ✅ |  |
| Gust: word (TMD Beaufort) | ลมสงบถึงลมโชย | TMD เกณฑ์อากาศ p.2 | ลมสงบถึงลมโชย | ✅ |  |
| Gust: range p10–p90 | 17–21 |  | 17–21 | ✅ |  |
| Gust: 3 days | 18 19 23 |  | 18 19 23 | ✅ |  |
| Other pollution (CAMS at this hour, µg/m³) | PM10 16 · O₃ 14 · NO₂ 35 · SO₂ 7 · CO 1,773 | CAMS hour 2026-10-24T03:00 | PM10 16 · O₃ 14 · NO₂ 35 · SO₂ 7 · CO 1,773 | ✅ |  |
| UV now | กลางคืน | CAMS uv_index at 2026-10-24T03:00 = 0.0 | กลางคืน | ✅ |  |
| UV tile value | พรุ่งนี้สูงสุด 9 | daily max: 2026-10-24 7.8, 2026-10-25 9.1, 2026-10-26 6.95 | next daylight is today (2026-10-24): peak 8 | ❌ | at 03:3x the next sun is today's, but the tile says 'tomorrow' (assess.js: c.value = day ? … : `พรุ่งนี้สูงสุด ${air.uv[1]?.max}`) |
| UV: today's peak line + word | สูงสุดวันนี้ราว 8 (สูงมาก) |  | สูงสุดวันนี้ราว 8 (สูงมาก) | ✅ |  |
| UV: 3 days | 8 9 7 |  | 8 9 7 | ✅ |  |
| PM2.5 (GISTDA 24-h estimate) | 13.8 | pm25Avg24hrs = 13.818; pm25 now = 16.70 | 13.8 (ดีมาก) | ✅ |  |
| PM2.5 GISTDA time | 03:00 น. วันนี้ | last graph hour 2026-10-24T03:00 (Thai time per datetimeThai 'เวลา 3:00 น.') | 03:00 น. วันนี้ | ✅ |  |
| PM2.5 3 days (CAMS daily mean × GISTDA/CAMS ratio) | 11 13 14 | ratio over 24 h = 0.911 → 0.911 | 11 13 14 | ✅ |  |
| PM2.5 'no PCD station within 15 km' (claim) | ไม่มีสถานีวัดของ คพ. ในรัศมี 15 กม. | Air4Thai official: 173 stations; nearest 36t โรงเรียนยุพราชวิทยาลัย  0.6 km, 2026-10-24 03:00 | station 36t โรงเรียนยุพราชวิทยาลัย  0.6 km, 24-h mean 15.5 (ดี) at 2026-10-24 03:00 | ❌ | the page never got Air4Thai (air4thai.com: ERR_CERT_AUTHORITY_INVALID) and words the failure as 'no station' |
| Other pollution: PCD station | CAMS values | no fresh non-PM2.5 station ≤ 15 km | CAMS is the right fallback | ✅ |  |
| Rain measured (nearest gauge ≤ 10 km, ≤ 3 h) | วัดได้ 0.0 มม. ใน 24 ชม. ที่ผ่านมา ที่ซุ้มเทศบาลหน้าวัดพระสิงห์วรมหาวิหาร (ห่าง 0.3 กม.) | ThaiWater rain_24h TH71 2026-10-24T02:50 | วัดได้ 0.0 มม. ใน 24 ชม. ที่ผ่านมา ที่ซุ้มเทศบาลหน้าวัดพระสิงห์วรมหาวิหาร (ห่าง 0.3 กม.) | ✅ |  |
| Rain gauge time | 02:50 น. วันนี้ | 2026-10-24T02:50 | 02:50 น. วันนี้ | ✅ |  |
| Rain tile level | ok |  | ok | ✅ |  |
| Gauge MOU010 | สะพานห้วยแม่ตาช้าง (ห้วยแม่ท่าช้าง) ห่าง 13.0 กม.: ต่ำกว่าตลิ่ง 408 ซม. · ยังรับน้ำได้ | ThaiWater 2026-10-24T03:20: level 379.55 m MSL, min_bank 383.63, ground 377.753, situation_level 3 | สะพานห้วยแม่ตาช้าง (ห้วยแม่ท่าช้าง) ห่าง 13.0 กม.: ต่ำกว่าตลิ่ง 408 ซม. · ยังรับน้ำได้ (pct 31 %) | ✅ |  |
| Gauge TBW008 | ฝ่ายส่งน้ำและบำรุงรักษาที่ 2 (น้ำแม่ดู) ห่าง 14.7 กม.: ต่ำกว่าตลิ่ง 188 ซม. · ยังรับน้ำได้ | ThaiWater 2026-10-24T03:20: level 320.35 m MSL, min_bank 322.23, ground 318.75, situation_level 3 | ฝ่ายส่งน้ำและบำรุงรักษาที่ 2 (น้ำแม่ดู) ห่าง 14.7 กม.: ต่ำกว่าตลิ่ง 188 ซม. · ยังรับน้ำได้ (pct 46 %) | ✅ |  |
| Gauge MOU009 | สะพานน้ำแม่สา (น้ำแม่สา) ห่าง 19.9 กม.: ต่ำกว่าตลิ่ง 324 ซม. · ยังรับน้ำได้ | ThaiWater 2026-10-24T03:20: level 735.21 m MSL, min_bank 738.45, ground 735.21, situation_level 1 | สะพานน้ำแม่สา (น้ำแม่สา) ห่าง 19.9 กม.: ต่ำกว่าตลิ่ง 324 ซม. · ยังรับน้ำได้ (pct 0 %) | ✅ |  |
| Flood area line | ไม่มีสถานีวัดระดับน้ำที่ส่งข้อมูลในรัศมี 8 กม. |  | ไม่มีสถานีวัดระดับน้ำที่ส่งข้อมูลในรัศมี 8 กม. | ✅ |  |
| Flood tile word/level with NO gauge ≤ 8 km | ยังรับน้ำได้ · lv-ok |  | no area category: should read as unknown / no gauge, not calm | ❌ | assess.js: c.level = ai.category ?? 0 and c.word = RIVER_WORDS[c.level] → 'ยังรับน้ำได้' from no data (rule: missing data is never calm) |
| Flood tile value (basis gauge's freeboard) | ต่ำกว่าตลิ่ง 408 ซม. | MOU010 | ต่ำกว่าตลิ่ง 408 ซม. | ✅ |  |
| Flood source time (nearest fresh gauge) | 03:20 น. วันนี้ | 2026-10-24T03:20 | 03:20 น. วันนี้ | ✅ |  |
| HII flash-flood list | น้ำป่า: ตำบลนี้ไม่อยู่ในรายชื่อเสี่ยงของ สสน. คืนนี้ (0 ตำบลทั่วประเทศ) | 0 rows (header only) | not listed (0 ตำบลทั่วประเทศ) | ✅ |  |
| Quake line 1 | ขนาด 3.5 MYANMAR-CHINA BORDER REGION ห่าง 293 กม. ทางตะวันออกเฉียงเหนือ · 05:03 น. 23 ต.ค. · ไม่น่ารู้สึก | EMSC 2026-10-22T22:03:45Z 21.033,100.453 d10.0 | ขนาด 3.5 MYANMAR-CHINA BORDER REGION ห่าง 293 กม. ทางตะวันออกเฉียงเหนือ · 05:03 น. 23 ต.ค. · ไม่น่ารู้สึก (MMI -0.7) | ✅ |  |
| Quake line 2 | ขนาด 3.0 MYANMAR ห่าง 267 กม. ทางเหนือ · 04:19 น. 23 ต.ค. · ไม่น่ารู้สึก | EMSC 2026-10-22T21:19:35Z 21.17,99.336 d10.0 | ขนาด 3.0 MYANMAR ห่าง 267 กม. ทางเหนือ · 04:19 น. 23 ต.ค. · ไม่น่ารู้สึก (MMI -1.3) | ✅ |  |
| Quake line 3 | ขนาด 1.9 ต.เมืองนะ อ.เชียงดาว จ.เชียงใหม่ ห่าง 108 กม. ทางเหนือ · 16:39 น. 23 ต.ค. · ไม่น่ารู้สึก | TMD 2026-10-23T09:39:24Z 19.761,98.94 d10 | ขนาด 1.9 ต.เมืองนะ อ.เชียงดาว จ.เชียงใหม่ ห่าง 108 กม. ทางเหนือ · 16:39 น. 23 ต.ค. · ไม่น่ารู้สึก (MMI -1.7) | ✅ |  |
| TMD storm CHAMPI | กรมอุตุฯ: ไต้ฝุ่น "จำปี" ห่างราว 2,490 กม. เส้นทางคาดการณ์เข้าใกล้สุดราว 2,490 กม. | TMD StormTrack (fetched 2026-10-23T20:43:17Z): last obs 2026-10-23T18:00:00 24.8,122.3 ไต้ฝุ่น | กรมอุตุฯ: ไต้ฝุ่น "จำปี" ห่างราว 2,490 กม. เส้นทางคาดการณ์เข้าใกล้สุดราว 2,490 กม. | ✅ |  |
| JMA storm Champi | not shown (TMD's track used) | JMA TC2636 TY | dropped (TMD carries it) | ✅ |  |
| JMA storm In-fa | พายุ In-fa อยู่ห่างราว 7,310 กม. วงคาดการณ์เข้าใกล้สุดราว 6,420 กม. ใน 120 ชม. | JMA TC2637 analysis [10.4, 166.7] | พายุ In-fa อยู่ห่างราว 7,310 กม. วงคาดการณ์เข้าใกล้สุดราว 6,420 กม. ใน 120 ชม. | ✅ |  |
| GDACS TC ≤ 1,000 km | ไม่มีพายุหมุนเขตร้อนในรัศมี 1,000 กม. | Tropical Cyclone VANCE-26 16,034 km | none within 1,000 km | ✅ |  |
| Hotspots ≤ 25 km (VIIRS, not low) | 1 จุด, nearest 19.7 km | collector file (20:25 UTC): 1, nearest 19.7 km | my FIRMS fetch (20:43 UTC): 1, nearest 19.7 km | ✅ |  |
| Fire tile level (app rule: nearest ≤ 10 km → watch, ≤ 2 km → warning) | ok |  | ok | ✅ |  |
| DMR landslide-risk villages ≤ 3 km | 1 | count = 1 | 1 | ✅ |  |
| DMR active-fault subdistrict | 〰️ ตำบลนี้อยู่ในรัศมี 20 กม. จากรอยเลื่อนมีพลัง แม่ทา (กรมทรัพยากรธรณี) | TB_CODE=500102: 1 feature(s) แม่ทา | ตำบลนี้อยู่ในรัศมี 20 กม. จากรอยเลื่อนมีพลัง แม่ทา | ✅ |  |
| Elevation | not shown | elevation API (page): HTTP 429/aborted | ensemble response's DEM elevation 312.0 | ✅ |  |
| TMD CAP warning for the province | none | no live item for TH-50 | none | ✅ |  |
| Verdict (highest tile or warning) | เตรียมตัว | tiles {'rain': 0, 'flood': 0, 'pm25': 0, 'heat': 2, 'quake': 0, 'fire': 0, 'wind': 0, 'uv': 0, 'landslide': 0, 'air': -1}, CAP -1 | เตรียมตัว | ✅ |  |

### Hat Yai (7.0086, 100.4747)

Page loaded 20:35:29 UTC (nearest subdistrict ต.หาดใหญ่ อ.หาดใหญ่ จ.สงขลา, 901101); independent fetches 20:35:35–20:36:06 UTC. **50 ✅ · 2 ❌ · 0 ⚠️** of 52 items.

| Item | Page shows | Source says | My recomputation | Match | Note |
|---|---|---|---|---|---|
| Subdistrict (nearest centroid, HDX table) | ใกล้ ต.หาดใหญ่ อ.หาดใหญ่ จ.สงขลา | GISTDA reverse lookup of the rounded point: หาดใหญ่ (901101) | ต.หาดใหญ่ อ.หาดใหญ่ จ.สงขลา (901101, 0.8 km to centroid) | ✅ |  |
| Heat: value (median member's 24-h peak heat index) | 36 °C | 51 members, T & RH hourly | 36 °C (p50 = 36.31) | ✅ |  |
| Heat: band word | เตือนภัย | DOH/TMD 2024 bands | เตือนภัย | ✅ |  |
| Heat: range p10–p90 | 34–39 |  | 34–39 | ✅ |  |
| Heat: air temp peak p50 | 30 |  | 30 | ✅ |  |
| Heat: feels like now (median at this hour) | 26 | hour 2026-10-24T03:00 | 26 | ✅ |  |
| Heat: 3 days (p50 of daily peaks) | 36 35 34 |  | 36 35 34 | ✅ |  |
| Heat: chance ≥ 42 °C line | not shown |  | 0.00 → not shown | ✅ |  |
| Heat: tile level | warn |  | warn | ✅ |  |
| Heat: model time | 03:00 น. วันนี้ | hourly.time[3] = 2026-10-24T03:00 | 03:00 น. วันนี้ | ✅ |  |
| Rain fcst: 24-h median | 14 | 51 members, hourly precipitation summed | 14 (p50 = 13.6000) | ✅ |  |
| Rain fcst: range p10–p90 | 6–23 |  | 6–23 (6.4000–22.9000) | ✅ |  |
| Rain fcst: chance > 35 mm | ไม่ถึง 10% |  | 0.000 → ไม่ถึง 10% | ✅ |  |
| Rain fcst: TMD word (of the median) | ฝนปานกลาง | TMD เกณฑ์ปริมาณฝน | ฝนปานกลาง | ✅ |  |
| Rain fcst: 3 days (p50) in the table | 13 18 20 |  | 13 18 20 | ✅ |  |
| Gust: 24-h median of member peaks | 24 | 51 members wind_gusts_10m | 24 (p50 = 23.80) | ✅ |  |
| Gust: word (TMD Beaufort) | ลมปานกลาง | TMD เกณฑ์อากาศ p.2 | ลมปานกลาง | ✅ |  |
| Gust: range p10–p90 | 22–30 |  | 22–30 | ✅ |  |
| Gust: 3 days | 24 22 23 |  | 24 22 23 | ✅ |  |
| Other pollution (CAMS at this hour, µg/m³) | PM10 2 · O₃ 62 · NO₂ 4 · SO₂ 1 · CO 570 | CAMS hour 2026-10-24T03:00 | PM10 2 · O₃ 62 · NO₂ 4 · SO₂ 1 · CO 570 | ✅ |  |
| UV now | กลางคืน | CAMS uv_index at 2026-10-24T03:00 = 0.0 | กลางคืน | ✅ |  |
| UV tile value | พรุ่งนี้สูงสุด 9 | daily max: 2026-10-24 9.8, 2026-10-25 8.75, 2026-10-26 6.1 | next daylight is today (2026-10-24): peak 10 | ❌ | at 03:3x the next sun is today's, but the tile says 'tomorrow' (assess.js: c.value = day ? … : `พรุ่งนี้สูงสุด ${air.uv[1]?.max}`) |
| UV: today's peak line + word | สูงสุดวันนี้ราว 10 (สูงมาก) |  | สูงสุดวันนี้ราว 10 (สูงมาก) | ✅ |  |
| UV: 3 days | 10 9 6 |  | 10 9 6 | ✅ |  |
| PM2.5 (GISTDA 24-h estimate) | 14.2 | pm25Avg24hrs = 14.171; pm25 now = 13.10 | 14.2 (ดีมาก) | ✅ |  |
| PM2.5 GISTDA time | 03:00 น. วันนี้ | last graph hour 2026-10-24T03:00 (Thai time per datetimeThai 'เวลา 3:00 น.') | 03:00 น. วันนี้ | ✅ |  |
| PM2.5 3 days (CAMS daily mean × GISTDA/CAMS ratio) | 6 4 3 | ratio over 24 h = 2.578 → 2.578 | 6 4 3 | ✅ |  |
| PM2.5 'no PCD station within 15 km' (claim) | ไม่มีสถานีวัดของ คพ. ในรัศมี 15 กม. | Air4Thai official: 173 stations; nearest 44t เทศบาลนครหาดใหญ่  1.7 km, 2026-10-23 21:00 | no fresh station ≤ 15 km | ✅ |  |
| Other pollution: PCD station | CAMS values | no fresh non-PM2.5 station ≤ 15 km | CAMS is the right fallback | ✅ |  |
| Rain measured (nearest gauge ≤ 10 km, ≤ 3 h) | วัดได้ 0.0 มม. ใน 24 ชม. ที่ผ่านมา ที่คลองอู่ตะเภาตอนล่าง (ห่าง 2.2 กม.) | ThaiWater rain_24h G09006-TA200304 2026-10-24T03:00 | วัดได้ 0.0 มม. ใน 24 ชม. ที่ผ่านมา ที่คลองอู่ตะเภาตอนล่าง (ห่าง 2.2 กม.) | ✅ |  |
| Rain gauge time | 03:00 น. วันนี้ | 2026-10-24T03:00 | 03:00 น. วันนี้ | ✅ |  |
| Rain tile level | watch |  | watch | ✅ |  |
| Gauge X.44 | บ้านหาดใหญ่ใน (คลองอู่ตะเภา) ห่าง 2.2 กม.: ต่ำกว่าตลิ่ง 647 ซม. · ยังรับน้ำได้ | ThaiWater 2026-10-23T22:00: level 0.68 m MSL, min_bank 7.15, ground -2.204, situation_level 3 | บ้านหาดใหญ่ใน (คลองอู่ตะเภา) ห่าง 2.2 กม.: ต่ำกว่าตลิ่ง 647 ซม. · ยังรับน้ำได้ (pct 31 %) | ✅ |  |
| Gauge X.174 | บ้านคลองหวะ (คลองหวะ) ห่าง 2.6 กม.: ต่ำกว่าตลิ่ง 389 ซม. · ยังรับน้ำได้ | ThaiWater 2026-10-23T22:00: level 4.99 m MSL, min_bank 8.88, ground None, situation_level 3 | บ้านคลองหวะ (คลองหวะ) ห่าง 2.6 กม.: ต่ำกว่าตลิ่ง 389 ซม. · ยังรับน้ำได้ | ✅ |  |
| Gauge SLA007 | บางกล่ำ (คลองบางกล่ำ) ห่าง 9.4 กม.: ต่ำกว่าตลิ่ง 135 ซม. · ยังรับน้ำได้ | ThaiWater 2026-10-24T03:20: level 0.24 m MSL, min_bank 1.59, ground -1.739, situation_level 3 | บางกล่ำ (คลองบางกล่ำ) ห่าง 9.4 กม.: ต่ำกว่าตลิ่ง 135 ซม. · ยังรับน้ำได้ (pct 59 %) | ✅ |  |
| Flood area category (FloodWatch rule on ThaiWater gauges) | ภาพรวมทางน้ำรอบจุดนี้: ยังรับน้ำได้ (จาก 2 สถานี ใกล้สุด 2.2 กม. · ความมั่นใจปานกลาง) |  | ภาพรวมทางน้ำรอบจุดนี้: ยังรับน้ำได้ (จาก 2 สถานี ใกล้สุด 2.2 กม. · ความมั่นใจปานกลาง) | ✅ |  |
| Flood tile value (basis gauge's freeboard) | ต่ำกว่าตลิ่ง 647 ซม. | X.44 | ต่ำกว่าตลิ่ง 647 ซม. | ✅ |  |
| Flood source time (nearest fresh gauge) | 22:00 น. 23 ต.ค. | 2026-10-23T22:00 | 22:00 น. 23 ต.ค. | ✅ |  |
| HII flash-flood list | น้ำป่า: ตำบลนี้ไม่อยู่ในรายชื่อเสี่ยงของ สสน. คืนนี้ (0 ตำบลทั่วประเทศ) | 0 rows (header only) | not listed (0 ตำบลทั่วประเทศ) | ✅ |  |
| Quakes ≤ 300 km or MMI ≥ 3 in 7 days | none | EMSC 69, USGS 136, TMD 10 | none | ✅ |  |
| TMD storm CHAMPI | กรมอุตุฯ: ไต้ฝุ่น "จำปี" ห่างราว 3,050 กม. เส้นทางคาดการณ์เข้าใกล้สุดราว 3,050 กม. | TMD StormTrack (fetched 2026-10-23T20:43:17Z): last obs 2026-10-23T18:00:00 24.8,122.3 ไต้ฝุ่น | กรมอุตุฯ: ไต้ฝุ่น "จำปี" ห่างราว 3,050 กม. เส้นทางคาดการณ์เข้าใกล้สุดราว 3,050 กม. | ✅ |  |
| JMA storm Champi | not shown (TMD's track used) | JMA TC2636 TY | dropped (TMD carries it) | ✅ |  |
| JMA storm In-fa | พายุ In-fa อยู่ห่างราว 7,280 กม. วงคาดการณ์เข้าใกล้สุดราว 6,530 กม. ใน 120 ชม. | JMA TC2637 analysis [10.4, 166.7] | พายุ In-fa อยู่ห่างราว 7,280 กม. วงคาดการณ์เข้าใกล้สุดราว 6,530 กม. ใน 120 ชม. | ✅ |  |
| GDACS TC ≤ 1,000 km | ไม่มีพายุหมุนเขตร้อนในรัศมี 1,000 กม. | Tropical Cyclone VANCE-26 16,865 km | none within 1,000 km | ✅ |  |
| Hotspots ≤ 25 km (VIIRS, not low) | 0 จุด | collector file (20:25 UTC): 0 | my FIRMS fetch (20:43 UTC): 0 | ✅ |  |
| Fire tile level (app rule: nearest ≤ 10 km → watch, ≤ 2 km → warning) | ok |  | ok | ✅ |  |
| DMR landslide-risk villages ≤ 3 km | 0 (ไม่มีหมู่บ้านเสี่ยง…) | count = 0 | 0 | ✅ |  |
| DMR active-fault subdistrict | 〰️ ตำบลนี้ไม่อยู่ในรายชื่อตำบลใกล้รอยเลื่อนมีพลัง (รัศมี 20 กม.) ของกรมทรัพยากรธรณี | TB_CODE=901101: 0 feature(s)  | ตำบลนี้ไม่อยู่ในรายชื่อตำบลใกล้รอยเลื่อนมีพลัง | ✅ |  |
| Elevation | not shown | elevation API (page): HTTP 429/aborted | ensemble response's DEM elevation 13.0 | ✅ |  |
| TMD CAP warning for the province | พื้นที่เสี่ยงภัยฝนตกหนักบริเวณประเทศไทย · ถึง 2026-10-24 08:00 | 1 live item(s) for TH-90: severity Severe | พื้นที่เสี่ยงภัยฝนตกหนักบริเวณประเทศไทย · ถึง 2026-10-24 08:00 | ✅ |  |
| Rain tile vs TMD's heavy-rain warning for the province | ฝนปานกลาง · lv-watch | TMD CAP 'พื้นที่เสี่ยงภัยฝนตกหนักบริเวณประเทศไทย' severity Severe | at least warn (Severe → เตือนภัย, thresholds doc rule 2) | ❌ | assess.js applies CAP warnings to the verdict only (top = max(tiles, warnings)); the rain tile stays at the model's level |
| Verdict (highest tile or warning) | เตรียมตัว | tiles {'rain': 1, 'flood': 0, 'pm25': 0, 'heat': 2, 'quake': 0, 'fire': 0, 'wind': 0, 'uv': 0, 'landslide': 0, 'air': -1}, CAP 2 | เตรียมตัว | ✅ |  |

### Phuket (7.8804, 98.3923)

Page loaded 20:36:06 UTC (nearest subdistrict ต.ตลาดใหญ่ อ.เมืองภูเก็ต จ.ภูเก็ต, 830101); independent fetches 20:36:23–20:36:32 UTC. **48 ✅ · 2 ❌ · 0 ⚠️** of 50 items.

| Item | Page shows | Source says | My recomputation | Match | Note |
|---|---|---|---|---|---|
| Subdistrict (nearest centroid, HDX table) | ใกล้ ต.ตลาดใหญ่ อ.เมืองภูเก็ต จ.ภูเก็ต | GISTDA reverse lookup of the rounded point: ตลาดใหญ่ (830101) | ต.ตลาดใหญ่ อ.เมืองภูเก็ต จ.ภูเก็ต (830101, 0.8 km to centroid) | ✅ |  |
| Heat: value (median member's 24-h peak heat index) | 33 °C | 51 members, T & RH hourly | 33 °C (p50 = 33.15) | ✅ |  |
| Heat: band word | เตือนภัย | DOH/TMD 2024 bands | เตือนภัย | ✅ |  |
| Heat: range p10–p90 | 32–34 |  | 32–34 | ✅ |  |
| Heat: air temp peak p50 | 29 |  | 29 | ✅ |  |
| Heat: feels like now (median at this hour) | 31 | hour 2026-10-24T03:00 | 31 | ✅ |  |
| Heat: 3 days (p50 of daily peaks) | 33 32 31 |  | 33 32 31 | ✅ |  |
| Heat: chance ≥ 42 °C line | not shown |  | 0.00 → not shown | ✅ |  |
| Heat: tile level | warn |  | warn | ✅ |  |
| Heat: model time | 03:00 น. วันนี้ | hourly.time[3] = 2026-10-24T03:00 | 03:00 น. วันนี้ | ✅ |  |
| Rain fcst: 24-h median | 12 | 51 members, hourly precipitation summed | 13 (p50 = 12.5000) | ✅ (.5 tie) | an exact .5: the float sum lands either side (rounding only) |
| Rain fcst: range p10–p90 | 8–16 |  | 8–17 (8.1000–16.5000) | ✅ (.5 tie) | an exact .5: rounding only |
| Rain fcst: chance > 35 mm | ไม่ถึง 10% |  | 0.000 → ไม่ถึง 10% | ✅ |  |
| Rain fcst: TMD word (of the median) | ฝนปานกลาง | TMD เกณฑ์ปริมาณฝน | ฝนปานกลาง | ✅ |  |
| Rain fcst: 3 days (p50) in the table | 10 16 16 |  | 10 16 16 | ✅ |  |
| Gust: 24-h median of member peaks | 30 | 51 members wind_gusts_10m | 30 (p50 = 29.90) | ✅ |  |
| Gust: word (TMD Beaufort) | ลมแรง | TMD เกณฑ์อากาศ p.2 | ลมแรง | ✅ |  |
| Gust: range p10–p90 | 24–34 |  | 24–34 | ✅ |  |
| Gust: 3 days | 30 26 23 |  | 30 26 23 | ✅ |  |
| Other pollution (CAMS at this hour, µg/m³) | PM10 3 · O₃ 53 · NO₂ 3 · SO₂ 1 · CO 433 | CAMS hour 2026-10-24T03:00 | PM10 3 · O₃ 53 · NO₂ 3 · SO₂ 1 · CO 433 | ✅ |  |
| UV now | กลางคืน | CAMS uv_index at 2026-10-24T03:00 = 0.0 | กลางคืน | ✅ |  |
| UV tile value | พรุ่งนี้สูงสุด 8 | daily max: 2026-10-24 10.45, 2026-10-25 8.15, 2026-10-26 7.1 | next daylight is today (2026-10-24): peak 10 | ❌ | at 03:3x the next sun is today's, but the tile says 'tomorrow' (assess.js: c.value = day ? … : `พรุ่งนี้สูงสุด ${air.uv[1]?.max}`) |
| UV: today's peak line + word | สูงสุดวันนี้ราว 10 (สูงมาก) |  | สูงสุดวันนี้ราว 10 (สูงมาก) | ✅ |  |
| UV: 3 days | 10 8 7 |  | 10 8 7 | ✅ |  |
| PM2.5 (GISTDA 24-h estimate) | 15.7 | pm25Avg24hrs = 15.730; pm25 now = 12.45 | 15.7 (ดี) | ✅ |  |
| PM2.5 GISTDA time | 03:00 น. วันนี้ | last graph hour 2026-10-24T03:00 (Thai time per datetimeThai 'เวลา 3:00 น.') | 03:00 น. วันนี้ | ✅ |  |
| PM2.5 3 days (CAMS daily mean × GISTDA/CAMS ratio) | 5 4 5 | ratio over 24 h = 4.046 → 3.000 | 5 4 5 | ✅ |  |
| PM2.5 'no PCD station within 15 km' (claim) | ไม่มีสถานีวัดของ คพ. ในรัศมี 15 กม. | Air4Thai official: 173 stations; nearest 43t ศูนย์บริการสาธารณสุขเทศบาลภูเก็ต 0.5 km, 2026-10-23 21:00 | no fresh station ≤ 15 km | ✅ |  |
| Other pollution: PCD station | CAMS values | no fresh non-PM2.5 station ≤ 15 km | CAMS is the right fallback | ✅ |  |
| Rain measured (nearest gauge ≤ 10 km, ≤ 3 h) | วัดได้ 0.4 มม. ใน 24 ชม. ที่ผ่านมา ที่ภูเก็ต (ห่าง 0.9 กม.) | ThaiWater rain_24h 48564 2026-10-24T01:00 | วัดได้ 0.4 มม. ใน 24 ชม. ที่ผ่านมา ที่ภูเก็ต (ห่าง 0.9 กม.) | ✅ |  |
| Rain gauge time | 01:00 น. วันนี้ | 2026-10-24T01:00 | 01:00 น. วันนี้ | ✅ |  |
| Rain tile level | watch |  | watch | ✅ |  |
| Gauge X.190A | บ้านเก็ตโฮ่ (คลองเก็ตโฮ) ห่าง 5.3 กม.: ต่ำกว่าตลิ่ง 208 ซม. · ยังรับน้ำได้ | ThaiWater 2026-10-23T22:00: level 15.05 m MSL, min_bank 17.13, ground 13.967, situation_level 3 | บ้านเก็ตโฮ่ (คลองเก็ตโฮ) ห่าง 5.3 กม.: ต่ำกว่าตลิ่ง 208 ซม. · ยังรับน้ำได้ (pct 34 %) | ✅ |  |
| Flood area category (FloodWatch rule on ThaiWater gauges) | ภาพรวมทางน้ำรอบจุดนี้: ยังรับน้ำได้ (จาก 1 สถานี ใกล้สุด 5.3 กม. · ความมั่นใจต่ำมาก) |  | ภาพรวมทางน้ำรอบจุดนี้: ยังรับน้ำได้ (จาก 1 สถานี ใกล้สุด 5.3 กม. · ความมั่นใจต่ำมาก) | ✅ |  |
| Flood tile value (basis gauge's freeboard) | ต่ำกว่าตลิ่ง 208 ซม. | X.190A | ต่ำกว่าตลิ่ง 208 ซม. | ✅ |  |
| Flood source time (nearest fresh gauge) | 22:00 น. 23 ต.ค. | 2026-10-23T22:00 | 22:00 น. 23 ต.ค. | ✅ |  |
| HII flash-flood list | น้ำป่า: ตำบลนี้ไม่อยู่ในรายชื่อเสี่ยงของ สสน. คืนนี้ (0 ตำบลทั่วประเทศ) | 0 rows (header only) | not listed (0 ตำบลทั่วประเทศ) | ✅ |  |
| Quakes ≤ 300 km or MMI ≥ 3 in 7 days | none | EMSC 69, USGS 136, TMD 10 | none | ✅ |  |
| TMD storm CHAMPI | กรมอุตุฯ: ไต้ฝุ่น "จำปี" ห่างราว 3,160 กม. เส้นทางคาดการณ์เข้าใกล้สุดราว 3,160 กม. | TMD StormTrack (fetched 2026-10-23T20:43:17Z): last obs 2026-10-23T18:00:00 24.8,122.3 ไต้ฝุ่น | กรมอุตุฯ: ไต้ฝุ่น "จำปี" ห่างราว 3,160 กม. เส้นทางคาดการณ์เข้าใกล้สุดราว 3,160 กม. | ✅ |  |
| JMA storm Champi | not shown (TMD's track used) | JMA TC2636 TY | dropped (TMD carries it) | ✅ |  |
| JMA storm In-fa | พายุ In-fa อยู่ห่างราว 7,490 กม. วงคาดการณ์เข้าใกล้สุดราว 6,730 กม. ใน 120 ชม. | JMA TC2637 analysis [10.4, 166.7] | พายุ In-fa อยู่ห่างราว 7,490 กม. วงคาดการณ์เข้าใกล้สุดราว 6,730 กม. ใน 120 ชม. | ✅ |  |
| GDACS TC ≤ 1,000 km | ไม่มีพายุหมุนเขตร้อนในรัศมี 1,000 กม. | Tropical Cyclone VANCE-26 16,978 km | none within 1,000 km | ✅ |  |
| Hotspots ≤ 25 km (VIIRS, not low) | 0 จุด | collector file (20:25 UTC): 0 | my FIRMS fetch (20:43 UTC): 0 | ✅ |  |
| Fire tile level (app rule: nearest ≤ 10 km → watch, ≤ 2 km → warning) | ok |  | ok | ✅ |  |
| DMR landslide-risk villages ≤ 3 km | 0 (ไม่มีหมู่บ้านเสี่ยง…) | count = 0 | 0 | ✅ |  |
| DMR active-fault subdistrict | 〰️ ตำบลนี้อยู่ในรัศมี 20 กม. จากรอยเลื่อนมีพลัง คลองมะรุ่ย (กรมทรัพยากรธรณี) | TB_CODE=830101: 1 feature(s) คลองมะรุ่ย | ตำบลนี้อยู่ในรัศมี 20 กม. จากรอยเลื่อนมีพลัง คลองมะรุ่ย | ✅ |  |
| Elevation | not shown | elevation API (page): HTTP 429/aborted | ensemble response's DEM elevation 4.0 | ✅ |  |
| TMD CAP warning for the province | พื้นที่เสี่ยงภัยฝนตกหนักบริเวณประเทศไทย · ถึง 2026-10-24 08:00 | 1 live item(s) for TH-83: severity Severe | พื้นที่เสี่ยงภัยฝนตกหนักบริเวณประเทศไทย · ถึง 2026-10-24 08:00 | ✅ |  |
| Rain tile vs TMD's heavy-rain warning for the province | ฝนปานกลาง · lv-watch | TMD CAP 'พื้นที่เสี่ยงภัยฝนตกหนักบริเวณประเทศไทย' severity Severe | at least warn (Severe → เตือนภัย, thresholds doc rule 2) | ❌ | assess.js applies CAP warnings to the verdict only (top = max(tiles, warnings)); the rain tile stays at the model's level |
| Verdict (highest tile or warning) | เตรียมตัว | tiles {'rain': 1, 'flood': 0, 'pm25': 0, 'heat': 2, 'quake': 0, 'fire': 0, 'wind': 0, 'uv': 0, 'landslide': 0, 'air': -1}, CAP 2 | เตรียมตัว | ✅ |  |

### Ubon Ratchathani (15.2287, 104.8564)

Page loaded 20:36:32 UTC (nearest subdistrict ต.ในเมือง อ.เมืองอุบลราชธานี จ.อุบลราชธานี, 340101); independent fetches 20:36:38–20:36:45 UTC. **47 ✅ · 3 ❌ · 0 ⚠️** of 50 items.

| Item | Page shows | Source says | My recomputation | Match | Note |
|---|---|---|---|---|---|
| Subdistrict (nearest centroid, HDX table) | ใกล้ ต.ในเมือง อ.เมืองอุบลราชธานี จ.อุบลราชธานี | GISTDA reverse lookup of the rounded point: ในเมือง (340101) | ต.ในเมือง อ.เมืองอุบลราชธานี จ.อุบลราชธานี (340101, 2.1 km to centroid) | ✅ |  |
| Heat: value (median member's 24-h peak heat index) | 37 °C | 51 members, T & RH hourly | 37 °C (p50 = 37.16) | ✅ |  |
| Heat: band word | เตือนภัย | DOH/TMD 2024 bands | เตือนภัย | ✅ |  |
| Heat: range p10–p90 | 37–38 |  | 37–38 | ✅ |  |
| Heat: air temp peak p50 | 32 |  | 32 | ✅ |  |
| Heat: feels like now (median at this hour) | 26 | hour 2026-10-24T03:00 | 26 | ✅ |  |
| Heat: 3 days (p50 of daily peaks) | 37 37 36 |  | 37 37 36 | ✅ |  |
| Heat: chance ≥ 42 °C line | not shown |  | 0.00 → not shown | ✅ |  |
| Heat: tile level | warn |  | warn | ✅ |  |
| Heat: model time | 03:00 น. วันนี้ | hourly.time[3] = 2026-10-24T03:00 | 03:00 น. วันนี้ | ✅ |  |
| Rain fcst: 24-h median | 1 | 51 members, hourly precipitation summed | 1 (p50 = 0.6000) | ✅ |  |
| Rain fcst: range p10–p90 | 0–1 |  | 0–2 (0.0000–1.5000) | ✅ (.5 tie) | an exact .5: rounding only |
| Rain fcst: chance > 35 mm | ไม่ถึง 10% |  | 0.000 → ไม่ถึง 10% | ✅ |  |
| Rain fcst: TMD word (of the median) | ฝนเล็กน้อย | TMD เกณฑ์ปริมาณฝน | ฝนเล็กน้อย | ✅ |  |
| Rain fcst: 3 days (p50) in the table | 1 2 6 |  | 1 2 6 | ✅ |  |
| Gust: 24-h median of member peaks | 17 | 51 members wind_gusts_10m | 17 (p50 = 17.30) | ✅ |  |
| Gust: word (TMD Beaufort) | ลมสงบถึงลมโชย | TMD เกณฑ์อากาศ p.2 | ลมสงบถึงลมโชย | ✅ |  |
| Gust: range p10–p90 | 16–20 |  | 16–20 | ✅ |  |
| Gust: 3 days | 17 18 21 |  | 17 18 21 | ✅ |  |
| Other pollution (CAMS at this hour, µg/m³) | PM10 5 · O₃ 46 · NO₂ 10 · SO₂ 3 · CO 296 | CAMS hour 2026-10-24T03:00 | PM10 5 · O₃ 46 · NO₂ 10 · SO₂ 3 · CO 296 | ✅ |  |
| UV now | กลางคืน | CAMS uv_index at 2026-10-24T03:00 = 0.0 | กลางคืน | ✅ |  |
| UV tile value | พรุ่งนี้สูงสุด 9 | daily max: 2026-10-24 8.3, 2026-10-25 8.85, 2026-10-26 7.65 | next daylight is today (2026-10-24): peak 8 | ❌ | at 03:3x the next sun is today's, but the tile says 'tomorrow' (assess.js: c.value = day ? … : `พรุ่งนี้สูงสุด ${air.uv[1]?.max}`) |
| UV: today's peak line + word | สูงสุดวันนี้ราว 8 (สูงมาก) |  | สูงสุดวันนี้ราว 8 (สูงมาก) | ✅ |  |
| UV: 3 days | 8 9 8 |  | 8 9 8 | ✅ |  |
| PM2.5 (GISTDA 24-h estimate) | 9.8 | pm25Avg24hrs = 9.799; pm25 now = 12.11 | 9.8 (ดีมาก) | ✅ |  |
| PM2.5 GISTDA time | 03:00 น. วันนี้ | last graph hour 2026-10-24T03:00 (Thai time per datetimeThai 'เวลา 3:00 น.') | 03:00 น. วันนี้ | ✅ |  |
| PM2.5 3 days (CAMS daily mean × GISTDA/CAMS ratio) | 6 6 8 | ratio over 24 h = 1.166 → 1.166 | 6 6 8 | ✅ |  |
| PM2.5 'no PCD station within 15 km' (claim) | ไม่มีสถานีวัดของ คพ. ในรัศมี 15 กม. | Air4Thai official: 173 stations; nearest 83t ศูนย์แสดงและจำหน่ายสินค้า OTOP จังหวัดอุบลราชธานี 2.2 km, 2026-10-24 03:00 | station 83t ศูนย์แสดงและจำหน่ายสินค้า OTOP จังหวัดอุบลราชธานี 2.2 km, 24-h mean 11.4 (ดีมาก) at 2026-10-24 03:00 | ❌ | the page never got Air4Thai (air4thai.com: ERR_CERT_AUTHORITY_INVALID) and words the failure as 'no station' |
| Other pollution: PCD station (should lead) | CAMS values, 'ไม่มีสถานีวัดใกล้ ๆ' | 83t ศูนย์แสดงและจำหน่ายสินค้า OTOP จังหวัดอุบลราชธานี 2.2 km 2026-10-24 03:00: {'PM10': 12.0} | AQI 12 (PM10) → ดีมาก | ❌ | Air4Thai unreadable in the page; the card says there is no station nearby |
| Rain measured (nearest gauge ≤ 10 km, ≤ 3 h) | วัดได้ 0.0 มม. ใน 24 ชม. ที่ผ่านมา ที่อุบลราชธานี (ห่าง 0.6 กม.) | ThaiWater rain_24h G09006-TA054502 2026-10-24T03:00 | วัดได้ 0.0 มม. ใน 24 ชม. ที่ผ่านมา ที่อุบลราชธานี (ห่าง 0.6 กม.) | ✅ |  |
| Rain gauge time | 03:00 น. วันนี้ | 2026-10-24T03:00 | 03:00 น. วันนี้ | ✅ |  |
| Rain tile level | ok |  | ok | ✅ |  |
| Gauge PMTS16 | แม่น้ำมูล เมืองอุบลราชธานี (M.7) (แม่น้ำมูล) ห่าง 0.6 กม.: ต่ำกว่าตลิ่ง 540 ซม. · ยังรับน้ำได้ | ThaiWater 2026-10-24T03:00: level 108.44 m MSL, min_bank 113.84, ground 101.79, situation_level 3 | แม่น้ำมูล เมืองอุบลราชธานี (M.7) (แม่น้ำมูล) ห่าง 0.6 กม.: ต่ำกว่าตลิ่ง 540 ซม. · ยังรับน้ำได้ (pct 55 %) | ✅ |  |
| Gauge M.7 | สะพานเสรีประชาธิปไตย (แม่น้ำมูล) ห่าง 0.7 กม.: ต่ำกว่าตลิ่ง 354 ซม. · ยังรับน้ำได้ | ThaiWater 2026-10-24T02:00: level 108.46 m MSL, min_bank 112.0, ground 100.42, situation_level 3 | สะพานเสรีประชาธิปไตย (แม่น้ำมูล) ห่าง 0.7 กม.: ต่ำกว่าตลิ่ง 354 ซม. · ยังรับน้ำได้ (pct 69 %) | ✅ |  |
| Flood area category (FloodWatch rule on ThaiWater gauges) | ภาพรวมทางน้ำรอบจุดนี้: ยังรับน้ำได้ (จาก 2 สถานี ใกล้สุด 0.6 กม. · ความมั่นใจปานกลาง) |  | ภาพรวมทางน้ำรอบจุดนี้: ยังรับน้ำได้ (จาก 2 สถานี ใกล้สุด 0.6 กม. · ความมั่นใจปานกลาง) | ✅ |  |
| Flood tile value (basis gauge's freeboard) | ต่ำกว่าตลิ่ง 540 ซม. | PMTS16 | ต่ำกว่าตลิ่ง 540 ซม. | ✅ |  |
| Flood source time (nearest fresh gauge) | 03:00 น. วันนี้ | 2026-10-24T03:00 | 03:00 น. วันนี้ | ✅ |  |
| HII flash-flood list | น้ำป่า: ตำบลนี้ไม่อยู่ในรายชื่อเสี่ยงของ สสน. คืนนี้ (0 ตำบลทั่วประเทศ) | 0 rows (header only) | not listed (0 ตำบลทั่วประเทศ) | ✅ |  |
| Quake line 1 | ขนาด 3.8 LAOS-VIETNAM-CAMBODIA BORDER REG ห่าง 290 กม. ทางตะวันออก · 06:04 น. 20 ต.ค. · ไม่น่ารู้สึก | EMSC 2026-10-19T23:04:16Z 14.998,107.543 d10.0 | ขนาด 3.8 LAOS-VIETNAM-CAMBODIA BORDER REG ห่าง 290 กม. ทางตะวันออก · 06:04 น. 20 ต.ค. · ไม่น่ารู้สึก (MMI -0.3) | ✅ |  |
| TMD storm CHAMPI | กรมอุตุฯ: ไต้ฝุ่น "จำปี" ห่างราว 2,110 กม. เส้นทางคาดการณ์เข้าใกล้สุดราว 2,110 กม. | TMD StormTrack (fetched 2026-10-23T20:43:17Z): last obs 2026-10-23T18:00:00 24.8,122.3 ไต้ฝุ่น | กรมอุตุฯ: ไต้ฝุ่น "จำปี" ห่างราว 2,110 กม. เส้นทางคาดการณ์เข้าใกล้สุดราว 2,110 กม. | ✅ |  |
| JMA storm Champi | not shown (TMD's track used) | JMA TC2636 TY | dropped (TMD carries it) | ✅ |  |
| JMA storm In-fa | พายุ In-fa อยู่ห่างราว 6,710 กม. วงคาดการณ์เข้าใกล้สุดราว 5,870 กม. ใน 120 ชม. | JMA TC2637 analysis [10.4, 166.7] | พายุ In-fa อยู่ห่างราว 6,710 กม. วงคาดการณ์เข้าใกล้สุดราว 5,870 กม. ใน 120 ชม. | ✅ |  |
| GDACS TC ≤ 1,000 km | ไม่มีพายุหมุนเขตร้อนในรัศมี 1,000 กม. | Tropical Cyclone VANCE-26 15,908 km | none within 1,000 km | ✅ |  |
| Hotspots ≤ 25 km (VIIRS, not low) | 0 จุด | collector file (20:25 UTC): 0 | my FIRMS fetch (20:43 UTC): 0 | ✅ |  |
| Fire tile level (app rule: nearest ≤ 10 km → watch, ≤ 2 km → warning) | ok |  | ok | ✅ |  |
| DMR landslide-risk villages ≤ 3 km | 0 (ไม่มีหมู่บ้านเสี่ยง…) | count = 0 | 0 | ✅ |  |
| DMR active-fault subdistrict | 〰️ ตำบลนี้ไม่อยู่ในรายชื่อตำบลใกล้รอยเลื่อนมีพลัง (รัศมี 20 กม.) ของกรมทรัพยากรธรณี | TB_CODE=340101: 0 feature(s)  | ตำบลนี้ไม่อยู่ในรายชื่อตำบลใกล้รอยเลื่อนมีพลัง | ✅ |  |
| Elevation | 124 | elevation API (page): 124.0 | ensemble response's DEM elevation 124.0 | ✅ |  |
| TMD CAP warning for the province | none | no live item for TH-34 | none | ✅ |  |
| Verdict (highest tile or warning) | เตรียมตัว | tiles {'rain': 0, 'flood': 0, 'pm25': 0, 'heat': 2, 'quake': 0, 'fire': 0, 'wind': 0, 'uv': 0, 'landslide': 0, 'air': -1}, CAP -1 | เตรียมตัว | ✅ |  |

### Mae Sai (20.4285, 99.8765)

Page loaded 20:36:45 UTC (nearest subdistrict ต.เวียงพางคำ อ.แม่สาย จ.เชียงราย, 570906); independent fetches 20:36:51–20:37:22 UTC. **49 ✅ · 2 ❌ · 0 ⚠️** of 51 items.

| Item | Page shows | Source says | My recomputation | Match | Note |
|---|---|---|---|---|---|
| Subdistrict (nearest centroid, HDX table) | ใกล้ ต.เวียงพางคำ อ.แม่สาย จ.เชียงราย | GISTDA reverse lookup of the rounded point: เวียงพางคำ (570906) | ต.เวียงพางคำ อ.แม่สาย จ.เชียงราย (570906, 2.3 km to centroid) | ✅ |  |
| Heat: value (median member's 24-h peak heat index) | 36 °C | 51 members, T & RH hourly | 36 °C (p50 = 35.71) | ✅ |  |
| Heat: band word | เตือนภัย | DOH/TMD 2024 bands | เตือนภัย | ✅ |  |
| Heat: range p10–p90 | 35–36 |  | 35–36 | ✅ |  |
| Heat: air temp peak p50 | 31 |  | 31 | ✅ |  |
| Heat: feels like now (median at this hour) | 25 | hour 2026-10-24T03:00 | 25 | ✅ |  |
| Heat: 3 days (p50 of daily peaks) | 36 36 36 |  | 36 36 36 | ✅ |  |
| Heat: chance ≥ 42 °C line | not shown |  | 0.00 → not shown | ✅ |  |
| Heat: tile level | warn |  | warn | ✅ |  |
| Heat: model time | 03:00 น. วันนี้ | hourly.time[3] = 2026-10-24T03:00 | 03:00 น. วันนี้ | ✅ |  |
| Rain fcst: 24-h median | 0 | 51 members, hourly precipitation summed | 0 (p50 = 0.0000) | ✅ |  |
| Rain fcst: range p10–p90 | 0–0 |  | 0–0 (0.0000–0.3000) | ✅ |  |
| Rain fcst: chance > 35 mm | ไม่ถึง 10% |  | 0.000 → ไม่ถึง 10% | ✅ |  |
| Rain fcst: TMD word (of the median) | ไม่มีฝน | TMD เกณฑ์ปริมาณฝน | ไม่มีฝน | ✅ |  |
| Rain fcst: 3 days (p50) in the table | 0 0 2 |  | 0 0 2 | ✅ |  |
| Gust: 24-h median of member peaks | 21 | 51 members wind_gusts_10m | 21 (p50 = 21.20) | ✅ |  |
| Gust: word (TMD Beaufort) | ลมปานกลาง | TMD เกณฑ์อากาศ p.2 | ลมปานกลาง | ✅ |  |
| Gust: range p10–p90 | 19–24 |  | 19–24 | ✅ |  |
| Gust: 3 days | 21 20 23 |  | 21 20 23 | ✅ |  |
| Other pollution (CAMS at this hour, µg/m³) | PM10 15 · O₃ 24 · NO₂ 15 · SO₂ 3 · CO 642 | CAMS hour 2026-10-24T03:00 | PM10 15 · O₃ 24 · NO₂ 15 · SO₂ 3 · CO 642 | ✅ |  |
| UV now | กลางคืน | CAMS uv_index at 2026-10-24T03:00 = 0.0 | กลางคืน | ✅ |  |
| UV tile value | พรุ่งนี้สูงสุด 9 | daily max: 2026-10-24 7.95, 2026-10-25 8.55, 2026-10-26 7.7 | next daylight is today (2026-10-24): peak 8 | ❌ | at 03:3x the next sun is today's, but the tile says 'tomorrow' (assess.js: c.value = day ? … : `พรุ่งนี้สูงสุด ${air.uv[1]?.max}`) |
| UV: today's peak line + word | สูงสุดวันนี้ราว 8 (สูงมาก) |  | สูงสุดวันนี้ราว 8 (สูงมาก) | ✅ |  |
| UV: 3 days | 8 9 8 |  | 8 9 8 | ✅ |  |
| PM2.5 (GISTDA 24-h estimate) | 30.4 | pm25Avg24hrs = 30.420; pm25 now = 15.00 | 30.4 (ปานกลาง) | ✅ |  |
| PM2.5 GISTDA time | 03:00 น. วันนี้ | last graph hour 2026-10-24T03:00 (Thai time per datetimeThai 'เวลา 3:00 น.') | 03:00 น. วันนี้ | ✅ |  |
| PM2.5 3 days (CAMS daily mean × GISTDA/CAMS ratio) | 33 37 41 | ratio over 24 h = 2.808 → 2.808 | 33 37 41 | ✅ |  |
| PM2.5 'no PCD station within 15 km' (claim) | ไม่มีสถานีวัดของ คพ. ในรัศมี 15 กม. | Air4Thai official: 173 stations; nearest 73t สำนักงานสาธารณสุขแม่สาย 0.8 km, 2026-10-24 03:00 | station 73t สำนักงานสาธารณสุขแม่สาย 0.8 km, 24-h mean 25.4 (ปานกลาง) at 2026-10-24 03:00 | ❌ | the page never got Air4Thai (air4thai.com: ERR_CERT_AUTHORITY_INVALID) and words the failure as 'no station' |
| Other pollution: PCD station | CAMS values | no fresh non-PM2.5 station ≤ 15 km | CAMS is the right fallback | ✅ |  |
| Rain measured (nearest gauge ≤ 10 km, ≤ 3 h) | วัดได้ 0.0 มม. ใน 24 ชม. ที่ผ่านมา ที่สะพานมิตรภาพแม่น้ำสายแห่งที่ 1 (ห่าง 1.8 กม.) | ThaiWater rain_24h MYA004 2026-10-24T03:00 | วัดได้ 0.0 มม. ใน 24 ชม. ที่ผ่านมา ที่สะพานมิตรภาพแม่น้ำสายแห่งที่ 1 (ห่าง 1.8 กม.) | ✅ |  |
| Rain gauge time | 03:00 น. วันนี้ | 2026-10-24T03:00 | 03:00 น. วันนี้ | ✅ |  |
| Rain tile level | ok |  | ok | ✅ |  |
| Gauge MYA004 | สะพานมิตรภาพแม่น้ำสายแห่งที่ 1 (ลุ่มน้ำโขงเหนือ) ห่าง 1.8 กม.: ต่ำกว่าตลิ่ง 285 ซม. · ยังรับน้ำได้ | ThaiWater 2026-10-24T03:20: level 394.74 m MSL, min_bank 397.59, ground 392.717, situation_level 3 | สะพานมิตรภาพแม่น้ำสายแห่งที่ 1 (ลุ่มน้ำโขงเหนือ) ห่าง 1.8 กม.: ต่ำกว่าตลิ่ง 285 ซม. · ยังรับน้ำได้ (pct 42 %) | ✅ |  |
| Flood area category (FloodWatch rule on ThaiWater gauges) | ภาพรวมทางน้ำรอบจุดนี้: ยังรับน้ำได้ (จาก 1 สถานี ใกล้สุด 1.8 กม. · ความมั่นใจต่ำ) |  | ภาพรวมทางน้ำรอบจุดนี้: ยังรับน้ำได้ (จาก 1 สถานี ใกล้สุด 1.8 กม. · ความมั่นใจต่ำ) | ✅ |  |
| Flood tile value (basis gauge's freeboard) | ต่ำกว่าตลิ่ง 285 ซม. | MYA004 | ต่ำกว่าตลิ่ง 285 ซม. | ✅ |  |
| Flood source time (nearest fresh gauge) | 03:20 น. วันนี้ | 2026-10-24T03:20 | 03:20 น. วันนี้ | ✅ |  |
| HII flash-flood list | น้ำป่า: ตำบลนี้ไม่อยู่ในรายชื่อเสี่ยงของ สสน. คืนนี้ (0 ตำบลทั่วประเทศ) | 0 rows (header only) | not listed (0 ตำบลทั่วประเทศ) | ✅ |  |
| Quake line 1 | ขนาด 4.6 MYANMAR ห่าง 184 กม. ทางตะวันตกเฉียงเหนือ · 04:08 น. 18 ต.ค. · ไม่น่ารู้สึก | EMSC 2026-10-17T21:08:23Z 21.9272,99.1332 d10.0 | ขนาด 4.6 MYANMAR ห่าง 184 กม. ทางตะวันตกเฉียงเหนือ · 04:08 น. 18 ต.ค. · ไม่น่ารู้สึก (MMI 1.4) | ✅ |  |
| Quake line 2 | ขนาด 3.5 MYANMAR-CHINA BORDER REGION ห่าง 90 กม. ทางตะวันออกเฉียงเหนือ · 05:03 น. 23 ต.ค. · ไม่น่ารู้สึก | EMSC 2026-10-22T22:03:45Z 21.033,100.453 d10.0 | ขนาด 3.5 MYANMAR-CHINA BORDER REGION ห่าง 90 กม. ทางตะวันออกเฉียงเหนือ · 05:03 น. 23 ต.ค. · ไม่น่ารู้สึก (MMI 0.8) | ✅ |  |
| Quake line 3 | ขนาด 4.2 ประเทศลาว ห่าง 266 กม. ทางตะวันออกเฉียงใต้ · 02:31 น. วันนี้ · ไม่น่ารู้สึก | EMSC/TMD 2026-10-23T19:31:21Z 19.081,101.974 d10.0 | ขนาด 4.2 ประเทศลาว ห่าง 266 กม. ทางตะวันออกเฉียงใต้ · 02:31 น. วันนี้ · ไม่น่ารู้สึก (MMI 0.4) | ✅ |  |
| TMD storm CHAMPI | กรมอุตุฯ: ไต้ฝุ่น "จำปี" ห่างราว 2,350 กม. เส้นทางคาดการณ์เข้าใกล้สุดราว 2,350 กม. | TMD StormTrack (fetched 2026-10-23T20:43:17Z): last obs 2026-10-23T18:00:00 24.8,122.3 ไต้ฝุ่น | กรมอุตุฯ: ไต้ฝุ่น "จำปี" ห่างราว 2,350 กม. เส้นทางคาดการณ์เข้าใกล้สุดราว 2,350 กม. | ✅ |  |
| JMA storm Champi | not shown (TMD's track used) | JMA TC2636 TY | dropped (TMD carries it) | ✅ |  |
| JMA storm In-fa | พายุ In-fa อยู่ห่างราว 7,210 กม. วงคาดการณ์เข้าใกล้สุดราว 6,300 กม. ใน 120 ชม. | JMA TC2637 analysis [10.4, 166.7] | พายุ In-fa อยู่ห่างราว 7,210 กม. วงคาดการณ์เข้าใกล้สุดราว 6,300 กม. ใน 120 ชม. | ✅ |  |
| GDACS TC ≤ 1,000 km | ไม่มีพายุหมุนเขตร้อนในรัศมี 1,000 กม. | Tropical Cyclone VANCE-26 15,832 km | none within 1,000 km | ✅ |  |
| Hotspots ≤ 25 km (VIIRS, not low) | 10 จุด, nearest 5.8 km | collector file (20:25 UTC): 10, nearest 5.8 km | my FIRMS fetch (20:43 UTC): 10, nearest 5.8 km | ✅ |  |
| Fire tile level (app rule: nearest ≤ 10 km → watch, ≤ 2 km → warning) | watch |  | watch | ✅ |  |
| DMR landslide-risk villages ≤ 3 km | 8 | count = 8 | 8 | ✅ |  |
| DMR active-fault subdistrict | 〰️ ตำบลนี้ไม่อยู่ในรายชื่อตำบลใกล้รอยเลื่อนมีพลัง (รัศมี 20 กม.) ของกรมทรัพยากรธรณี | TB_CODE=570906: 0 feature(s)  | ตำบลนี้ไม่อยู่ในรายชื่อตำบลใกล้รอยเลื่อนมีพลัง | ✅ |  |
| Elevation | 422 | elevation API (page): 422.0 | ensemble response's DEM elevation 422.0 | ✅ |  |
| TMD CAP warning for the province | none | no live item for TH-57 | none | ✅ |  |
| Verdict (highest tile or warning) | เตรียมตัว | tiles {'rain': 0, 'flood': 0, 'pm25': 1, 'heat': 2, 'quake': 0, 'fire': 1, 'wind': 0, 'uv': 0, 'landslide': 0, 'air': -1}, CAP -1 | เตรียมตัว | ✅ |  |
